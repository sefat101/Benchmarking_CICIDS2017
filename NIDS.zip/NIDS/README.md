# NIDS Baselines — CICIDS2017 (`ml.csv`), 8 PyTorch architectures

Eight base `nn.Module` classes for multi-class intrusion detection on 1D
tabular flow features, an efficiency-oriented preprocessing pipeline, and one
journal-ready artefact folder per model.

Every model accepts a **raw 2D tabular batch** `[batch_size, n_features]`.
All reshaping (`unsqueeze`, `permute`) happens inside `forward()`, so no model
needs a custom collate function or a reshaping wrapper in the training loop.

---

## 1. Project layout

**All code lives in `core/`. Everything else — generated artefacts, data,
checkpoints, logs, writing — lives outside it, at this root.**

```
E:\NIDS\
├── core/                          ← CODE ONLY
│   ├── common/
│   │   ├── preprocessing.py       CICIDS2017 ml.csv pipeline (§4)
│   │   └── model_utils.py         params, MACs, shape trace, latency, SVG
│   ├── models/
│   │   ├── ann.py                 ANN
│   │   ├── cnn1d.py               CNN1D
│   │   ├── autoencoder.py         Autoencoder
│   │   ├── encoder.py             Encoder
│   │   ├── transformer.py         TabTransformer
│   │   ├── cnn_rnn.py             CNNRNN
│   │   ├── cnn_lstm.py            CNNLSTM
│   │   ├── cnn_gru.py             CNNGRU
│   │   └── __init__.py            REGISTRY + build() helper
│   ├── tools/
│   │   └── build_journal_outputs.py   regenerates every artefact below
│   ├── verify_all.py              smoke test: 8 models, one dummy batch
│   └── requirements.txt
│
├── 01_ann/  02_cnn1d/  03_autoencoder/  04_encoder/          ← GENERATED
├── 05_transformer/  06_cnn_rnn/  07_cnn_lstm/  08_cnn_gru/     artefacts,
│   ├── README.md                  methods text, hyperparameters, LaTeX        one folder
│   ├── architecture.svg / .mmd    print-ready diagram + Mermaid source        per model
│   ├── summary.txt                torchinfo layer table
│   ├── shape_trace.txt            per-layer input/output shapes
│   └── params.json                machine-readable metrics
│
├── comparison.csv / comparison.md  cross-model table for the paper
├── verification_log.txt
├── data/                          put ml.csv here; data/cache/ is auto-filled
├── checkpoints/                   trained weights (.pt)
├── logs/                          training curves, run logs
└── docs/                          the paper itself
    ├── figures/                   copy the SVGs here when a figure is final
    └── tables/                    exported LaTeX/CSV tables
```

Nothing in the eight artefact folders is hand-written — they are regenerated
by `core/tools/build_journal_outputs.py`. Edit the model in `core/models/`,
rerun the builder, and every README, diagram, summary and table updates.

---

## 2. The eight architectures

| # | Class | Source | Output | Params (F=78, C=15) | Role in the study |
|---|---|---|---|---|---|
| 1 | `ANN` | `core/models/ann.py` | `[B, 15]` logits | 55,055 | Permutation-agnostic control |
| 2 | `CNN1D` | `core/models/cnn1d.py` | `[B, 15]` logits | 7,311 | Local feature-group prior |
| 3 | `Autoencoder` | `core/models/autoencoder.py` | `[B, 78]` reconstruction | 14,318 | Unsupervised / zero-day arm |
| 4 | `Encoder` | `core/models/encoder.py` | `[B, 32]` embedding | 7,136 | Representation probe |
| 5 | `TabTransformer` | `core/models/transformer.py` | `[B, 15]` logits | 73,231 | Full pairwise feature attention |
| 6 | `CNNRNN` | `core/models/cnn_rnn.py` | `[B, 15]` logits | 15,631 | Ungated recurrence (control) |
| 7 | `CNNLSTM` | `core/models/cnn_lstm.py` | `[B, 15]` logits | 40,591 | 4-gate recurrence |
| 8 | `CNNGRU` | `core/models/cnn_gru.py` | `[B, 15]` logits | 32,271 | 2-gate recurrence |

Full metrics — MACs per sample, model size, CPU latency and throughput — are
in [`comparison.md`](comparison.md) / [`comparison.csv`](comparison.csv).

---

## 3. Quick start

First-time environment setup — including the Pascal/`sm_61` wheel trap that
affects the GTX 1070 — is in **[SETUP.md](SETUP.md)**, or just run
`setup.bat`.

```bat
cd /d E:\NIDS
.venv\Scripts\activate

python core\tools\check_env.py             # Python / torch / CUDA / GPU check
python core\verify_all.py                  # smoke test, all 8 models
python core\tools\build_journal_outputs.py # regenerate all artefacts
```

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import CNNLSTM

prep   = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv"))
bundle = prep.run()
print(prep.summary(bundle))                # paste this block into the paper

train_dl, val_dl, test_dl = prep.make_dataloaders(bundle, batch_size=1024)
model = CNNLSTM(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Run everything from the project root so `core` resolves as a package.

---

## 4. Preprocessing (`core/common/preprocessing.py`)

Every step is there either to remove work from the training loop or to remove
a documented failure mode of this dataset:

| Step | What it does | Why it pays off |
|---|---|---|
| `usecols` skip list | Flow ID, IPs, timestamp, ports are never parsed | Avoids tokenising columns you would drop anyway, and removes the strongest testbed-memorisation leak |
| `dtype=float32` | Half of pandas' default float64 | ~2.1x less RAM on the full `ml.csv` |
| `chunksize` | Streams the CSV in blocks | Bounds peak memory independently of file size |
| `.npy` cache + `mmap_mode='r'` | Cleaned arrays reloaded, not recomputed | Cold run parses once; later runs start in milliseconds and page data in on demand |
| inf/NaN repair | `Flow Bytes/s`, `Flow Packets/s` | The two known `±inf` sources in CICIDS2017 |
| Duplicate-row removal **before** the split | ~20–30% of rows are exact duplicates | Identical flows in train and test inflate every reported metric |
| Constant / duplicate / collinear pruning (\|r\| > 0.98) | Smaller input layer | Fewer parameters, faster epochs, less to regularise |
| `QuantileTransformer(output='normal')` | Heavy tails spanning ~9 orders of magnitude | Reaches a given loss in far fewer steps than `StandardScaler` on raw values |
| Scaler fitted on **train only** | No distributional leakage | The one line that keeps the numbers defensible |
| Canonical 15-class label map | Handles the `\x96` en-dash in the Web Attack labels | The most common cause of phantom extra classes |
| Class weights + optional `WeightedRandomSampler` | BENIGN is ~80% of rows | Minority recall is the metric reviewers check |
| Optional `benign_cap` | Undersamples BENIGN | The single largest epoch-time saving available on this dataset |

Configuration lives in the `PreprocessConfig` dataclass — scaler choice,
correlation threshold, BENIGN cap, split ratios and seed are one keyword away,
and the cache key is a hash of the config, so changing any of them
transparently produces a fresh cache under `data/cache/`.

**Never hardcode 78.** Pruning changes the final feature count; always
construct models with `bundle.input_dim`.

---

## 5. Where to add regularisation

Every file in `core/models/` carries commented anchors:

```python
# nn.BatchNorm1d(h1),   # <-- ADD BATCH-NORM HERE
# nn.Dropout(0.3),      # <-- ADD DROPOUT HERE
```

The base classes are deliberately shallow (1–2 layers per block) and
un-regularised so the ablation table has a clean starting point.

---

## 6. Reporting checklist

- Report **macro-F1 and per-class recall**, not accuracy — BENIGN dominance
  makes accuracy uninformative on CICIDS2017.
- Models 3 and 4 are not 15-class classifiers. Score the autoencoder with
  ROC-AUC / PR-AUC and TPR at fixed FPR (0.1% and 1%); score the encoder with
  a linear probe and k-NN.
- Report mean ± std over ≥ 3 seeds before claiming any ordering among models
  6, 7 and 8 — the gaps are routinely smaller than seed noise.
- Report parameters and latency alongside accuracy (both are in
  `comparison.csv`); the parameter budgets here are deliberately unequal, so a
  fair-comparison claim needs either matched budgets or an explicit table.
- Declare the feature-ordering dependence of models 2, 6, 7 and 8, and run the
  column-shuffle ablation.
- State that the "sequence" fed to the recurrent models is the pooled feature
  axis, not time. There is no temporal axis in per-flow tabular rows.
