# 06_cnn_rnn — CNN-RNN

**1D-CNN + Vanilla Recurrent Neural Network** · family: *Hybrid convolutional-recurrent*

Convolutional stem compresses the feature axis into 39 64-channel steps, which a tanh RNN then reads sequentially.

> **Source code:** [`core/models/cnn_rnn.py`](../core/models/cnn_rnn.py) — class `CNNRNN`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | unsqueeze(1) -> [B, 1, F]; after the conv stem permute(0, 2, 1) turns [B, C, L] into the [B, T, feat] layout nn.RNN expects. |
| Parameters (total / trainable) | 15,631 / 15,631 |
| Model size (fp32) | 0.0596 MB |
| MACs per sample | 567,552 |
| CPU latency @ batch 32 | 1.6098 ms (19,878 samples/s) |

## 2. Inductive bias — why this model is in the study

Two stacked priors: convolutional locality over adjacent columns, then a strictly ordered recursion over the pooled positions. The recursion is the weakest of the three recurrent variants — the single tanh gate gives it the shortest effective memory — which is precisely why it belongs in the study as the vanishing-gradient control for the LSTM and GRU rows.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | unsqueeze(1) | [B, 1, 78] |
| 3 | Conv1d k=3 + ReLU | 1 -> 32 ch |
| 4 | MaxPool1d /2 | 78 -> 39 |
| 5 | Conv1d k=3 + ReLU | 32 -> 64 ch |
| 6 | permute(0,2,1) | [B, 39, 64] |
| 7 | RNN (tanh), 1 layer | hidden 64 |
| 8 | Last time step | [B, 64] |
| 9 | Linear (classifier) | 64 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `channels` | (32, 64) | Conv stem feature maps |
| `kernel_size` | 3 | Conv receptive field |
| `hidden_size` | 64 | RNN hidden state width |
| `num_layers` | 1 | Recurrent depth |
| `bidirectional` | False | Set True for a Bi-RNN ablation |
| `nonlinearity` | tanh | Vanilla Elman recursion |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `cnn.net.0` | Conv1d | 32x1x78 | 32x32x78 | 128 |
| `cnn.net.1` | ReLU | 32x32x78 | 32x32x78 | 0 |
| `cnn.net.2` | MaxPool1d | 32x32x78 | 32x32x39 | 0 |
| `cnn.net.3` | Conv1d | 32x32x39 | 32x64x39 | 6,208 |
| `cnn.net.4` | ReLU | 32x64x39 | 32x64x39 | 0 |
| `rnn` | RNN | 32x39x64 | (32x39x64, 1x32x64) | 8,320 |
| `classifier` | Linear | 32x64 | 32x15 | 975 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
The conv stem maps $\mathbf{x}$ to $\mathbf{U}\in\mathbb{R}^{C\times L}$ with $C=64$, $L=\lfloor F/2\rfloor$. Writing $\mathbf{u}_t$ for the $t$-th column of $\mathbf{U}$, the Elman recursion is
\begin{equation}
\mathbf{h}_t=\tanh\!\left(\mathbf{W}_{ih}\mathbf{u}_t+\mathbf{W}_{hh}\mathbf{h}_{t-1}+\mathbf{b}\right),\qquad \mathbf{h}_0=\mathbf{0},
\end{equation}
and the terminal state $\mathbf{h}_L$ is classified by $\mathbf{z}=\mathbf{W}_o\mathbf{h}_L+\mathbf{b}_o$.
```

## 6. Reporting notes

- The 'sequence' here is synthetic — it is the pooled feature axis, not time. Say so plainly in the paper: several published NIDS papers apply recurrence to per-flow tabular rows without acknowledging that no temporal axis exists, and a reviewer will look for that admission.
- Because the recursion is length-39 with a single tanh gate, the gradient norm at t=1 is the quantity to plot when arguing why the gated variants (07, 08) outperform this model.
- Matched parameter budget with 07/08 is not automatic: LSTM has 4x and GRU 3x the recurrent weights at equal hidden_size. Either report parameters per model (see comparison.csv) or shrink hidden_size for the gated variants when claiming a fair fight.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import CNNRNN

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = CNNRNN(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
