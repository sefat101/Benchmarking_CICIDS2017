# 04_encoder — Encoder

**Standalone Encoder / Latent Feature Extractor** · family: *Representation learning*

The autoencoder's encoder used on its own to emit a 32-d embedding for probing, transfer or clustering.

> **Source code:** [`core/models/encoder.py`](../core/models/encoder.py) — class `Encoder`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, D]  (D = latent_dim = 32)` — latent embedding (logits only if attach_head=True) |
| Verified output for `torch.randn(32, 78)` | `32x32` |
| Reshaping | None — operates directly on the 2D tabular batch. |
| Parameters (total / trainable) | 7,136 / 7,136 |
| Model size (fp32) | 0.0272 MB |
| MACs per sample | 7,040 |
| CPU latency @ batch 32 | 0.0854 ms (374,906 samples/s) |

## 2. Inductive bias — why this model is in the study

Identical to the autoencoder encoder, but the representation is evaluated rather than inverted. Isolating it lets the paper separate two questions that are usually conflated: how much class structure the unsupervised bottleneck captures, and how much the supervised head adds on top.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | Linear + ReLU | 78 -> 64 |
| 3 | Linear + ReLU (latent) | 64 -> 32 |
| 4 | Linear head (optional) | 32 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `latent_dim` | 32 | Dimensionality of the emitted embedding |
| `hidden_dim` | 64 | Intermediate width |
| `attach_head` | False | Set True for the linear-probe experiment |
| `freeze` | True (transfer) | Via load_from_autoencoder() |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `encoder.0` | Linear | 32x78 | 32x64 | 5,056 |
| `encoder.1` | ReLU | 32x64 | 32x64 | 0 |
| `encoder.2` | Linear | 32x64 | 32x32 | 2,080 |
| `encoder.3` | ReLU | 32x32 | 32x32 | 0 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
The encoder realises $f_\theta:\mathbb{R}^{F}\!\to\!\mathbb{R}^{d}$, $\mathbf{z}=f_\theta(\mathbf{x})=\sigma(\mathbf{W}_2\,\sigma(\mathbf{W}_1\mathbf{x}+\mathbf{b}_1)+\mathbf{b}_2)$ with $d=32$. In the linear-probe protocol $\theta$ is frozen after unsupervised pre-training and only $\mathbf{W}_{p}\in\mathbb{R}^{C\times d}$ is fitted, so the probe accuracy is a direct measure of the linear separability of the learned representation.
```

## 6. Reporting notes

- Standard reporting for this model: (i) linear-probe macro-F1, (ii) k-NN (k=5) accuracy in the embedding space, and (iii) a 2-D t-SNE or UMAP projection coloured by attack class — the qualitative figure reviewers expect from a representation section.
- Because the embedding is only 32-d, it is also the cheapest input for downstream classical classifiers (RF, XGBoost), which makes a useful hybrid row in the results table.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import Encoder

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = Encoder(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
