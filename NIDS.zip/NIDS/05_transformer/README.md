# 05_transformer — Transformer

**Encoder-only Transformer (feature-as-token)** · family: *Attention*

Treats each of the 78 flow statistics as a token and lets self-attention learn the full pairwise feature-interaction graph.

> **Source code:** [`core/models/transformer.py`](../core/models/transformer.py) — class `TabTransformer`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | x.unsqueeze(-1) -> [B, F, 1], then a shared Linear(1, d_model) lifts every scalar to a token; a learnable [1, F, d_model] positional embedding is added. |
| Parameters (total / trainable) | 73,231 / 73,231 |
| Model size (fp32) | 0.2794 MB |
| MACs per sample | 6,675,264 |
| CPU latency @ batch 32 | 6.9187 ms (4,625 samples/s) |

## 2. Inductive bias — why this model is in the study

No locality assumption — attention is permutation-equivariant and the positional embedding is learned, so the model can discover long-range feature interactions (e.g. flow duration paired with backward IAT std) that the 1D-CNN can only reach through stacked receptive fields. The cost is quadratic attention in F and the largest per-sample latency of the eight baselines.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | unsqueeze(-1) | [B, 78, 1] |
| 3 | Value projection | 1 -> 64 (d_model) |
| 4 | + Positional embedding | [1, 78, 64] learnable |
| 5 | TransformerEncoderLayer x2 | 4 heads, FFN 128, pre-LN |
| 6 | Mean pool over tokens | [B, 64] |
| 7 | Linear (classifier) | 64 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `d_model` | 64 | Token embedding width |
| `nhead` | 4 | Attention heads (head dim = 16) |
| `num_layers` | 2 | Encoder blocks (kept shallow by design) |
| `dim_feedforward` | 128 | FFN inner width (2x d_model) |
| `dropout` | 0.1 | Applied inside attention and FFN |
| `pool` | mean | Alternative: 'cls' token pooling |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `value_proj` | Linear | 32x78x1 | 32x78x64 | 128 |
| `encoder.layers.0.norm1` | LayerNorm | 32x78x64 | 32x78x64 | 128 |
| `encoder.layers.0.dropout1` | Dropout | 32x78x64 | 32x78x64 | 0 |
| `encoder.layers.0.norm2` | LayerNorm | 32x78x64 | 32x78x64 | 128 |
| `encoder.layers.0.linear1` | Linear | 32x78x64 | 32x78x128 | 8,320 |
| `encoder.layers.0.dropout` | Dropout | 32x78x128 | 32x78x128 | 0 |
| `encoder.layers.0.linear2` | Linear | 32x78x128 | 32x78x64 | 8,256 |
| `encoder.layers.0.dropout2` | Dropout | 32x78x64 | 32x78x64 | 0 |
| `encoder.layers.1.norm1` | LayerNorm | 32x78x64 | 32x78x64 | 128 |
| `encoder.layers.1.dropout1` | Dropout | 32x78x64 | 32x78x64 | 0 |
| `encoder.layers.1.norm2` | LayerNorm | 32x78x64 | 32x78x64 | 128 |
| `encoder.layers.1.linear1` | Linear | 32x78x64 | 32x78x128 | 8,320 |
| `encoder.layers.1.dropout` | Dropout | 32x78x128 | 32x78x128 | 0 |
| `encoder.layers.1.linear2` | Linear | 32x78x128 | 32x78x64 | 8,256 |
| `encoder.layers.1.dropout2` | Dropout | 32x78x64 | 32x78x64 | 0 |
| `norm` | LayerNorm | 32x78x64 | 32x78x64 | 128 |
| `classifier` | Linear | 32x64 | 32x15 | 975 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
Each scalar feature $x_i$ is embedded as $\mathbf{t}_i=\mathbf{W}_v x_i+\mathbf{b}_v+\mathbf{p}_i\in\mathbb{R}^{d}$, where $\mathbf{p}_i$ is a learnable column-positional code. The token matrix $\mathbf{T}\in\mathbb{R}^{F\times d}$ is processed by $L=2$ pre-norm encoder blocks, each computing
\begin{align}
\mathrm{Attn}(\mathbf{T})&=\mathrm{softmax}\!\left(\frac{\mathbf{Q}\mathbf{K}^{\top}}{\sqrt{d/h}}\right)\mathbf{V},\\
\mathbf{T}'&=\mathbf{T}+\mathrm{Attn}(\mathrm{LN}(\mathbf{T})),\qquad
\mathbf{T}''=\mathbf{T}'+\mathrm{FFN}(\mathrm{LN}(\mathbf{T}')),
\end{align}
with $h=4$ heads. The sequence is reduced by mean pooling, $\bar{\mathbf{t}}=\tfrac{1}{F}\sum_i \mathbf{T}''_i$, and mapped to logits by a single affine layer.
```

## 6. Reporting notes

- Complexity is O(F^2 d) per sample; with F = 78 the attention matrix is 78x78, which is small enough to visualise directly — a head-averaged attention heat-map over named CICFlowMeter columns is a strong interpretability figure and differentiates the paper from the accuracy-only NIDS literature.
- Pre-LN (norm_first=True) is used because 2-layer post-LN stacks need a warm-up schedule to converge; state this to justify the deviation from the vanilla formulation.
- If throughput matters, report tokens/second alongside accuracy — this model is the natural 'upper bound on cost' row.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import TabTransformer

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = TabTransformer(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
