# 06 — References

What each source is used for, and — where it matters — what it does *not*
support. Verify every number against the source before it enters the
manuscript; the summaries below are working notes, not citations.

---

## Primary evidence for the gap analysis

**[1] Do Transformers Actually Help Intrusion Detection? A Temporal Sequence
Evaluation on CIC-IDS2017.** arXiv:2606.11098 (2026).
https://arxiv.org/abs/2606.11098

The load-bearing source for G1, G2 and G3. Re-runs nine models (SVM, RF, MLP,
Image-CNN, LSTM, GRU, 1D-CNN, CNN+Transformer, Transformer-small) on
CIC-IDS2017 under three split protocols, with 3 seeds.

Used for:
- Transformer macro-F1 0.775 (random) → 0.549 (group-by-five-tuple), Δ −0.226;
  LSTM 0.776 → 0.753; GRU 0.762 → 0.736; 1D-CNN 0.754 → 0.733; RF 0.769 →
  0.778 (+0.009, the most robust model).
- False-alarm rate: Transformer 0.04% → 2.7% (67x); RF 0.16% → 0.14%.
- Latency on A100: Transformer 1.73 ms/sample vs LSTM 0.13, GRU 0.12,
  1D-CNN 0.09.
- Padding ablation: repeat-last → zero-pad+mask costs LSTM/GRU ~0.02, 1D-CNN
  0.046, Transformer 0.243 — the direct evidence that self-attention latched
  onto an input-encoding artefact.
- Chronological splitting is degenerate on CIC-IDS2017 (2 of 13 classes in the
  test window) because attacks are scheduled per day.
- Flow-level 15-class RF reaches macro-F1 0.801.
- The Heartbleed / Infiltration count discrepancy in Liu et al. (reported 514
  and 6,401 against the actual 11 and 36).

Does **not** support: any claim about the reduced 10-class task (it uses 13
windowed classes), or about CPU inference (all latency is A100).

**[2] Evaluating Tabular Representation Learning for Network Intrusion
Detection.** arXiv:2605.02519 (2026). https://arxiv.org/abs/2605.02519

Used for G3 and G4: no representation-classifier combination dominates; an
end-to-end BERT ties autoencoder+SVM and TabICL+RF; macro-F1 is 0.29–0.49
across all methods while binary F1 sits near 0.88; rare classes (Backdoor,
Worms, Bot, Infiltration, SQL Injection) are "largely undetectable" regardless
of representation.

Does **not** support: anything about CICIDS2017 specifically — this paper uses
CIDDS-001, NF-UNSW-NB15-v2 and NF-CSE-CIC-IDS2018-v2. Cite it for the general
rare-class and representation findings only.

**[3] Engelen, Timmerman & Lagerström. Troubleshooting an Intrusion Detection
Dataset: the CICIDS2017 Case Study** / **Errors in the CICIDS2017 Dataset and
the Significant Differences in Detection Performances It Makes** (2021, 2023).
https://link.springer.com/chapter/10.1007/978-3-031-31108-6_2

The standard citation for CICIDS2017 flow-construction and labelling errors,
and for destination-port shortcut overfitting. Used to justify dropping
Infiltration and the port column. **Read the original before citing** — [1]
cites it second-hand and this analysis inherits that.

---

## Method sources

**[4] Menon et al. Long-tail learning via logit adjustment.** ICLR 2021.
The `LogitAdjustedLoss` in `core/common/balancing.py`. Bayes-consistency under
label shift.

**[5] Cui et al. Class-Balanced Loss Based on Effective Number of Samples.**
CVPR 2019. `ClassBalancedLoss` and the `effective` sampling scheme.

**[6] Lin et al. Focal Loss for Dense Object Detection.** ICCV 2017.
`FocalLoss`.

**[7] Ganin & Lempitsky. Unsupervised Domain Adaptation by Backpropagation.**
ICML 2015. The gradient-reversal layer used for the shortcut-invariance head.
Note the reuse is off-label: the original target is domain adaptation, here it
is nuisance-invariance within one domain. Say so explicitly.

**[8] Martins & Astudillo. From Softmax to Sparsemax.** ICML 2016. The group
gate.

**[9] Arik & Pfister. TabNet: Attentive Interpretable Tabular Learning.**
AAAI 2021. Precedent for sparse learned feature selection on tabular data;
SIGMA-IDS's gate operates over semantic groups rather than raw columns.

**[10] Gorishniy et al. Revisiting Deep Learning Models for Tabular Data.**
NeurIPS 2021. Source of the FT-Transformer feature-tokeniser design that
grouped tokenisation departs from, and of the finding that well-tuned
baselines are hard to beat on tabular data.

**[11] Verma et al. Manifold Mixup.** ICML 2019. `manifold_mixup`.

**[12] Chawla et al. SMOTE.** JAIR 2002. Cited as the method whose raw-space
application `flow_invariant_violations` is designed to police — not as a
recommendation.

**[13] Sharafaldin, Lashkari & Ghorbani. Toward Generating a New Intrusion
Detection Dataset and Intrusion Traffic Characterization.** ICISSP 2018.
The CICIDS2017 dataset paper and CICFlowMeter feature definitions. The source
for the arithmetic identities the invariant check enforces.

---

## Context / framing

**[14] Deep Learning-based Intrusion Detection Systems: A Survey.**
arXiv:2504.07839 (2025). https://arxiv.org/abs/2504.07839
Positioning only. **Not yet read past the abstract** — the fetch returned the
abstract alone. Read it before citing anything specific.

**[15] Deployment-oriented evaluation of deep learning network intrusion
detection systems.** Frontiers in Communications and Networks (2026).
https://www.frontiersin.org/journals/communications-and-networks/articles/10.3389/frcmn.2026.1863367/full
Supports the G5 framing that benchmark metrics diverge from deployment
metrics. **Not yet read** — retrieved from search results only.

**[16] BARS: Benign-Anchored Ranking and Selection for False Alarm Reduction
in Network Intrusion Detection.** arXiv:2607.13203 (2026).
Source of the framing that a sub-1% FPR still yields tens of thousands of
daily alerts in high-volume environments. **Abstract only.**

**[17] Are We Shooting Flies with Cannons? Trade-off Analysis for AI-based 5G
Intrusion Detection.** arXiv:2608.26844 (2026).
Complexity-versus-benefit framing for the efficiency argument. **Abstract
only.**

---

## Reading order before you write

1. [1] in full — it is the backbone of the argument and you should be able to
   defend every number taken from it.
2. [3] in the original — do not inherit a second-hand citation.
3. [4] and [7] — the two methods whose correctness the proposal depends on.
4. [10] — so the related-work section positions grouped tokenisation against
   FT-Transformer honestly rather than claiming novelty it does not have.

Items marked "abstract only" or "not yet read" must be read or dropped. A
reference list padded with unread papers is the fastest way to lose a
reviewer's trust.
