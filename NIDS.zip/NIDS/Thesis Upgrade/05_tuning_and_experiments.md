# 05 — Hyperparameter protocol and experiment plan

---

## 1. Metrics, and which one carries the claim

| Metric | Role |
|---|---|
| **FPR at fixed 95% attack recall** | **Primary.** Carries the >30% claim. The metric with genuine headroom on the reduced task, and the one an operator acts on. |
| **Macro-F1 (grouped split)** | Primary secondary. The academic standard; equal weight to the five small classes. |
| Protocol gap = macro-F1(random) − macro-F1(grouped) | The quantity the invariance mechanism is supposed to shrink. Report it per model. |
| TPR at FPR = 0.1% and 1% | Deployment operating points. |
| Per-class recall, all 10 | Where macro-F1 actually comes from. Never omit. |
| MCC | Robust to imbalance; cheap to add; reviewers in this field ask for it. |
| Params, MACs/sample, ms/batch | Efficiency. Already generated in `../comparison.csv`. |
| Accuracy | Report once, to show it is uninformative at 80.4% BENIGN. Never as a headline. |

**Thresholds are calibrated on the validation split.** A threshold chosen on
test is the most common silent error in this literature and it invalidates
every operating-point number.

---

## 2. Search space, with priors

Optuna TPE, `multivariate=True`, ASHA pruning on validation macro-F1. **60
trials per model, identical budget for every model including the baselines.**
An under-tuned control is how a weak architectural claim survives to
publication.

### Shared across all models

| Parameter | Range | Prior / note |
|---|---|---|
| learning rate | log-uniform 1e-4 … 3e-3 | AdamW; 1e-3 is a good centre for all ten |
| weight decay | log-uniform 1e-6 … 1e-2 | Matters more than usual — the tail classes overfit fast |
| batch size | {512, 1024, 2048, 4096} | 8 GB VRAM is not the constraint; larger batches mostly buy speed |
| epochs | 30, early stop patience 5 on val macro-F1 | These models converge quickly; the tail classes decide when |
| scheduler | {cosine, one-cycle} | Cosine with 5% warmup is the safe default |
| dropout | uniform 0.0 … 0.3 | |
| `tau` (logit adjustment) | uniform 0.0 … 1.0 | **Search it.** `tau=0` is the ablation and must be reachable |
| sampler | {none, sqrt, effective} | `inverse` excluded from the search; run it once as the negative control |
| label smoothing | {0.0, 0.05} | |

### SIGMA-IDS only

| Parameter | Range | Prior / note |
|---|---|---|
| `d_model` | {32, 64, 96} | 64 is the centre; 128 rarely helps at 11 tokens |
| `nhead` | {2, 4, 8} | Head dim ≥ 16 |
| `num_layers` | {1, 2, 3} | 2 is the centre. Depth over 11 tokens saturates fast |
| `dim_feedforward` | {2, 4} x `d_model` | |
| `grl_lambda` | {0, 0.1, 0.3, 0.5, 1.0} | **Report as a curve, not a tuned scalar** — see §4 |
| `n_groups` | {6, 11, 16} | 11 is the semantic partition; the others test the prior |
| `use_gate`, `use_wide_path` | {True, False} | Ablations, not search dimensions — fix True for the main run |
| `proto_scale` init | {5, 10, 20} | Learnable afterwards |

### GRN-MLP (control)

`d_model` {64, 96, 128}, `num_blocks` {2, 3, 4}, `expansion` {1, 2}.
**Constrain the joint choice so the parameter count lands within ±10% of the
tuned SIGMA-IDS**, or print both counts beside every score. At defaults the
control has 310,145 parameters against SIGMA-IDS's 96,946.

### Seeds

5 seeds for every reported configuration; report mean ± std. Do not claim an
ordering that is inside one standard deviation — the gaps between CNN-LSTM and
CNN-GRU on this data routinely are.

---

## 3. Experiment grid

Run in this order. Each stage is a decision point.

**E0 — Baseline re-run (mandatory).** All 8 baselines on the reduced 10-class
task, both protocols, plain CE, default sampler. This is the reference table
and it does not exist yet.

**E1 — Protocol effect.** All 8 baselines, random split vs grouped split.
Deliverable: the protocol-gap column. *This is the figure the paper opens
with.* If the gap is near zero for every model, Protocol B's grouping is too
coarse — sweep `decimals` before concluding there is no leak.

**E2 — Objective effect.** All 8 baselines + GRN-MLP, grouped split, {CE,
logit-adjusted, class-balanced, focal} x {none, sqrt} sampler. Deliverable:
how much of the improvement is the loss. Expect this to be large.

**E3 — Architecture effect.** SIGMA-IDS vs GRN-MLP vs the best baseline,
grouped split, best objective from E2, matched parameters, 5 seeds.
Deliverable: the headline table.

**E4 — Ablations.** `grl_lambda=0` · `use_gate=False` · `use_wide_path=False`
· `tau=0` · contiguous groups instead of semantic · `n_groups ∈ {6, 11, 16}`.
Deliverable: the mechanism attribution. **A proposal without this table is not
a contribution.**

**E5 — Shortcut probes.** (a) Column-shuffle: retrain models 2, 6, 7, 8 on a
fixed random column permutation — if nothing moves, their locality prior is
decorative. (b) Nuisance probe: train a linear classifier on frozen embeddings
to predict port bucket / victim host. SIGMA-IDS's probe accuracy should
approach chance as `grl_lambda` rises; the baselines' should stay high. *This
probe is the most direct evidence for the whole thesis.*

**E6 — Operating points.** ROC and PR curves, TPR at FPR 0.1%/1%, FPR at 95%
recall, thresholds from validation. Deliverable: the >30% number.

**E7 — Cost.** Params, MACs, CPU and GTX 1070 latency, throughput. Mostly
already generated by `core/tools/build_journal_outputs.py`.

**E8 (optional) — Open set.** Hold out one attack family at training time,
score it with `SIGMANet.open_set_score`. Cheap, since the mechanism is already
in the model, and it strengthens the paper considerably.

---

## 4. Reporting `grl_lambda` as a curve

Do not tune `grl_lambda` on validation macro-F1 and report the winner. The
mechanism's whole point is a trade-off, and the trade-off is the result.

Plot, over `grl_lambda ∈ {0, 0.1, 0.3, 0.5, 1.0}`, three lines: random-split
macro-F1, grouped-split macro-F1, and nuisance-probe accuracy. The prediction
is that random-split score declines slightly, grouped-split score rises, and
probe accuracy falls toward chance. If all three move as predicted, the
mechanism is demonstrated, not asserted. If grouped-split score does not rise,
report the negative result — it means the baselines' collapse has a different
cause than shortcut dependence, which is itself worth knowing.

---

## 5. Success criteria — commit to these before running

**Primary (the >30% claim).** Under the grouped split on the reduced 10-class
task, SIGMA-IDS achieves ≥30% relative reduction in FPR at fixed 95% attack
recall versus the strongest of the eight baselines under the same objective
and tuning budget.

**Secondary.** SIGMA-IDS recovers ≥30% of the protocol gap (the macro-F1 drop
each baseline suffers from random to grouped split), and beats GRN-MLP by more
than one standard deviation over 5 seeds at matched parameters.

**Efficiency.** ≤ 1.5 ms per batch of 32 on the GTX 1070 and fewer MACs per
sample than the Transformer baseline. The MAC target is already met by
construction — 847,168 vs 6,675,264, a 7.9x reduction.

**Mechanism.** Nuisance-probe accuracy on SIGMA-IDS embeddings within 10
percentage points of chance at `grl_lambda ≥ 0.3`, while baseline embeddings
stay above 2x chance.

## 6. Kill criteria — and what to do instead

| If | Then |
|---|---|
| E1 shows no protocol gap for any model | The grouping is too coarse. Sweep `decimals ∈ {0,-1,-2}`; if still flat, obtain GeneratedLabelledFlows and run Protocol A before drawing any conclusion. |
| E2 shows the loss alone closes the whole gap | **Pivot the paper.** The contribution becomes "objective and protocol, not architecture, explain deep-NIDS performance on CICIDS2017" — a stronger and more honest result than a 2-point architectural win. |
| E3 shows GRN-MLP ≈ SIGMA-IDS | Report it. Reframe around efficiency and interpretability, which SIGMA-IDS still wins on measured cost. |
| E4 shows no ablation hurts | The components are not doing what the paper claims. Remove them and simplify rather than keeping unjustified machinery. |
| E5 shows shuffled columns do not hurt models 2/6/7/8 | Excellent finding — the convolutional and recurrent NIDS literature on tabular flows rests on a prior that is not there. That result can carry a paper by itself. |

A pre-registered pivot is not a failure. Deciding what would change your mind
before you look at the numbers is what makes the numbers worth anything.

---

## 7. Ten-day schedule (single GTX 1070)

| Day | Work |
|---|---|
| 1 | Preprocess to the 10-class set; build both grouping protocols; publish the leakage report |
| 2 | E0 — baseline re-run, random split |
| 3 | E1 — baseline re-run, grouped split; produce the protocol-gap figure |
| 4 | E2 — objective sweep |
| 5–6 | E3 — tune SIGMA-IDS and GRN-MLP, 60 trials each, matched parameters |
| 7 | E4 — ablations, 5 seeds |
| 8 | E5 — shortcut probes; the `grl_lambda` curve |
| 9 | E6/E7 — operating points and cost; assemble tables and figures |
| 10 | Write-up; run the kill-criteria checklist before claiming anything |

These models are small — minutes per epoch, not hours. Preprocessing and
tuning dominate the wall clock, not training. If epochs still feel slow, set
`PreprocessConfig(benign_cap=500_000)` and report the cap.
