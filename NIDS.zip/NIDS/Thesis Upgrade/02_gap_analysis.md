# 02 — Gap analysis

Five gaps. Each is stated as a claim, backed by evidence, and paired with the
mechanism that addresses it. A gap without a mechanism is a complaint; a
mechanism without a gap is decoration.

---

## G1 — Evaluation protocol: the benchmark rewards memorisation

**Claim.** Reported CICIDS2017 scores in the 0.99 range are not
generalisation estimates. They are inflated by duplicate and near-duplicate
flows straddling the train/test boundary.

**Evidence.** A 2026 re-evaluation of nine models on CIC-IDS2017 compared a
stratified random split against a group-by-five-tuple split. The Transformer
fell from 0.775 to 0.549 macro-F1 and its false-alarm rate rose 67-fold
(0.04% → 2.7%); the LSTM, GRU and 1D-CNN each lost 0.02–0.03; the Random
Forest gained 0.009. The same study found a chronological split to be
*degenerate* on this dataset — attacks are scheduled one family per day, so a
time cut leaves only 2 of 13 classes in the test window — which rules out the
obvious alternative fix.

**Why it matters more than anything else here.** Nothing in an architecture
can be evaluated on a protocol that does not distinguish memorisation from
generalisation. This gap has to be closed first or the other four cannot be
measured.

**Mechanism.** `core/common/protocol.py`: grouped splitting with a proof
(`leakage_report` counts groups shared across folds and must print zero).
Protocol A groups by five-tuple where the identifier columns are available;
Protocol B, for the `ml.csv` distribution which has them stripped, groups by
rounded feature signature so near-identical flows cannot straddle.

---

## G2 — Shortcut dependence: the models learn the testbed, not the attack

**Claim.** The deep baselines' random-split advantage comes substantially
from features that identify the CICIDS2017 testbed rather than the attack
behaviour, which is why they collapse under grouping while a Random Forest
does not.

**Evidence.** The same study documents a "destination-port-shortcut
overfitting" issue and cites Engelen et al. (2021) on label noise and
flow-construction artefacts in this dataset. Its padding ablation is the
sharper result: swapping repeat-last padding for zero-padding with an explicit
mask cost the LSTM and GRU about 0.02 macro-F1 but cost the Transformer 0.243.
Self-attention had latched onto an artefact of the input encoding. That is the
same failure mode as a port shortcut, caught in the act.

**Why dropping the column is not enough.** Destination port is correlated with
header lengths, initial TCP window sizes, minimum segment size and packet-size
modes. Remove the port column and a sufficiently flexible model reconstructs
it. The leak has to be attacked at the representation, not the input.

**Mechanism.** A gradient-reversal head in `SIGMANet` trained to predict a
nuisance variable (port bucket, victim host, capture day) from the pooled
embedding. The reversed gradient makes the encoder actively destroy that
information. Ablate with `grl_lambda=0`.

---

## G3 — Token granularity: attention is applied at the wrong scale

**Claim.** Feature-as-token attention over 78 columns pays quadratic cost for
a factorisation the data does not have, and produces attention maps nobody can
read.

**Evidence.** Measured on the baselines in this project: the Transformer needs
6,675,264 MACs per sample against the ANN's 54,656 — 122x — for no consistent
accuracy gain. In the published comparison the LSTM matched the Transformer's
random-split macro-F1 at 13x lower latency (0.13 ms vs 1.73 ms per sample on
an A100), and Random Forest matched both. Separately, an evaluation of modern
tabular representation learning across three NetFlow datasets found no
representation-classifier combination dominating: an end-to-end attention
model tied with autoencoder-plus-SVM and with TabICL-plus-Random-Forest.

**The structural fact behind it.** The 78 columns are ~11 semantic families —
duration, forward volume, backward volume, rates, three IAT families, flags,
headers/window, size statistics, active/idle. Verified against the actual
CICIDS2017 header in `core/common/feature_groups.py`.

**Mechanism.** Grouped tokenisation: one token per family. 11x11 attention
instead of 78x78 — about 50x fewer pairs — and an attention map whose axes are
words a SOC analyst already uses. Measured cost of the result: 847,168
MACs/sample and 3.53 ms per batch of 32, against the Transformer baseline's
6,675,264 and 8.08 ms.

---

## G4 — Long-tail objective: the loss is biased before training starts

**Claim.** Under a 1,156:1 prior, plain cross-entropy is a biased estimator of
the balanced error the macro-F1 metric actually rewards, and the common
remedies are worse than the principled one.

**Evidence.** Rare-class failure is systematic, not model-specific. The
tabular representation-learning study reports macro-F1 of 0.29–0.49 across all
methods and all three datasets while binary F1 sits near 0.88, and finds
Backdoor, Worms, Bot, Infiltration and SQL Injection "largely undetectable"
regardless of representation. The problem is the objective and the prior, not
the encoder.

**Why the usual fixes underperform.** Inverse-frequency reweighting inflates
the gradient variance of exactly the classes with the least data. Full
resampling oversamples Bot's 1,966 flows ~1,156x per epoch and memorises them.
Both change the loss surface at training time and leave the decision rule
uncorrected.

**Mechanism.** Logit adjustment — add `tau * log(prior)` to the logits during
training only (`core/common/balancing.py`). It is Bayes-consistent for label
shift, costs nothing at inference, and reduces to plain cross-entropy at
`tau=0`, so it ablates with one scalar. Paired with a cosine prototype head,
which is better conditioned than a linear head when class frequencies span
three orders of magnitude, and square-root sampling rather than full balancing.

---

## G5 — Operating point: macro-F1 is not the deployment metric

**Claim.** A model selected on macro-F1 can be unusable in a SOC, and the
baselines are not evaluated at any stated operating point.

**Evidence.** The Transformer's grouped-split false-alarm rate of 2.7% sounds
small. On the CICIDS2017 volume of 2.83M flows it is roughly 61,000 false
alerts. Published work on alert-volume reduction observes that even a sub-1%
false positive rate produces tens of thousands of daily alerts in high-volume
environments — the reason false alarms, not missed detections, are the usual
barrier to deployment.

**Mechanism.** Report **TPR at fixed FPR** (0.1% and 1%) and **FPR at fixed
95% attack recall** alongside macro-F1, with the threshold calibrated on the
validation split and never on test. This is also the primary metric for the
>30% claim, because it is the one with genuine headroom on the reduced task
and the one an operator cares about. `SIGMANet.open_set_score` provides a
per-sample confidence for the same thresholding machinery.

---

## Gap-to-mechanism map

| Gap | Mechanism | Where | Ablation that isolates it |
|---|---|---|---|
| G1 protocol leakage | grouped split + leakage proof | `core/common/protocol.py` | random split vs grouped split, all models |
| G2 shortcut dependence | gradient-reversal nuisance head | `SIGMANet(grl_lambda=...)` | `grl_lambda=0` |
| G3 token granularity | ~11 semantic family tokens | `core/common/feature_groups.py` | contiguous-block groups; `n_groups` sweep |
| G4 long-tail objective | logit adjustment + prototype head | `core/common/balancing.py` | `tau=0`; `cosine_head=False` |
| G5 operating point | FPR-at-recall reporting | `05_tuning_and_experiments.md` | threshold on val vs on test |

Two of the five — G1 and G4 — are not architectural. They are applied
identically to all ten models, which is exactly what makes the remaining
margin attributable to G2 and G3. That is the point of including GRN-MLP as a
control: it receives G1 and G4 and nothing else.
