# 04 — Class reduction, leakage-free splitting, and balancing

Implementation: [`../core/common/protocol.py`](../core/common/protocol.py) ·
[`../core/common/balancing.py`](../core/common/balancing.py) ·
[`../core/common/preprocessing.py`](../core/common/preprocessing.py)

---

## 1. The reduced 10-class task

You chose to remove the payload-based and ultra-rare classes. That is
defensible, and the argument has to be about the data — a reviewer reads
class removal as a convenience until shown otherwise.

**Kept — 10 classes, 2,828,516 flows, 99.921% of the dataset.**

| Class | Flows | Share of kept |
|---|---|---|
| BENIGN | 2,273,097 | 80.364% |
| DoS Hulk | 231,073 | 8.169% |
| PortScan | 158,930 | 5.619% |
| DDoS | 128,027 | 4.526% |
| DoS GoldenEye | 10,293 | 0.364% |
| FTP-Patator | 7,938 | 0.281% |
| SSH-Patator | 5,897 | 0.208% |
| DoS slowloris | 5,796 | 0.205% |
| DoS Slowhttptest | 5,499 | 0.194% |
| Bot | 1,966 | 0.070% |

**Removed — 5 classes, 2,227 flows, 0.079%.**

| Class | Flows | The argument |
|---|---|---|
| Web Attack: Brute Force | 1,507 | Payload-defined. CICFlowMeter emits no payload information, so the class is not identifiable from these columns *by construction* — only via coarse timing/volume side-effects. |
| Web Attack: XSS | 652 | Same, and mutually inseparable from the other two Web Attack classes: all three are HTTP POST bursts to the same victim on the same port in the same capture window. |
| Web Attack: SQL Injection | 21 | Same, plus a stratified 20% test fold receives 4 flows. Any per-class F1 has a confidence interval wider than the metric. |
| Infiltration | 36 | The class most affected by the flow-construction and labelling errors documented by Engelen et al. (2021). A 7-flow test fold cannot support a claim. |
| Heartbleed | 11 | 11 flows from a single victim host; 2 in a 20% test fold. Note that published work reporting hundreds of Heartbleed flows is not using the standard distribution. |

The removal argument is **representational for the Web Attack classes**
(the feature set cannot express what distinguishes them) and **statistical for
Infiltration and Heartbleed** (the test fold is too small for the metric to
mean anything). Those are different arguments and the paper should make both,
not blur them into "we dropped the rare classes".

`python -c "from core.common.protocol import reduction_summary; print(reduction_summary())"`
prints this table with the justifications, so the methodology section and the
code cannot drift apart.

### Three things you must do because of the reduction

1. **Re-run all eight baselines on the 10-class set.** Comparing a 10-class
   proposal against 15-class published numbers is not a comparison. The
   baselines are the reference and they have to be measured on the same task.
2. **Say the task is easier.** Removing the four hardest classes raises every
   score. State the kept/removed counts in the abstract, not a footnote.
3. **Do not compare macro-F1 across the two class sets, ever.** Macro-F1 is an
   average over classes; changing the denominator changes the metric.

---

## 2. Leakage-free splitting — the change that creates the headroom

### Protocol A — group by five-tuple (preferred)

Group id per (srcIP, dstIP, srcPort, dstPort, proto) conversation, split by
group. Requires the **GeneratedLabelledFlows** distribution of CICIDS2017,
which carries Flow ID, IPs, ports and timestamps.

> **Practical note.** The `MachineLearningCSV` / `MachineLearningCVE`
> distribution that `ml.csv` comes from has already stripped those columns —
> its first column is Destination Port. If `ml.csv` is all you have, Protocol A
> is not available and you should either fetch GeneratedLabelledFlows (you
> already hold raw CICIDS2017 material) or run Protocol B and say so.

### Protocol B — group by feature signature (ml.csv fallback)

`signature_groups(X_raw, decimals)` rounds the raw feature matrix and gives
every distinct rounded row a group id. Exact duplicates always share a group;
with `decimals=-1` or `-2` so do flows differing only by measurement jitter.
This does not reconstruct conversations, so it is strictly weaker than
Protocol A — but it closes the specific leak that inflates this dataset most.
Run `decimals ∈ {0, -1, -2}` as a sensitivity analysis and report all three.

### Why not a chronological split

The obvious alternative fails on this dataset. Attacks are scheduled one
family per day, so a train-early/test-late cut leaves entire classes on one
side; a published attempt found only 2 of 13 classes surviving in the test
window. Use day grouping for a targeted same-family-different-day holdout, not
as the main split. `day_groups()` supports that if you kept the source
filename when concatenating the eight CSVs.

### Prove it, do not assert it

`grouped_split` uses `StratifiedGroupKFold`, and `leakage_report` counts
groups shared across folds:

```
train n val overlap    : 0
train n test overlap   : 0
val   n test overlap   : 0
VERDICT: no group crosses a fold — clean.
```

Put that block in the paper. It converts a methodological claim into a
verifiable one. `grouped_split` also warns if grouping starves a class out of
a fold — do not report macro-F1 from a split that warned.

---

## 3. Preprocessing already in place

`core/common/preprocessing.py` (unchanged by this upgrade) handles: parse-time
dropping of identifier and port columns, float32 + chunked reading, ±inf/NaN
repair on `Flow Bytes/s` and `Flow Packets/s`, exact-duplicate row removal
*before* splitting, constant/duplicate/collinear column pruning, the canonical
label map including the `\x96` en-dash in the Web Attack labels, a
train-only scaler fit, and an `.npy` cache keyed by a hash of the config.

One addition worth making for this study: **keep the raw, unscaled matrix**
alongside the transformed one. Protocol B's signature grouping and the
flow-invariant check both operate on raw values — neither identity survives a
quantile transform.

---

## 4. Balancing: what to use, in order

| Method | Where | When |
|---|---|---|
| `LogitAdjustedLoss(counts, tau)` | `balancing.py` | **Default.** Bayes-consistent for label shift, free at inference, `tau=0` recovers plain CE so it ablates with one scalar. |
| `sampling_weights(..., "sqrt")` | `balancing.py` | Default sampler. Partial rebalancing. |
| `ClassBalancedLoss(counts, beta)` | `balancing.py` | Effective-number reweighting, for comparability with reweighted baselines. |
| `FocalLoss(gamma)` | `balancing.py` | Completeness. Weakest of the three in the ablation ordering. |
| `manifold_mixup(h, y, C, alpha)` | `balancing.py` | Minority augmentation in embedding space. |
| `sampling_weights(..., "inverse")` | `balancing.py` | The ablation that shows why full balancing is wrong here — it oversamples Bot ~1,156x per epoch. |

### Why raw-space SMOTE invalidates a result on this dataset

CICFlowMeter columns are not free coordinates; they satisfy arithmetic
identities. `Total Length of Fwd Packets = Total Fwd Packets x Fwd Packet
Length Mean`. `Min <= Mean <= Max`. Packet counts are non-negative integers.
`Flow Bytes/s = total bytes / duration`. Interpolating between two real flows
breaks all of them simultaneously.

`flow_invariant_violations()` measures the residual. On a synthetic
demonstration with 500 flows constructed to satisfy the identities exactly,
against SMOTE-style interpolation of the same rows:

| Check | Real flows | SMOTE-interpolated |
|---|---|---|
| `flow_bytes/s != total_bytes / duration` | 0.00% | **83.60%** |
| `fwd: bytes != packets x mean_len` | 0.00% | **76.80%** |
| `bwd: bytes != packets x mean_len` | 0.00% | **76.80%** |
| `fwd/bwd: packet count non-integer` | 0.00% | **50.00%** |

A classifier can separate synthetic from real using constraint residuals alone.
Minority-class recall measured on such data is partly the model's ability to
recognise SMOTE, which no attacker will ever emit.

**What to do instead.** Prefer `manifold_mixup` — interpolating a learned
embedding cannot violate an identity that is not defined in that space. If you
do generate raw-space samples (SMOTE, CTGAN, TVAE), run
`report_violations()` on both the real training split and the synthetic set
and publish both columns. The real rate is not exactly zero — CICFlowMeter has
rounding and documented bugs — so the standard is "synthetic does not exceed
real", not "synthetic is zero". Reject any generator that fails it.

This check is, on its own, a small methodological contribution: the NIDS
oversampling literature is large and this validity gate is not standard
practice in it.
