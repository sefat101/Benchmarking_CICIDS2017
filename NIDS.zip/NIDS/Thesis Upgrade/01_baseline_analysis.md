# 01 — Baseline analysis

What the eight models in `../01_ann/` … `../08_cnn_gru/` actually are, what
limits each, and what that implies for the upgrade. Parameter, MAC and latency
figures are measured (`../comparison.csv`), taken at F=78, C=15, batch 32, CPU.

---

## 1. The eight, by inductive bias

| # | Model | Prior over the feature axis | Params | MACs/sample | ms/batch-32 |
|---|---|---|---|---|---|
| 1 | ANN | none (permutation-agnostic) | 55,055 | 54,656 | 0.13 |
| 2 | 1D-CNN | locality between adjacent columns | 7,311 | 248,064 | 0.75 |
| 3 | Autoencoder | benign traffic lies on a low-dim manifold | 14,318 | 14,080 | 0.11 |
| 4 | Encoder | as above, evaluated as a representation | 7,136 | 7,040 | 0.06 |
| 5 | Transformer | full pairwise interaction, 78 tokens | 73,231 | 6,675,264 | 8.08 |
| 6 | CNN-RNN | locality, then ordered recursion | 15,631 | 567,552 | 1.81 |
| 7 | CNN-LSTM | as above, gated | 40,591 | 1,526,016 | 2.10 |
| 8 | CNN-GRU | as above, two gates | 32,271 | 1,206,528 | 4.11 |

Three of these priors are, on inspection, not true of the data.

**Models 2, 6, 7 and 8 assume the feature axis has meaningful locality.** It
does not, except by accident: adjacent columns are related only because
CICFlowMeter happens to emit related statistics next to each other. The
correct test is a column-shuffle ablation — retrain on a fixed random
permutation of the columns. If the score does not move, the convolution has
degenerated into a weight-shared MLP and the "spatial extraction" framing in
the paper is not supported.

**Models 6, 7 and 8 additionally assume an ordered sequence.** There is no
temporal axis in a per-flow tabular row. The 39 "time steps" are pooled
convolutional positions along the feature axis. Several published NIDS papers
apply recurrence to flow rows without acknowledging this; a reviewer who knows
the dataset will look for the acknowledgement.

**Model 5 assumes 78 independent tokens.** The 78 columns are a dozen
statistical summaries of a handful of underlying signals — forward sizes,
backward sizes, inter-arrival times, flags. Attending over them pairwise costs
6,084 pairs and 6.68M MACs per sample, 122x the ANN, for a prior that
over-counts the true number of degrees of freedom by roughly sevenfold.

Models 1, 3 and 4 impose priors that are defensible. That is precisely why the
ANN is so hard to beat here, and why it belongs in the results table as the
control rather than as a strawman.

---

## 2. The measurement problem is larger than the architecture problem

The eight baselines will not separate cleanly on the reduced 10-class task
under a stratified random split, because that protocol does not measure
generalisation on this dataset.

CICIDS2017 contains a very large fraction of duplicate and near-duplicate
flows. A stratified random split assigns them independently, so a flow in the
test set frequently has an identical or near-identical twin in training. The
model does not need to generalise; it needs to remember. The preprocessing
pipeline in `core/common/preprocessing.py` already removes *exact* duplicates
before splitting, which is necessary and not sufficient — near-duplicates from
the same conversation survive.

The most direct published measurement of the size of this effect re-ran nine
models on CIC-IDS2017 under three protocols. Moving from a stratified random
split to a group-by-five-tuple split:

| Model | macro-F1 random | macro-F1 grouped | Δ |
|---|---|---|---|
| Random Forest | 0.769 | **0.778** | +0.009 |
| LSTM | 0.776 | 0.753 | −0.023 |
| GRU | 0.762 | 0.736 | −0.027 |
| 1D-CNN | 0.754 | 0.733 | −0.021 |
| Transformer | 0.775 | **0.549** | **−0.226** |

and the Transformer's false-alarm rate went from 0.04% to 2.7% — a 67-fold
increase, while the Random Forest's stayed flat (0.16% → 0.14%).

Two things follow, and they set up the whole upgrade.

**First, the ranking you would report from a random split is not the ranking
that survives.** The Transformer looks competitive under the random split and
is the worst model under the grouped one. If your thesis compares eight
architectures on a random split, it is comparing their capacity to memorise.

**Second, the deep models are riding something that the grouping removes.**
That "something" has a name in this dataset: testbed fingerprints. Each attack
was run from fixed hosts against fixed services in a fixed window, so
destination port, header lengths, initial window sizes and packet-size modes
carry identity information that a real deployment will not reproduce. Dropping
the port column — which the preprocessing already does — is necessary and, again,
not sufficient, because port information leaks back through the correlated
header and window columns.

---

## 3. Where the class structure actually hurts

On the reduced 10-class set (see [04](04_balancing_and_preprocessing.md)):

| Class | Flows | Share |
|---|---|---|
| BENIGN | 2,273,097 | 80.364% |
| DoS Hulk | 231,073 | 8.169% |
| PortScan | 158,930 | 5.619% |
| DDoS | 128,027 | 4.526% |
| DoS GoldenEye | 10,293 | 0.364% |
| FTP-Patator | 7,938 | 0.281% |
| SSH-Patator | 5,897 | 0.208% |
| DoS slowloris | 5,796 | 0.205% |
| DoS Slowhttptest | 5,499 | 0.194% |
| Bot | 1,966 | 0.070% |

Imbalance ratio 1,156:1. Four classes hold under 0.3% of the rows each, and
macro-F1 gives each of them a tenth of the weight. So macro-F1 on this task is
mostly a measurement of five small classes — which is the right thing to
measure, and also why accuracy must not appear as a headline number.

Two consequences for the design:

- Plain softmax cross-entropy under a 1,156:1 prior is biased toward BENIGN by
  construction. Fixing this is a loss-function change, not an architecture
  change, and it will move macro-F1 more than swapping CNN for LSTM does.
  Applying it uniformly to all ten models is therefore mandatory, or the
  comparison measures the loss function rather than the architecture.
- Bot's 1,966 flows are the binding constraint on any resampling scheme. Full
  inverse-frequency balancing oversamples it roughly 1,156x per epoch, which
  memorises those 1,966 rows and inflates validation while doing nothing for a
  grouped test split.

---

## 4. What the baselines are missing, in one line each

| # | Model | Binding limitation |
|---|---|---|
| 1 | ANN | No mechanism for feature interaction beyond what a dense layer learns implicitly; nothing resists shortcuts. |
| 2 | 1D-CNN | Assumes a locality that only holds by column-ordering accident. |
| 3 | Autoencoder | Reconstruction error is not attack-specific; benign heavy tails produce large residuals of their own. |
| 4 | Encoder | Unsupervised representation carries no class structure; the linear probe is weak on rare classes. |
| 5 | Transformer | Wrong token granularity — 78 tokens for ~11 degrees of freedom, at 122x the ANN's compute, and the most shortcut-dependent model of the eight. |
| 6 | CNN-RNN | Ungated recursion over a synthetic 39-step sequence; shortest effective memory. |
| 7 | CNN-LSTM | Best of the recurrent three, but the sequence it recurses over is not a sequence. |
| 8 | CNN-GRU | As above, cheaper; the gap to LSTM is usually inside seed noise. |

**Common to all eight:** trained with an uncorrected objective under a 1,156:1
prior, evaluated on a protocol that rewards memorisation, with no term
anywhere that penalises dependence on testbed identity.

The upgrade in [03](03_architecture.md) attacks the last three items — token
granularity, shortcut dependence, and the long-tail objective — and
[04](04_balancing_and_preprocessing.md) fixes the protocol so the improvement
can be seen.
