# 03 — SIGMA-IDS

**S**hortcut-**I**nvariant **G**rouped **M**ulti-head **A**ttention for
intrusion detection.

Implementation: [`../core/models/sigma.py`](../core/models/sigma.py) ·
artefacts: [`../09_sigma/`](../09_sigma/) · control:
[`../core/models/gated_mlp.py`](../core/models/gated_mlp.py)

![SIGMA-IDS](figures/sigma_architecture.svg)

---

## 1. One paragraph

SIGMA-IDS replaces the two assumptions that make the Transformer baseline both
expensive and fragile. Instead of treating the 78 flow statistics as 78
independent tokens, it encodes them as ~11 semantic family tokens, gates those
families sparsely per sample, and attends over the 11 — cutting the pairwise
cost about fiftyfold and making the attention map readable. Instead of hoping
the model ignores testbed fingerprints, it trains a nuisance head behind a
gradient-reversal layer to predict destination-port bucket, victim host or
capture day from the pooled embedding, so the encoder is pushed to destroy
that information. A wide residual path preserves the axis-aligned rules that
make tree ensembles strong on this data, and a cosine prototype head paired
with a logit-adjusted objective handles the 1,156:1 prior and yields an
open-set score for free.

Measured at F=78, C=15: **96,946 parameters, 847,168 MACs per sample, 3.53 ms
per batch of 32 on CPU** — against the Transformer baseline's 73,231 /
6,675,264 / 8.08 ms. Same order of parameters, **7.9x fewer MACs, 2.3x lower
latency.**

---

## 2. Data flow, step by step

A batch arrives as `[B, F]` — the same raw 2D tabular batch every baseline
takes. No collate function, no wrapper.

**Step 1 — Group gather.** `build_groups(input_dim, feature_names)` partitions
the column indices into families by matching normalised column names. On the
real CICIDS2017 header (76 columns after dropping Destination Port) this
yields exactly 11 groups:

| Group | Cols | Example members |
|---|---|---|
| duration | 1 | Flow Duration |
| iat flow | 4 | Flow IAT Mean / Std / Max / Min |
| iat fwd | 5 | Fwd IAT Total / Mean / Std / Max / Min |
| iat bwd | 5 | Bwd IAT Total / Mean / Std / Max / Min |
| flags | 12 | FIN/SYN/RST/PSH/ACK/URG/CWE/ECE counts, Fwd/Bwd PSH & URG |
| headers/win | 6 | Fwd/Bwd Header Length, Init_Win_bytes_*, act_data_pkt_fwd, min_seg_size |
| rates | 5 | Flow Bytes/s, Flow Packets/s, Fwd/Bwd Packets/s, Down/Up Ratio |
| fwd volume | 12 | Total Fwd Packets, Fwd Packet Length Max/Min/Mean/Std, Subflow Fwd, Avg Fwd Segment |
| bwd volume | 12 | mirror of the above |
| size stats | 6 | Min/Max Packet Length, Packet Length Mean/Std/Variance, Average Packet Size |
| active/idle | 8 | Active Mean/Std/Max/Min, Idle Mean/Std/Max/Min |

Columns matching nothing land in an explicit `misc` group — never silently
dropped. Without `feature_names` the model falls back to contiguous blocks;
that path compiles and trains but discards the prior the design rests on, so
it is the smoke-test configuration only.

**Step 2 — Per-family encoding.** Family *j* with *n_j* columns gets its own
`Linear(n_j, d) -> LayerNorm -> GELU`, producing one token. A learnable group
embedding `[1, G, d]` is added, so the model knows which family a token is.
Output `[B, 11, 64]`.

**Step 3 — Sparse group gate.** A scalar score per token, then **sparsemax**
over the 11. Sparsemax, unlike softmax, assigns exact zeros — which is what
makes "this alert used the flag and backward-IAT families and nothing else" a
true statement rather than a heat-map with small numbers in it. Tokens are
scaled by `G * alpha_j` so the gate re-weights rather than shrinks. In the
smoke test a typical row activates 5 of 11 groups and the weights sum to 1.

**Step 4 — Attention.** A `[CLS]` token is prepended and two pre-norm encoder
blocks run over the 12 positions, 4 heads. Pre-norm because 2-layer post-norm
stacks need a warm-up schedule to converge; state that in the paper as a
deliberate deviation.

**Step 5 — Wide residual path.** `Linear(F, 128) -> GELU -> Dropout ->
Linear(128, 64)` over the raw vector, summed into the pooled `[CLS]` output.
Tree ensembles beat attention on this feature set, which is evidence that
simple axis-aligned rules carry a lot of the signal; forcing them through
attention is a needless bottleneck. Ablate with `use_wide_path=False` to see
what attention is contributing on its own.

**Step 6 — Cosine prototype head.** Class prototypes on the unit sphere,
learnable scale:

```
z_c = s * cos(h, p_c)
```

Better conditioned than a linear head when frequencies span three orders of
magnitude, and `1 - max_c cos(h, p_c)` is an open-set score at zero extra cost.

**Step 7 — Nuisance head (training only).** The pooled embedding passes
through a gradient-reversal layer into a small classifier predicting the
nuisance bucket. Forward pass unchanged; the reversed gradient makes the
encoder minimise what the head can recover. At inference this branch is not
evaluated.

---

## 3. Objective

```
L = CE(z + tau * log(pi), y)  -  lambda * CE(psi(h), d)
```

- `pi` — training class prior; `tau` in [0.25, 1.0], `tau=0` recovers plain CE.
- `d` — nuisance label (port bucket / victim host / capture day).
- `lambda` — realised by the gradient-reversal layer, so one forward pass
  suffices. Ramp it from 0 to its target over the first ~5 epochs; applying
  full reversal from step 0 destabilises the encoder before it has learned
  anything worth making invariant.

The nuisance labels come from columns deliberately excluded from the model
input. They must be carried alongside `X` through the split and never fed to
the encoder — `core/common/protocol.py` provides `port_domain_labels` and
`hash_domain_labels` for constructing them.

---

## 4. What each piece is claimed to fix

| Component | Gap | Ablation | If the ablation does not hurt |
|---|---|---|---|
| Grouped tokenisation | G3 | `n_groups` sweep; contiguous blocks | The semantic prior is not doing work — report that; the cost win stands on its own |
| Sparsemax gate | G3 (interpretability) | `use_gate=False` | Drop it. It is only justified if it either helps or explains |
| Gradient-reversal head | G2 | `grl_lambda=0` | The shortcut hypothesis is wrong for your split — a genuinely interesting negative result |
| Wide residual path | G3 (tabular prior) | `use_wide_path=False` | Attention alone suffices; simplify |
| Cosine prototype head | G4 | `cosine_head=False` | Linear head is fine; keep the simpler one |
| Logit adjustment | G4 | `tau=0` | Your sampler is already doing the work |

Every row has a falsifier. That is the difference between a proposal and a
list of components.

---

## 5. Honest risks

**The control may win.** GRN-MLP receives the leakage-free protocol and the
logit-adjusted loss and nothing else. On CICIDS2017-style features, tuned
tree ensembles and well-regularised MLPs are repeatedly reported at or above
attention models; in the published nine-model comparison the Random Forest was
the most robust model overall under the grouped split. If GRN-MLP matches
SIGMA-IDS, the finding is that protocol and objective explain the gains — a
real result, and a more useful one than a marginal architectural win. Report
it rather than tuning until the expected ordering appears.

**Invariance can cost accuracy.** Destroying nuisance information removes
genuinely predictive signal along with the shortcut, because on this testbed
the two are entangled. Expect random-split macro-F1 to fall slightly as
`grl_lambda` rises while grouped-split macro-F1 rises. That crossover *is* the
result — plot it as a curve over `grl_lambda ∈ {0, 0.1, 0.3, 0.5, 1.0}` and
make it a figure.

**Grouping is a prior, not a fact.** The 11 families come from CICFlowMeter's
documented semantics, not from the data. Report the `n_groups` sweep and the
`misc`-group size so a reader can judge how much of the partition is real.

**Sparsemax gates are not free explanations.** A sparse gate says which family
the model used, not why that family is evidence of an attack. Do not overclaim
in the interpretability section; pair the gate figure with per-class gate
distributions so the reader can check the story against the attack semantics.

**Parameter parity is not automatic.** At the defaults GRN-MLP has 310,145
parameters against SIGMA-IDS's 96,946. Constrain `d_model` and `num_blocks`
during tuning so the two land within ~10%, or print both counts beside every
score.
