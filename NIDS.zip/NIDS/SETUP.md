# Setup — Windows + GTX 1070

Follow this once. Everything is run from the project root (`E:\NIDS`), never
from inside `core\`, so that `core` resolves as a Python package.

---

## 0. The one thing that will bite you

The GTX 1070 is **Pascal, compute capability `sm_61`**. PyTorch removed
Maxwell / Pascal / Volta kernels from its CUDA 12.8 and 12.9 wheel builds
starting with release 2.8 — and the **CUDA 12.6 (`cu126`) line is the last one
that still carries them**. Those cu126 wheels are published up to and including
PyTorch 2.14; from 2.15 they are gone entirely.

So the default `pip install torch` (which pulls the newest CUDA build) gives
you a wheel with **no kernels for your card**. It imports fine,
`torch.cuda.is_available()` even returns `True`, and then the first real
operation dies with:

```
CUDA error: no kernel image is available for execution on the device
```

Install from the `cu126` index and you avoid the whole problem.

---

## 1. Python

Use **Python 3.11 or 3.12** — those have `cu126` wheels for Windows.
Check what you have:

```bat
py -0p
```

If you don't have 3.11/3.12, install one from python.org, then use `py -3.12`
below in place of `py`.

---

## 2. Virtual environment

```bat
cd /d E:\NIDS
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
```

Your prompt should now start with `(.venv)`. Note `.venv` is already in
`.gitignore`.

---

## 3. Install PyTorch — the cu126 build

Do this **before** `requirements.txt`, so pip doesn't resolve a default-index
torch first:

```bat
pip install torch --index-url https://download.pytorch.org/whl/cu126
```

Then everything else (plain PyPI):

```bat
pip install -r core\requirements.txt
```

If pip complains that torch is already satisfied, that's fine — the cu126
build stays.

**CPU-only alternative.** These models are small enough that CPU training is
viable if the GPU gives you trouble. Swap step 3 for
`pip install torch --index-url https://download.pytorch.org/whl/cpu`.

---

## 4. Verify the environment

```bat
python core\tools\check_env.py
```

You want to see:

```
GPU           : NVIDIA GeForce GTX 1070
Capability    : sm_61  (Pascal)
VRAM          : 8.0 GB
Wheel kernels : sm_50, sm_60, sm_61, sm_70, sm_75, sm_80, sm_86, sm_90
GPU matmul    : OK  (checksum ...)
```

The `Wheel kernels` line must contain `sm_61`. The script also launches a real
matmul on the GPU, because the availability flag alone will lie to you.

If `nvidia-smi` doesn't run at all, update your NVIDIA driver first — CUDA 12.6
wheels need a reasonably current Pascal driver.

---

## 5. Smoke-test the models

```bat
python core\verify_all.py
```

Expected — eight rows, then `All 8 architectures compiled and produced finite
outputs.` This runs on CPU with a dummy tensor; it does not touch the GPU or
your data.

---

## 6. Regenerate the artefacts (optional)

```bat
python core\tools\build_journal_outputs.py
```

Rewrites `01_ann\ … 08_cnn_gru\` plus `comparison.csv`, `comparison.md` and
`verification_log.txt`. Run it any time you edit a model in `core\models\`.

---

## 7. Point the pipeline at your data

Put the CICIDS2017 `ml.csv` in `E:\NIDS\data\`. Then, from the project root:

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import CNNLSTM

cfg    = PreprocessConfig(csv_path="data/ml.csv", cache_dir="data/cache")
prep   = CICIDS2017Preprocessor(cfg)
bundle = prep.run()          # first call parses the CSV; later calls hit the cache
print(prep.summary(bundle))  # this block goes straight into the paper

train_dl, val_dl, test_dl = prep.make_dataloaders(bundle, batch_size=1024)
model = CNNLSTM(input_dim=bundle.input_dim, num_classes=bundle.num_classes).cuda()
```

Forward slashes work fine in Python on Windows. If you prefer backslashes, use
raw strings: `r"data\ml.csv"`.

The first run writes `data\cache\<hash>\` — cleaned `.npy` arrays, the fitted
scaler and a manifest. Delete that folder any time; it rebuilds. Changing any
`PreprocessConfig` field changes the hash, so you get a fresh cache
automatically instead of silently reusing stale arrays.

---

## 8. Practical notes for this card

**Batch size.** 8 GB is far more than these models need — the largest is 73k
parameters. `batch_size=1024` is comfortable; 4096 also fits and will cut
epoch time. The memory ceiling here is the batch tensor, not the model.

**Don't bother with AMP.** Pascal has no tensor cores, so `torch.amp` /
fp16 buys little and is sometimes slower. Train in fp32. TF32 does not exist
on this architecture either, so ignore any `torch.set_float32_matmul_precision`
advice written for Ampere and later.

**DataLoader workers.** `num_workers` defaults to `0` — correct here, because
the batches come from an in-memory `TensorDataset` where worker processes only
add IPC overhead. If you ever raise it on Windows, you **must** wrap your entry
code in `if __name__ == "__main__":`, or each worker re-imports your script and
the run crashes.

**Where the time actually goes.** Preprocessing dominates the first run;
training these models is minutes, not hours. If epochs still feel slow, set
`PreprocessConfig(benign_cap=500_000)` — BENIGN is roughly 80% of CICIDS2017,
and capping it is the single largest saving available.

---

## Command summary

```bat
cd /d E:\NIDS
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install torch --index-url https://download.pytorch.org/whl/cu126
pip install -r core\requirements.txt
python core\tools\check_env.py
python core\verify_all.py
```

Every later session just needs `cd /d E:\NIDS` and `.venv\Scripts\activate`.
