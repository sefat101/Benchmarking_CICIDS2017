# 01_ann — ANN

**Artificial Neural Network (Multi-Layer Perceptron)** · family: *Fully-connected*

Densely connected reference baseline; treats the 78 flow statistics as an unordered feature vector.

> **Source code:** [`core/models/ann.py`](../core/models/ann.py) — class `ANN`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | None — the model consumes the raw 2D tabular batch. |
| Parameters (total / trainable) | 55,055 / 55,055 |
| Model size (fp32) | 0.21 MB |
| MACs per sample | 54,656 |
| CPU latency @ batch 32 | 0.1128 ms (283,705 samples/s) |

## 2. Inductive bias — why this model is in the study

Permutation-agnostic. No locality or ordering assumption is imposed on the feature axis, which is the theoretically correct prior for tabular flow statistics and makes this the fairest control condition against which the structured models (CNN/RNN/Transformer) must be judged.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | Linear + ReLU | 78 -> 256 |
| 3 | Linear + ReLU | 256 -> 128 |
| 4 | Linear (classifier) | 128 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `hidden_dims` | (256, 128) | Width of the two dense blocks |
| `activation` | ReLU | Applied after every hidden linear layer |
| `dropout` | 0.0 (placeholder) | Insert after each ReLU |
| `norm` | none (placeholder) | BatchNorm1d recommended before ReLU |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `block1.0` | Linear | 32x78 | 32x256 | 20,224 |
| `block1.1` | ReLU | 32x256 | 32x256 | 0 |
| `block2.0` | Linear | 32x256 | 32x128 | 32,896 |
| `block2.1` | ReLU | 32x128 | 32x128 | 0 |
| `classifier` | Linear | 32x128 | 32x15 | 1,935 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
Let $\mathbf{x}\in\mathbb{R}^{F}$ denote the pre-processed flow feature vector. The ANN baseline computes
\begin{align}
\mathbf{h}_1 &= \sigma(\mathbf{W}_1\mathbf{x}+\mathbf{b}_1), && \mathbf{W}_1\in\mathbb{R}^{256\times F},\\
\mathbf{h}_2 &= \sigma(\mathbf{W}_2\mathbf{h}_1+\mathbf{b}_2), && \mathbf{W}_2\in\mathbb{R}^{128\times 256},\\
\mathbf{z}  &= \mathbf{W}_3\mathbf{h}_2+\mathbf{b}_3, && \mathbf{W}_3\in\mathbb{R}^{C\times 128},
\end{align}
where $\sigma(\cdot)=\max(0,\cdot)$ and $\mathbf{z}$ are the unnormalised class logits optimised with the class-weighted cross-entropy objective.
```

## 6. Reporting notes

- Serves as the control condition: any accuracy gained by the convolutional, recurrent or attention baselines must be reported relative to this model at matched parameter budget.
- Because no spatial prior is imposed, this architecture is also the cheapest per sample and is the natural candidate for the latency/throughput column of the results table.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import ANN

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = ANN(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
