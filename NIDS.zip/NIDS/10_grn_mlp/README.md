# 10_grn_mlp — GRN-MLP

**Gated Residual MLP (control for SIGMA-IDS)** · family: *Proposed — control*

A well-regularised feed-forward network sharing SIGMA-IDS's head, loss and tuning budget, so the attention margin can be attributed rather than assumed.

> **Source code:** [`core/models/gated_mlp.py`](../core/models/gated_mlp.py) — class `GRNMLP`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits (scaled cosine to class prototypes) |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | None — operates directly on the 2D tabular batch. |
| Parameters (total / trainable) | 310,145 / 310,145 |
| Model size (fp32) | 1.1831 MB |
| MACs per sample | 304,896 |
| CPU latency @ batch 32 | 1.1549 ms (27,709 samples/s) |

## 2. Inductive bias — why this model is in the study

Deliberately minimal: no locality, no ordering, no family structure. Gating gives multiplicative feature interactions, which is the one thing plain ReLU stacks do badly on tabular data and the reason tree ensembles beat them. Its role in the study is to absorb every improvement that is NOT specific to grouped attention or shortcut invariance.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | Stem: Linear + LayerNorm + GELU | 78 -> 128 |
| 3 | Gated residual block x3 | GLU, expansion 2 |
| 4 | LayerNorm | [B, 128] |
| 5 | Cosine prototype head | 128 -> 10 logits |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `d_model` | 128 | Residual stream width |
| `num_blocks` | 3 | Depth |
| `expansion` | 2 | GLU inner expansion |
| `dropout` | 0.1 | Applied inside blocks and before the head |
| `cosine_head` | True | Match SIGMA-IDS's head exactly |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `stem.0` | Linear | 32x78 | 32x128 | 10,112 |
| `stem.1` | LayerNorm | 32x128 | 32x128 | 256 |
| `stem.2` | GELU | 32x128 | 32x128 | 0 |
| `blocks.0.norm` | LayerNorm | 32x128 | 32x128 | 256 |
| `blocks.0.up` | Linear | 32x128 | 32x512 | 66,048 |
| `blocks.0.drop` | Dropout | 32x256 | 32x256 | 0 |
| `blocks.0.down` | Linear | 32x256 | 32x128 | 32,896 |
| `blocks.0.drop` | Dropout | 32x128 | 32x128 | 0 |
| `blocks.1.norm` | LayerNorm | 32x128 | 32x128 | 256 |
| `blocks.1.up` | Linear | 32x128 | 32x512 | 66,048 |
| `blocks.1.drop` | Dropout | 32x256 | 32x256 | 0 |
| `blocks.1.down` | Linear | 32x256 | 32x128 | 32,896 |
| `blocks.1.drop` | Dropout | 32x128 | 32x128 | 0 |
| `blocks.2.norm` | LayerNorm | 32x128 | 32x128 | 256 |
| `blocks.2.up` | Linear | 32x128 | 32x512 | 66,048 |
| `blocks.2.drop` | Dropout | 32x256 | 32x256 | 0 |
| `blocks.2.down` | Linear | 32x256 | 32x128 | 32,896 |
| `blocks.2.drop` | Dropout | 32x128 | 32x128 | 0 |
| `norm` | LayerNorm | 32x128 | 32x128 | 256 |
| `drop` | Dropout | 32x128 | 32x128 | 0 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
The stem maps $\mathbf{x}\in\mathbb{R}^{F}$ to $\mathbf{h}^{(0)}=\mathrm{GELU}(\mathrm{LN}(\mathbf{W}_s\mathbf{x}+\mathbf{b}_s))\in\mathbb{R}^{d}$. Each of the $B$ blocks applies
\begin{equation}
\mathbf{u},\mathbf{v}=\mathbf{W}_{\uparrow}\mathrm{LN}(\mathbf{h}^{(b-1)}),\qquad
\mathbf{h}^{(b)}=\mathbf{h}^{(b-1)}+\mathbf{W}_{\downarrow}\bigl(\mathbf{u}\odot\sigma(\mathbf{v})\bigr),
\end{equation}
where $\sigma$ is the logistic sigmoid, so the block realises second-order feature interactions without an attention matrix. The head is the cosine prototype classifier of SIGMA-IDS, trained under the same logit-adjusted objective.
```

## 6. Reporting notes

- Give this model the same hyperparameter search budget as SIGMA-IDS. An under-tuned control is the most common way a weak architectural claim survives to publication.
- It has no gradient-reversal head, so it also serves as the 'no-invariance' condition at the encoder level — complementing the grl_lambda=0 ablation inside SIGMA-IDS itself.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import GRNMLP

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = GRNMLP(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
