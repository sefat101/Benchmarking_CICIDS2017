Training curves and run logs. One subfolder per run keeps the seed sweep
readable: `logs/07_cnn_lstm/seed0/`.
