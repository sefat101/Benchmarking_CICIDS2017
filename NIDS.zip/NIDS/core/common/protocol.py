"""
Evaluation protocol for the reduced CICIDS2017 task.

Two things live here, and they are the two things that decide whether the
numbers in the thesis mean anything:

  1. The REDUCED CLASS SET — which classes are kept, which are dropped, and
     the argument for each removal.
  2. LEAKAGE-AWARE SPLITTING — how train/val/test are separated so that
     near-identical flows from the same conversation cannot appear on both
     sides. This is the single change that turns a 0.99 macro-F1 into an
     honest number.

Neither is cosmetic. Under a plain stratified random split the reduced task is
close to saturated, and any architectural improvement you report is inside the
noise. Under the grouped split there is real, measurable headroom.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Canonical CICIDS2017 (MachineLearningCSV) class distribution — 2,830,743 rows
# ---------------------------------------------------------------------------
CANONICAL_COUNTS: Dict[str, int] = {
    "BENIGN": 2_273_097,
    "DoS Hulk": 231_073,
    "PortScan": 158_930,
    "DDoS": 128_027,
    "DoS GoldenEye": 10_293,
    "FTP-Patator": 7_938,
    "SSH-Patator": 5_897,
    "DoS slowloris": 5_796,
    "DoS Slowhttptest": 5_499,
    "Bot": 1_966,
    "Web Attack: Brute Force": 1_507,
    "Web Attack: XSS": 652,
    "Infiltration": 36,
    "Web Attack: SQL Injection": 21,
    "Heartbleed": 11,
}

# The 10 classes kept. 2,828,516 flows — 99.921% of the dataset.
KEPT_CLASSES: List[str] = [
    "BENIGN", "DoS Hulk", "PortScan", "DDoS", "DoS GoldenEye",
    "FTP-Patator", "SSH-Patator", "DoS slowloris", "DoS Slowhttptest", "Bot",
]

# Dropped, with the reason that goes in the paper. Removing a class is a
# methodological choice a reviewer will challenge, so each one needs an
# argument that is about the data, not about convenience.
DROPPED_CLASSES: Dict[str, str] = {
    "Web Attack: Brute Force":
        "Payload-defined attack. The CICFlowMeter feature set contains no "
        "payload information, so this class is not identifiable from these "
        "78 columns by construction — it is separable from BENIGN only via "
        "coarse timing/volume side-effects, and not separable from the other "
        "two Web Attack classes at all.",
    "Web Attack: XSS":
        "Same argument. Published confusion matrices show XSS, Brute Force "
        "and SQL Injection collapsing into one another: all three are HTTP "
        "POST bursts to the same victim over the same port in the same "
        "capture window.",
    "Web Attack: SQL Injection":
        "Same argument, plus only 21 flows — a stratified 20% test fold "
        "receives 4 of them, so any per-class F1 has a confidence interval "
        "wider than the metric itself.",
    "Infiltration":
        "36 flows, and the class most affected by the flow-construction and "
        "labelling errors documented by Engelen et al. (2021). A test fold of "
        "7 flows cannot support a claim.",
    "Heartbleed":
        "11 flows from a single victim host. Two flows in a 20% test fold. "
        "Any reported score is a coin flip, and published works claiming "
        "hundreds of Heartbleed flows are not using the standard "
        "distribution.",
}


def reduction_summary() -> str:
    kept = sum(CANONICAL_COUNTS[c] for c in KEPT_CLASSES)
    total = sum(CANONICAL_COUNTS.values())
    dropped = total - kept
    lines = [
        "Reduced CICIDS2017 task",
        "=" * 72,
        f"kept    : {len(KEPT_CLASSES):>2} classes, {kept:>10,} flows "
        f"({100*kept/total:.3f}% of the dataset)",
        f"dropped : {len(DROPPED_CLASSES):>2} classes, {dropped:>10,} flows "
        f"({100*dropped/total:.3f}%)",
        "",
        "Kept:",
    ]
    for c in KEPT_CLASSES:
        n = CANONICAL_COUNTS[c]
        lines.append(f"  {c:<20} {n:>10,}  ({100*n/kept:6.3f}%)")
    ratio = CANONICAL_COUNTS["BENIGN"] / CANONICAL_COUNTS["Bot"]
    lines += ["", f"Imbalance ratio (BENIGN : Bot) = {ratio:,.0f} : 1",
              "", "Dropped:"]
    for c, why in DROPPED_CLASSES.items():
        lines.append(f"  {c} ({CANONICAL_COUNTS[c]:,} flows)")
        lines.append(f"    {why}")
    return "\n".join(lines)


def reduce_classes(y: np.ndarray, class_names: Sequence[str],
                   keep: Optional[Sequence[str]] = None
                   ) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Filter labels down to the reduced class set and re-index them.

    Returns (row_mask, y_new, new_class_names). Apply `row_mask` to X yourself:

        mask, y10, names10 = reduce_classes(bundle.y_train, bundle.class_names)
        X10 = bundle.X_train[mask]
    """
    keep = list(keep or KEPT_CLASSES)
    name_to_old = {n: i for i, n in enumerate(class_names)}
    kept_names = [n for n in keep if n in name_to_old]
    missing = [n for n in keep if n not in name_to_old]
    if missing:
        import warnings
        warnings.warn(f"classes absent from this split, skipped: {missing}")

    old_ids = np.array([name_to_old[n] for n in kept_names], dtype=np.int64)
    mask = np.isin(y, old_ids)

    remap = np.full(len(class_names), -1, dtype=np.int64)
    for new_id, n in enumerate(kept_names):
        remap[name_to_old[n]] = new_id
    return mask, remap[y[mask]], kept_names


# ---------------------------------------------------------------------------
# Leakage-aware grouping
# ---------------------------------------------------------------------------
def five_tuple_groups(src_ip: Sequence, dst_ip: Sequence, src_port: Sequence,
                      dst_port: Sequence, protocol: Sequence) -> np.ndarray:
    """
    PROTOCOL A (preferred). Group id per (srcIP, dstIP, srcPort, dstPort,
    proto) conversation.

    Requires the GeneratedLabelledFlows distribution of CICIDS2017, which
    carries Flow ID / IPs / ports / timestamp. The MachineLearningCSV
    distribution that `ml.csv` comes from has already stripped those columns,
    so if that is all you have, use `signature_groups` instead and say so in
    the methodology section.
    """
    n = len(src_ip)
    out = np.empty(n, dtype=np.int64)
    seen: Dict[str, int] = {}
    for i in range(n):
        key = f"{src_ip[i]}|{dst_ip[i]}|{src_port[i]}|{dst_port[i]}|{protocol[i]}"
        gid = seen.get(key)
        if gid is None:
            gid = len(seen)
            seen[key] = gid
        out[i] = gid
    return out


def signature_groups(X: np.ndarray, decimals: int = 0,
                     cols: Optional[Sequence[int]] = None) -> np.ndarray:
    """
    PROTOCOL B (ml.csv fallback). Group id per near-identical feature vector.

    Rounds the (raw, un-scaled) feature matrix to `decimals` places and gives
    every distinct rounded row a group id. Exact duplicates therefore always
    share a group, and with `decimals=-1` or `-2` so do flows that differ only
    by measurement jitter.

    This does not reconstruct conversations, and it is weaker than Protocol A.
    What it does do is close the specific leak that inflates CICIDS2017 the
    most: the dataset contains a very large fraction of duplicate and
    near-duplicate flows, and under a plain random split the same flow appears
    in train and test. State plainly in the paper which protocol you ran.

    Note `decimals` may be negative (numpy rounds to tens, hundreds, ...),
    which is how you widen a group from "identical" to "indistinguishable".
    """
    A = np.ascontiguousarray(np.round(np.asarray(X, dtype=np.float64), decimals))
    if cols is not None:
        A = np.ascontiguousarray(A[:, list(cols)])
    # Row-as-void view: the standard fast trick for unique-rows on a 2D array.
    view = A.view([("", A.dtype)] * A.shape[1]).ravel()
    _, inverse = np.unique(view, return_inverse=True)
    return inverse.astype(np.int64)


def day_groups(source_file: Sequence[str]) -> np.ndarray:
    """
    Group id per capture day, when you kept the source filename while
    concatenating the eight CICIDS2017 CSVs.

    A pure train-early/test-late split is DEGENERATE on this dataset: the
    attacks are scheduled one family per day, so a chronological cut puts
    entire classes on one side only. Use day groups for a targeted
    same-family-different-day holdout (Wednesday DoS -> Friday DDoS), not as
    the main split.
    """
    seen: Dict[str, int] = {}
    out = np.empty(len(source_file), dtype=np.int64)
    for i, f in enumerate(source_file):
        key = str(f)
        if key not in seen:
            seen[key] = len(seen)
        out[i] = seen[key]
    return out


@dataclass
class SplitIndices:
    train: np.ndarray
    val: np.ndarray
    test: np.ndarray

    def summary(self, y: np.ndarray, class_names: Sequence[str]) -> str:
        lines = [f"{'class':<22}{'train':>10}{'val':>10}{'test':>10}", "-" * 52]
        for i, name in enumerate(class_names):
            lines.append(f"{name:<22}{int((y[self.train]==i).sum()):>10,}"
                         f"{int((y[self.val]==i).sum()):>10,}"
                         f"{int((y[self.test]==i).sum()):>10,}")
        lines.append("-" * 52)
        lines.append(f"{'total':<22}{len(self.train):>10,}{len(self.val):>10,}"
                     f"{len(self.test):>10,}")
        return "\n".join(lines)


def grouped_split(y: np.ndarray, groups: np.ndarray,
                  test_size: float = 0.20, val_size: float = 0.20,
                  random_state: int = 42) -> SplitIndices:
    """
    Stratified-by-class, grouped-by-conversation train/val/test split.

    Uses StratifiedGroupKFold, which keeps the class proportions roughly intact
    while guaranteeing that a group never straddles a fold — the property that
    makes the resulting test score a generalisation estimate rather than a
    memorisation estimate.
    """
    from sklearn.model_selection import StratifiedGroupKFold

    y = np.asarray(y)
    groups = np.asarray(groups)
    idx = np.arange(len(y))

    n_outer = max(2, int(round(1.0 / test_size)))
    sgkf = StratifiedGroupKFold(n_splits=n_outer, shuffle=True,
                                random_state=random_state)
    trainval_idx, test_idx = next(sgkf.split(idx, y, groups))

    n_inner = max(2, int(round(1.0 / val_size)))
    sgkf2 = StratifiedGroupKFold(n_splits=n_inner, shuffle=True,
                                 random_state=random_state + 1)
    inner_train, inner_val = next(
        sgkf2.split(trainval_idx, y[trainval_idx], groups[trainval_idx]))

    split = SplitIndices(train=trainval_idx[inner_train],
                         val=trainval_idx[inner_val],
                         test=test_idx)

    # A grouped split can starve a small class out of a fold entirely — the
    # per-class F1 is then silently 0 and macro-F1 is quietly wrong. Surface
    # it loudly rather than letting it into a results table.
    import warnings
    for fold_name, idx in (("train", split.train), ("val", split.val),
                           ("test", split.test)):
        present = np.bincount(y[idx], minlength=int(y.max()) + 1)
        empty = np.where(present == 0)[0]
        if len(empty):
            warnings.warn(
                f"grouped_split: class id(s) {empty.tolist()} have zero rows "
                f"in the {fold_name} fold. Either the class is too small for "
                f"this grouping, or the group granularity is too coarse. Do "
                f"not report macro-F1 from this split until it is fixed.")
    return split


def leakage_report(groups: np.ndarray, split: SplitIndices) -> str:
    """Proof, not assertion: count groups shared across folds. Must be zero."""
    g_tr, g_va, g_te = (set(groups[split.train].tolist()),
                        set(groups[split.val].tolist()),
                        set(groups[split.test].tolist()))
    n_total = len(set(groups.tolist()))
    lines = [
        "Leakage check", "-" * 46,
        f"distinct groups        : {n_total:,}",
        f"groups in train        : {len(g_tr):,}",
        f"groups in val          : {len(g_va):,}",
        f"groups in test         : {len(g_te):,}",
        f"train n val overlap    : {len(g_tr & g_va):,}",
        f"train n test overlap   : {len(g_tr & g_te):,}",
        f"val   n test overlap   : {len(g_va & g_te):,}",
    ]
    clean = not (g_tr & g_va or g_tr & g_te or g_va & g_te)
    lines.append("VERDICT: " + ("no group crosses a fold — clean."
                                if clean else "LEAK — folds share groups."))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Shortcut / domain labels for the invariance objective
# ---------------------------------------------------------------------------
def port_domain_labels(dst_port: Sequence[int], n_buckets: int = 16) -> np.ndarray:
    """
    Coarse destination-port buckets, used as the nuisance variable the
    shortcut-adversary head is asked to predict (and the encoder is trained to
    hide).

    Destination port is the best-known shortcut in CICIDS2017: the testbed ran
    each attack against a fixed service, so port alone predicts the label far
    better than it would on real traffic. Dropping the column is necessary but
    not sufficient — port information leaks back in through header lengths,
    window sizes and packet-size modes. Training the encoder to be
    port-uninformative attacks the leak rather than the column.
    """
    p = np.asarray(dst_port, dtype=np.int64)
    well_known = np.array([20, 21, 22, 23, 25, 53, 80, 110, 143, 443, 445,
                           3306, 3389, 8080], dtype=np.int64)
    out = np.full(len(p), n_buckets - 1, dtype=np.int64)   # "other"
    for i, port in enumerate(well_known[:n_buckets - 2]):
        out[p == port] = i
    out[(p >= 49152) & (out == n_buckets - 1)] = n_buckets - 2  # ephemeral
    return out


def hash_domain_labels(values: Sequence, n_buckets: int = 16) -> np.ndarray:
    """Generic nuisance bucketing (victim host, capture day, ...)."""
    out = np.empty(len(values), dtype=np.int64)
    for i, v in enumerate(values):
        h = hashlib.md5(str(v).encode()).digest()
        out[i] = int.from_bytes(h[:4], "little") % n_buckets
    return out
