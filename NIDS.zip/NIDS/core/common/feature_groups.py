"""
Semantic partition of the CICFlowMeter / CICIDS2017 feature columns.

Why this exists
---------------
The 78 columns of `ml.csv` are not 78 independent measurements. They are
roughly a dozen *statistical summaries* computed over a handful of underlying
signals: forward packet sizes, backward packet sizes, inter-arrival times,
TCP flags, and so on. Treating them as 78 unrelated tokens (the naive
"feature-as-token" Transformer) throws that structure away and pays O(78^2)
attention for the privilege.

Grouping them first gives three concrete wins:

1. Attention cost drops from 78x78 = 6,084 pairs to ~11x11 = 121 — a ~50x
   reduction, which is what makes an attention model competitive with an LSTM
   on latency instead of ~13x slower.
2. The attention map becomes readable: "this flow was flagged because the
   IAT-backward group and the flag group fired" is a sentence a SOC analyst
   can act on. A 78x78 heat-map over raw column names is not.
3. Whole groups can be ablated or dropped, which is how you test — rather
   than assert — that the model is not riding a single shortcut feature.

Matching is by normalised column name, so it survives the leading spaces in
the CICIDS2017 headers (' Flow Duration') and the underscore/space
inconsistencies (`Init_Win_bytes_forward` vs `Fwd Header Length`).
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Sequence

# Ordered: the first pattern that matches a column claims it.
# Patterns are matched against the lower-cased column name with runs of
# whitespace/underscores collapsed to a single space.
GROUP_PATTERNS: List[tuple] = [
    ("duration",     [r"^flow duration$", r"duration"]),
    ("iat flow",     [r"^flow iat"]),
    ("iat fwd",      [r"^fwd iat"]),
    ("iat bwd",      [r"^bwd iat"]),
    ("flags",        [r"flag", r"^fwd psh", r"^bwd psh", r"^fwd urg", r"^bwd urg"]),
    ("headers/win",  [r"header length", r"init win bytes", r"act data pkt",
                      r"min seg size"]),
    ("rates",        [r"/s$", r"bytes/s", r"packets/s", r"down/up ratio"]),
    ("fwd volume",   [r"^total fwd", r"^total length of fwd", r"^fwd packet length",
                      r"^fwd avg", r"^subflow fwd", r"^avg fwd segment"]),
    ("bwd volume",   [r"^total backward", r"^total length of bwd", r"^bwd packet length",
                      r"^bwd avg", r"^subflow bwd", r"^avg bwd segment"]),
    ("size stats",   [r"^min packet length", r"^max packet length",
                      r"^packet length", r"^average packet size"]),
    ("active/idle",  [r"^active ", r"^idle "]),
]

MISC_GROUP = "misc"


def _norm(name: str) -> str:
    s = str(name).replace("_", " ")
    return re.sub(r"\s+", " ", s).strip().lower()


def assign_groups(feature_names: Sequence[str]) -> Dict[str, List[int]]:
    """
    Map each column index into a semantic group.

    Returns an ordered dict {group_name: [column indices]}. Empty groups are
    dropped, so the group count adapts to whatever survived the preprocessing
    pruning. Columns matching nothing land in `misc`, which is a real group —
    never silently discarded.
    """
    buckets: Dict[str, List[int]] = {name: [] for name, _ in GROUP_PATTERNS}
    buckets[MISC_GROUP] = []

    for idx, raw in enumerate(feature_names):
        col = _norm(raw)
        placed = False
        for group, patterns in GROUP_PATTERNS:
            if any(re.search(p, col) for p in patterns):
                buckets[group].append(idx)
                placed = True
                break
        if not placed:
            buckets[MISC_GROUP].append(idx)

    return {g: idxs for g, idxs in buckets.items() if idxs}


def contiguous_groups(input_dim: int, n_groups: int = 11) -> Dict[str, List[int]]:
    """
    Fallback when column names are unavailable (e.g. the dummy-tensor smoke
    test): split the feature axis into n_groups contiguous blocks. This keeps
    the model constructible from `input_dim` alone, but it is NOT the intended
    configuration — pass `feature_names=bundle.feature_names` for real runs,
    or the semantic prior the architecture is built on simply is not there.
    """
    n_groups = max(1, min(n_groups, input_dim))
    edges = [round(i * input_dim / n_groups) for i in range(n_groups + 1)]
    out = {}
    for i in range(n_groups):
        idxs = list(range(edges[i], edges[i + 1]))
        if idxs:
            out[f"block {i}"] = idxs
    return out


def build_groups(input_dim: int,
                 feature_names: Optional[Sequence[str]] = None,
                 n_groups: int = 11) -> Dict[str, List[int]]:
    """Semantic groups when names are known, contiguous blocks otherwise."""
    if feature_names is None:
        return contiguous_groups(input_dim, n_groups)
    if len(feature_names) != input_dim:
        raise ValueError(
            f"feature_names has {len(feature_names)} entries but input_dim is "
            f"{input_dim}. Pass bundle.feature_names from the preprocessor.")
    return assign_groups(feature_names)


def describe(groups: Dict[str, List[int]],
             feature_names: Optional[Sequence[str]] = None) -> str:
    lines = [f"{len(groups)} groups over "
             f"{sum(len(v) for v in groups.values())} features", "-" * 60]
    for g, idxs in groups.items():
        head = ""
        if feature_names is not None:
            names = [str(feature_names[i]).strip() for i in idxs[:3]]
            head = "  e.g. " + ", ".join(names) + ("..." if len(idxs) > 3 else "")
        lines.append(f"{g:<14} {len(idxs):>3} cols{head}")
    return "\n".join(lines)
