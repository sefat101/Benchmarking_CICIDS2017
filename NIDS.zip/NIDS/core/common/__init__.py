"""Shared preprocessing and analysis utilities for the 8 NIDS baselines."""

from .preprocessing import (CICIDS2017Preprocessor, PreprocessConfig,
                            DataBundle, CANONICAL_LABELS)
from .model_utils import (count_parameters, parameters_by_module, trace_shapes,
                          analytic_macs, measure_latency, render_svg,
                          render_mermaid)

__all__ = [
    "CICIDS2017Preprocessor", "PreprocessConfig", "DataBundle",
    "CANONICAL_LABELS", "count_parameters", "parameters_by_module",
    "trace_shapes", "analytic_macs", "measure_latency", "render_svg",
    "render_mermaid",
]
