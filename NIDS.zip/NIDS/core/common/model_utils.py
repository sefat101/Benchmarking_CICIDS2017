"""
Analysis helpers shared by every model folder:
  * parameter accounting (total / trainable / per-module)
  * analytic MAC (multiply-accumulate) counts per sample
  * a shape trace captured with forward hooks
  * CPU latency / throughput measurement
  * a publication-quality SVG block diagram and a Mermaid source file
"""

from __future__ import annotations

import time
from typing import Dict, List, Tuple

import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------
def count_parameters(model: nn.Module) -> Dict[str, int]:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    buffers = sum(b.numel() for b in model.buffers())
    return {
        "total_parameters": int(total),
        "trainable_parameters": int(trainable),
        "non_trainable_parameters": int(total - trainable),
        "buffers": int(buffers),
        "size_fp32_mb": round((total + buffers) * 4 / 1024 ** 2, 4),
    }


def parameters_by_module(model: nn.Module) -> List[Tuple[str, str, int]]:
    rows = []
    for name, mod in model.named_children():
        n = sum(p.numel() for p in mod.parameters())
        rows.append((name or "<root>", mod.__class__.__name__, int(n)))
    return rows


# ---------------------------------------------------------------------------
# Shape trace + analytic MACs
# ---------------------------------------------------------------------------
def _fmt(t) -> str:
    if torch.is_tensor(t):
        return "x".join(str(s) for s in t.shape)
    if isinstance(t, (tuple, list)):
        return "(" + ", ".join(_fmt(o) for o in t) + ")"
    return type(t).__name__


def trace_shapes(model: nn.Module, x: torch.Tensor):
    """Run one forward pass and record (module, in-shape, out-shape, params)."""
    records: List[Dict] = []
    handles = []

    def make_hook(name, mod):
        def hook(_m, inp, out):
            records.append({
                "layer": name,
                "type": mod.__class__.__name__,
                "in": _fmt(inp[0] if len(inp) == 1 else inp),
                "out": _fmt(out),
                "params": int(sum(p.numel() for p in mod.parameters(recurse=False))),
            })
        return hook

    for name, mod in model.named_modules():
        if name == "" or len(list(mod.children())) > 0:
            continue  # leaves only
        handles.append(mod.register_forward_hook(make_hook(name, mod)))

    model.eval()
    with torch.no_grad():
        out = model(x)
    for h in handles:
        h.remove()
    return records, out


def analytic_macs(model: nn.Module, x: torch.Tensor) -> int:
    """
    Multiply-accumulate operations for ONE sample. Covers Linear, Conv1d,
    RNN/LSTM/GRU and MultiheadAttention (the four families used here).
    """
    macs = {"n": 0}
    handles = []

    def hook_linear(m, inp, out):
        macs["n"] += m.in_features * m.out_features * (out.numel() // out.shape[-1] // out.shape[0] if out.dim() > 2 else 1)

    def hook_conv(m, inp, out):
        # out: [B, C_out, L_out]
        l_out = out.shape[-1]
        macs["n"] += m.in_channels // m.groups * m.out_channels * m.kernel_size[0] * l_out

    def hook_rnn(m, inp, out):
        T = inp[0].shape[1] if m.batch_first else inp[0].shape[0]
        gates = {"RNN": 1, "GRU": 3, "LSTM": 4}[m.__class__.__name__]
        dirs = 2 if m.bidirectional else 1
        H, I = m.hidden_size, m.input_size
        per_layer = gates * H * (I + H)
        total = per_layer
        for _ in range(m.num_layers - 1):
            total += gates * H * (H * dirs + H)
        macs["n"] += total * T * dirs

    def hook_mha(m, inp, out):
        q = inp[0]
        T, E = q.shape[1], m.embed_dim
        macs["n"] += 4 * T * E * E      # q, k, v and output projections
        macs["n"] += 2 * T * T * E      # scores and weighted sum

    for mod in model.modules():
        if isinstance(mod, nn.Linear):
            handles.append(mod.register_forward_hook(hook_linear))
        elif isinstance(mod, nn.Conv1d):
            handles.append(mod.register_forward_hook(hook_conv))
        elif isinstance(mod, (nn.RNN, nn.LSTM, nn.GRU)):
            handles.append(mod.register_forward_hook(hook_rnn))
        elif isinstance(mod, nn.MultiheadAttention):
            handles.append(mod.register_forward_hook(hook_mha))

    model.eval()
    with torch.no_grad():
        model(x[:1])
    for h in handles:
        h.remove()
    return int(macs["n"])


# ---------------------------------------------------------------------------
# Latency
# ---------------------------------------------------------------------------
@torch.no_grad()
def measure_latency(model: nn.Module, input_dim: int, batch_size: int = 32,
                    warmup: int = 5, iters: int = 30) -> Dict[str, float]:
    model.eval()
    x = torch.randn(batch_size, input_dim)
    for _ in range(warmup):
        model(x)
    t0 = time.perf_counter()
    for _ in range(iters):
        model(x)
    dt = (time.perf_counter() - t0) / iters
    return {
        "batch_size": batch_size,
        "latency_ms_per_batch": round(dt * 1000, 4),
        "throughput_samples_per_s": round(batch_size / dt, 1),
    }


# ---------------------------------------------------------------------------
# Diagrams
# ---------------------------------------------------------------------------
PALETTE = {
    "input":   ("#E8EDF5", "#3E5C86"),
    "reshape": ("#FDF1DC", "#9A6B1E"),
    "conv":    ("#DCEBE3", "#2F6B4F"),
    "pool":    ("#EDE7F3", "#5B4A80"),
    "rnn":     ("#FBE4E6", "#8C3A46"),
    "attn":    ("#E2ECF7", "#2C5F91"),
    "linear":  ("#EDEDED", "#4A4A4A"),
    "latent":  ("#FFF3CC", "#8A6D1E"),
    "out":     ("#DDE9F6", "#1F4E79"),
}


def render_svg(meta: Dict, stats: Dict) -> str:
    """Vertical block diagram, print-safe (no external fonts, no JS)."""
    blocks = meta["blocks"]
    bw, bh, gap, pad = 330, 54, 26, 34
    header = 74
    width = bw + 2 * pad
    height = header + len(blocks) * bh + (len(blocks) - 1) * gap + pad + 34

    esc = lambda s: (str(s).replace("&", "&amp;").replace("<", "&lt;")
                     .replace(">", "&gt;"))

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}" '
        f'font-family="Helvetica, Arial, sans-serif">',
        f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>',
        '<defs><marker id="arw" markerWidth="9" markerHeight="9" refX="6" '
        'refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#8A8A8A"/>'
        '</marker></defs>',
        f'<text x="{width/2}" y="30" text-anchor="middle" font-size="17" '
        f'font-weight="700" fill="#1A1A1A">{esc(meta["name"])}</text>',
        f'<text x="{width/2}" y="50" text-anchor="middle" font-size="11" '
        f'fill="#6A6A6A">{esc(meta["full_name"])}</text>',
    ]

    y = header
    for i, (kind, label, sub) in enumerate(blocks):
        fill, stroke = PALETTE.get(kind, PALETTE["linear"])
        parts.append(
            f'<rect x="{pad}" y="{y}" width="{bw}" height="{bh}" rx="8" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="1.4"/>')
        parts.append(
            f'<text x="{pad+16}" y="{y+23}" font-size="13" font-weight="600" '
            f'fill="#1A1A1A">{esc(label)}</text>')
        parts.append(
            f'<text x="{pad+16}" y="{y+41}" font-size="11" '
            f'fill="{stroke}">{esc(sub)}</text>')
        if i < len(blocks) - 1:
            parts.append(
                f'<line x1="{pad+bw/2}" y1="{y+bh}" x2="{pad+bw/2}" '
                f'y2="{y+bh+gap-6}" stroke="#8A8A8A" stroke-width="1.4" '
                f'marker-end="url(#arw)"/>')
        y += bh + gap

    parts.append(
        f'<text x="{width/2}" y="{height-14}" text-anchor="middle" '
        f'font-size="10.5" fill="#6A6A6A">'
        f'{stats["total_parameters"]:,} parameters &#183; '
        f'{stats["macs_per_sample"]:,} MACs/sample &#183; '
        f'output {esc(meta["output_shape"])}</text>')
    parts.append("</svg>")
    return "\n".join(parts)


def render_mermaid(meta: Dict) -> str:
    lines = ["flowchart TD"]
    for i, (kind, label, sub) in enumerate(meta["blocks"]):
        lines.append(f'    n{i}["{label}<br/><small>{sub}</small>"]')
    for i in range(len(meta["blocks"]) - 1):
        lines.append(f"    n{i} --> n{i+1}")
    return "\n".join(lines)
