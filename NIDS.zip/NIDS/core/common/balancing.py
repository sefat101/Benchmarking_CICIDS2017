"""
Imbalance handling for CICIDS2017 — losses, sampling and augmentation.

The reduced 10-class task still spans a ~1,150:1 imbalance ratio
(BENIGN 2,273,097 vs Bot 1,966), so what you do about imbalance matters more
than which of the eight baseline architectures you pick.

What is here, in the order you should try it:

1. `LogitAdjustedLoss`  — the default. Adds tau * log(prior) to the logits
   during training only. It is a Bayes-consistent correction for label shift,
   costs nothing at inference, and unlike reweighting does not inflate the
   gradient variance of the rare classes. Menon et al., "Long-tail learning
   via logit adjustment", ICLR 2021.
2. `ClassBalancedLoss`  — reweighting by the effective number of samples
   (1-beta^n)/(1-beta) rather than by 1/n. Cui et al., CVPR 2019. Use when
   you want reweighting for comparability with the baseline runs.
3. `FocalLoss`          — down-weights easy examples. On CICIDS2017 most
   BENIGN flows are trivially easy, so this helps; it is, however, the weakest
   of the three in our ablation ordering and is included for completeness.
4. `balanced_sampler`   — square-root or effective-number sampling. Prefer
   this over naive full balancing, which oversamples Bot ~1,150x per epoch and
   simply memorises its 1,966 flows.
5. `manifold_mixup`     — interpolate in the *embedding* space instead of
   synthesising raw feature vectors. See the note below on why raw-space SMOTE
   is a hazard on this dataset.
6. `flow_invariant_violations` — a validity gate for any synthetic tabular
   sample (SMOTE, CTGAN, TVAE) you do decide to generate.

Why raw-space SMOTE is a hazard here
------------------------------------
CICFlowMeter columns are not free coordinates: they satisfy arithmetic
identities. `Total Length of Fwd Packets` must equal
`Total Fwd Packets * Fwd Packet Length Mean`; `Fwd Packet Length Min` must be
<= Mean <= Max; packet counts are non-negative integers; `Flow Bytes/s` must
equal total bytes / duration. Interpolating between two real flows breaks all
of these at once, so the classifier can separate "synthetic" from "real"
using constraint residuals that no attacker would ever produce — the reported
minority-class recall then measures the ability to detect SMOTE, not to detect
Bot traffic. `flow_invariant_violations` measures exactly that residual so you
can report it rather than hope about it.
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Losses
# ---------------------------------------------------------------------------
class LogitAdjustedLoss(nn.Module):
    """
    Cross-entropy on logits shifted by tau * log(class prior).

        loss = CE(z + tau * log(pi), y)

    tau=1.0 is the theoretically motivated value; tau in [0.25, 1.0] is the
    range worth searching. tau=0 reduces exactly to plain cross-entropy, which
    makes this a drop-in replacement you can ablate with a single scalar.
    """

    def __init__(self, class_counts: Sequence[float], tau: float = 1.0,
                 label_smoothing: float = 0.0):
        super().__init__()
        counts = torch.as_tensor(list(class_counts), dtype=torch.float32)
        prior = counts / counts.sum()
        # log(0) guard for a class that is absent from the training split.
        self.register_buffer("log_prior", torch.log(prior.clamp_min(1e-12)))
        self.tau = float(tau)
        self.label_smoothing = float(label_smoothing)

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        adjusted = logits + self.tau * self.log_prior.to(logits.device)
        return F.cross_entropy(adjusted, target,
                               label_smoothing=self.label_smoothing)

    @torch.no_grad()
    def inference_logits(self, logits: torch.Tensor) -> torch.Tensor:
        """At test time the model is used unadjusted — this is a no-op that
        exists to make that explicit in the training script."""
        return logits


class ClassBalancedLoss(nn.Module):
    """Cui et al. (2019) effective-number reweighting, wrapped around CE."""

    def __init__(self, class_counts: Sequence[float], beta: float = 0.9999,
                 label_smoothing: float = 0.0):
        super().__init__()
        counts = np.asarray(list(class_counts), dtype=np.float64)
        effective = 1.0 - np.power(beta, np.maximum(counts, 1.0))
        weights = (1.0 - beta) / effective
        weights = weights / weights.mean()          # keep the loss scale sane
        self.register_buffer("weight",
                             torch.as_tensor(weights, dtype=torch.float32))
        self.label_smoothing = float(label_smoothing)

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return F.cross_entropy(logits, target,
                               weight=self.weight.to(logits.device),
                               label_smoothing=self.label_smoothing)


class FocalLoss(nn.Module):
    """Multi-class focal loss with optional per-class alpha."""

    def __init__(self, gamma: float = 2.0,
                 alpha: Optional[Sequence[float]] = None):
        super().__init__()
        self.gamma = float(gamma)
        if alpha is None:
            self.register_buffer("alpha", None)
        else:
            a = torch.as_tensor(list(alpha), dtype=torch.float32)
            self.register_buffer("alpha", a / a.mean())

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        logp = F.log_softmax(logits, dim=1)
        logp_t = logp.gather(1, target.unsqueeze(1)).squeeze(1)
        p_t = logp_t.exp()
        loss = -((1.0 - p_t) ** self.gamma) * logp_t
        if self.alpha is not None:
            loss = loss * self.alpha.to(logits.device)[target]
        return loss.mean()


def build_loss(name: str, class_counts: Sequence[float], **kw) -> nn.Module:
    """`name` in {"ce", "logit_adjusted", "class_balanced", "focal"}."""
    name = name.lower()
    if name in ("ce", "cross_entropy"):
        return nn.CrossEntropyLoss(label_smoothing=kw.get("label_smoothing", 0.0))
    if name in ("la", "logit_adjusted"):
        return LogitAdjustedLoss(class_counts, tau=kw.get("tau", 1.0),
                                 label_smoothing=kw.get("label_smoothing", 0.0))
    if name in ("cb", "class_balanced"):
        return ClassBalancedLoss(class_counts, beta=kw.get("beta", 0.9999),
                                 label_smoothing=kw.get("label_smoothing", 0.0))
    if name == "focal":
        return FocalLoss(gamma=kw.get("gamma", 2.0), alpha=kw.get("alpha"))
    raise ValueError(f"unknown loss '{name}'")


# ---------------------------------------------------------------------------
# Sampling
# ---------------------------------------------------------------------------
def sampling_weights(y: np.ndarray, num_classes: int,
                     scheme: str = "sqrt", beta: float = 0.9999) -> np.ndarray:
    """
    Per-sample weights for a WeightedRandomSampler.

    scheme:
      "none"      uniform (no resampling)
      "inverse"   1/n_c — full balancing; oversamples Bot ~1,150x per epoch,
                  which memorises its 1,966 flows. Included as the ablation
                  that shows why you should not do this.
      "sqrt"      1/sqrt(n_c) — the recommended default. Partial rebalancing,
                  a well-established compromise for extreme long tails.
      "effective" (1-beta)/(1-beta^n_c) — matches ClassBalancedLoss.
    """
    counts = np.bincount(y, minlength=num_classes).astype(np.float64)
    counts = np.maximum(counts, 1.0)

    if scheme == "none":
        per_class = np.ones_like(counts)
    elif scheme == "inverse":
        per_class = 1.0 / counts
    elif scheme == "sqrt":
        per_class = 1.0 / np.sqrt(counts)
    elif scheme == "effective":
        per_class = (1.0 - beta) / (1.0 - np.power(beta, counts))
    else:
        raise ValueError(f"unknown sampling scheme '{scheme}'")

    per_class = per_class / per_class.sum()
    return per_class[y]


def balanced_sampler(y: np.ndarray, num_classes: int, scheme: str = "sqrt",
                     num_samples: Optional[int] = None):
    from torch.utils.data import WeightedRandomSampler
    w = sampling_weights(y, num_classes, scheme)
    return WeightedRandomSampler(
        torch.as_tensor(w, dtype=torch.double),
        num_samples=int(num_samples or len(w)),
        replacement=True,
    )


# ---------------------------------------------------------------------------
# Augmentation
# ---------------------------------------------------------------------------
def manifold_mixup(h: torch.Tensor, y: torch.Tensor, num_classes: int,
                   alpha: float = 0.4) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Mixup applied to a hidden representation rather than raw features.

    Returns (mixed_h, soft_targets). Because the interpolation happens after
    the encoder, it cannot violate the arithmetic identities that raw-space
    SMOTE breaks — the synthetic point lives in a learned space where no such
    constraint is defined. Train the head with a soft-target cross-entropy:

        loss = -(soft_targets * log_softmax(head(mixed_h))).sum(1).mean()
    """
    if alpha <= 0:
        return h, F.one_hot(y, num_classes).float()
    lam = float(np.random.beta(alpha, alpha))
    perm = torch.randperm(h.size(0), device=h.device)
    mixed = lam * h + (1.0 - lam) * h[perm]
    y1 = F.one_hot(y, num_classes).float()
    targets = lam * y1 + (1.0 - lam) * y1[perm]
    return mixed, targets


def soft_target_ce(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    return -(targets * F.log_softmax(logits, dim=1)).sum(dim=1).mean()


# ---------------------------------------------------------------------------
# Validity gate for synthetic tabular samples
# ---------------------------------------------------------------------------
# name fragment -> canonical role. Matched case-insensitively against the
# normalised (underscores -> spaces) column name.
_ROLE_PATTERNS = {
    "fwd_packets":     "total fwd packets",
    "fwd_bytes":       "total length of fwd packets",
    "fwd_len_mean":    "fwd packet length mean",
    "fwd_len_min":     "fwd packet length min",
    "fwd_len_max":     "fwd packet length max",
    "bwd_packets":     "total backward packets",
    "bwd_bytes":       "total length of bwd packets",
    "bwd_len_mean":    "bwd packet length mean",
    "bwd_len_min":     "bwd packet length min",
    "bwd_len_max":     "bwd packet length max",
    "duration":        "flow duration",
    "flow_bytes_s":    "flow bytes/s",
}


def _resolve_roles(feature_names: Sequence[str]) -> Dict[str, int]:
    import re
    norm = [re.sub(r"\s+", " ", str(c).replace("_", " ")).strip().lower()
            for c in feature_names]
    roles: Dict[str, int] = {}
    for role, frag in _ROLE_PATTERNS.items():
        for i, c in enumerate(norm):
            if c == frag:
                roles[role] = i
                break
    return roles


def flow_invariant_violations(X: np.ndarray, feature_names: Sequence[str],
                              rtol: float = 0.02) -> Dict[str, float]:
    """
    Fraction of rows violating each CICFlowMeter arithmetic identity.

    Run this on RAW (un-scaled) features — the identities do not survive a
    quantile transform. Use it two ways:

      * on the real training split, to establish the natural violation rate
        (it is not exactly zero: CICFlowMeter has rounding and known bugs);
      * on any synthetic set you generate, to show it does not exceed that
        natural rate. If SMOTE/CTGAN output violates at 5x the real rate, the
        minority-class gain you measure is partly the classifier learning to
        recognise synthetic points, and the result is not publishable.

    Returns a dict of {check_name: violating_fraction}; checks whose columns
    are absent from `feature_names` are simply omitted.
    """
    roles = _resolve_roles(feature_names)
    n = len(X)
    out: Dict[str, float] = {}
    if n == 0:
        return out

    def col(role):
        i = roles.get(role)
        return None if i is None else np.asarray(X[:, i], dtype=np.float64)

    for side in ("fwd", "bwd"):
        pk, by = col(f"{side}_packets"), col(f"{side}_bytes")
        mean = col(f"{side}_len_mean")
        mn, mx = col(f"{side}_len_min"), col(f"{side}_len_max")

        if pk is not None and by is not None and mean is not None:
            pred = pk * mean
            denom = np.maximum(np.abs(by), 1.0)
            out[f"{side}: bytes != packets x mean_len"] = float(
                (np.abs(pred - by) / denom > rtol).mean())
        if mn is not None and mean is not None:
            out[f"{side}: min > mean"] = float((mn > mean * (1 + rtol)).mean())
        if mean is not None and mx is not None:
            out[f"{side}: mean > max"] = float((mean > mx * (1 + rtol)).mean())
        if pk is not None:
            out[f"{side}: packet count negative"] = float((pk < 0).mean())
            frac = np.abs(pk - np.round(pk))
            out[f"{side}: packet count non-integer"] = float((frac > 1e-6).mean())

    dur, fbs = col("duration"), col("flow_bytes_s")
    fb, bb = col("fwd_bytes"), col("bwd_bytes")
    if dur is not None and fbs is not None and fb is not None and bb is not None:
        # CICFlowMeter reports duration in microseconds.
        seconds = np.maximum(dur, 1.0) / 1e6
        pred = (fb + bb) / seconds
        denom = np.maximum(np.abs(fbs), 1.0)
        finite = np.isfinite(fbs) & np.isfinite(pred)
        out["rate: flow_bytes/s != total_bytes / duration"] = float(
            ((np.abs(pred - fbs) / denom > rtol) & finite).mean())

    return out


def report_violations(X: np.ndarray, feature_names: Sequence[str],
                      label: str = "sample") -> str:
    v = flow_invariant_violations(X, feature_names)
    if not v:
        return (f"{label}: no invariant columns resolved — check that "
                f"feature_names are the raw CICFlowMeter names.")
    width = max(len(k) for k in v)
    lines = [f"Flow-invariant violations — {label} (n={len(X):,})", "-" * (width + 12)]
    for k, frac in sorted(v.items(), key=lambda kv: -kv[1]):
        lines.append(f"{k:<{width}}  {frac*100:6.2f}%")
    return "\n".join(lines)
