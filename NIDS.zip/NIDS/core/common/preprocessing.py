"""
CICIDS2017 preprocessing pipeline (ml.csv) — built for *efficiency*, not just
correctness. Every step below either removes work from the training loop or
removes a documented failure mode of this dataset.

Design goals
------------
1. Bounded peak memory   : chunked read + float32 downcast (~2.1x less RAM
                           than the pandas default float64 load).
2. Run preprocessing once: the cleaned arrays are cached as .npy and reloaded
                           with mmap_mode='r' on every subsequent run, so
                           epoch 1 of run 2 starts in milliseconds.
3. Fewer input features  : constant, duplicate, identifier and near-collinear
                           columns are dropped -> smaller first layer, faster
                           epochs, fewer parameters to regularise.
4. Faster convergence    : CICIDS2017 features are extremely heavy-tailed
                           (Flow Bytes/s spans ~9 orders of magnitude). A
                           quantile transform to a normal marginal removes the
                           tail without clipping information and typically
                           reaches a given loss in far fewer steps than
                           StandardScaler on raw values.
5. No leakage            : the scaler is fitted on the TRAIN split only;
                           duplicate rows are removed BEFORE splitting so the
                           same flow cannot appear in train and test.

Usage
-----
    from common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig

    cfg  = PreprocessConfig(csv_path="data/ml.csv", cache_dir="data/cache")
    prep = CICIDS2017Preprocessor(cfg)
    bundle = prep.run()                      # cached after the first call

    print(bundle.input_dim, bundle.num_classes)
    train_dl, val_dl, test_dl = prep.make_dataloaders(bundle, batch_size=1024)

Then build any model with the *real* feature count:

    model = ANN(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
"""

from __future__ import annotations

import json
import hashlib
import warnings
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
@dataclass
class PreprocessConfig:
    csv_path: str = "data/ml.csv"
    cache_dir: str = "data/cache"

    # --- I/O efficiency ----------------------------------------------------
    chunksize: int = 500_000          # rows per chunk; caps peak RAM
    float_dtype: str = "float32"      # half the memory of float64
    use_cache: bool = True            # reload .npy instead of re-parsing CSV

    # --- Column hygiene ----------------------------------------------------
    drop_identifier_cols: bool = True   # Flow ID / IPs / timestamps
    drop_port_cols: bool = True         # ports memorise the CICIDS2017 testbed
    drop_constant_cols: bool = True     # zero variance -> zero information
    drop_duplicate_cols: bool = True    # e.g. 'Fwd Header Length.1'
    corr_threshold: float = 0.98        # drop one of each near-collinear pair
    corr_sample_rows: int = 200_000     # correlation on a subsample (speed)

    # --- Row hygiene -------------------------------------------------------
    drop_duplicate_rows: bool = True    # CICIDS2017 is ~20-30% duplicated
    nan_strategy: str = "zero"          # {"zero", "median", "drop"}
    clip_negative: bool = True          # CICFlowMeter emits impossible values
    negative_sentinel_cols: Tuple[str, ...] = (
        "Init_Win_bytes_forward", "Init_Win_bytes_backward",
        "init_win_bytes_forward", "init_win_bytes_backward",
    )                                   # here -1 means "no window", keep it

    # --- Class handling ----------------------------------------------------
    label_col: Optional[str] = None     # auto-detected if None
    merge_web_attacks: bool = False     # True -> 13 classes instead of 15
    benign_cap: Optional[int] = None    # e.g. 500_000 to undersample BENIGN
    min_class_count: int = 2            # classes below this are dropped

    # --- Scaling / splitting ----------------------------------------------
    scaler: str = "quantile"            # {"quantile","standard","robust","log-standard","minmax"}
    n_quantiles: int = 1000
    test_size: float = 0.20
    val_size: float = 0.20              # fraction of the remaining train part
    random_state: int = 42

    # --- Torch -------------------------------------------------------------
    # num_workers=0 is the right default here on two counts. The batches come
    # from an in-memory TensorDataset, so worker processes add IPC overhead
    # without hiding any I/O latency; and on Windows every worker re-imports
    # the entry module, which crashes unless the caller wraps its code in
    # `if __name__ == "__main__":`. Raise it only if you add on-the-fly
    # augmentation, and add the main-guard when you do.
    num_workers: int = 0
    pin_memory: bool = True   # keeps the host->GPU copy async; harmless on CPU


@dataclass
class DataBundle:
    X_train: np.ndarray
    y_train: np.ndarray
    X_val: np.ndarray
    y_val: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray
    feature_names: List[str]
    class_names: List[str]
    class_weights: np.ndarray
    manifest: Dict = field(default_factory=dict)

    @property
    def input_dim(self) -> int:
        return int(self.X_train.shape[1])

    @property
    def num_classes(self) -> int:
        return len(self.class_names)


# ---------------------------------------------------------------------------
# Canonical CICIDS2017 label vocabulary (15 classes)
# ---------------------------------------------------------------------------
CANONICAL_LABELS = {
    "benign": "BENIGN",
    "dos hulk": "DoS Hulk",
    "portscan": "PortScan",
    "port scan": "PortScan",
    "ddos": "DDoS",
    "dos goldeneye": "DoS GoldenEye",
    "ftp-patator": "FTP-Patator",
    "ssh-patator": "SSH-Patator",
    "dos slowloris": "DoS slowloris",
    "dos slowhttptest": "DoS Slowhttptest",
    "bot": "Bot",
    "web attack - brute force": "Web Attack: Brute Force",
    "web attack  brute force": "Web Attack: Brute Force",
    "web attack brute force": "Web Attack: Brute Force",
    "web attack - xss": "Web Attack: XSS",
    "web attack  xss": "Web Attack: XSS",
    "web attack xss": "Web Attack: XSS",
    "web attack - sql injection": "Web Attack: SQL Injection",
    "web attack  sql injection": "Web Attack: SQL Injection",
    "web attack sql injection": "Web Attack: SQL Injection",
    "infiltration": "Infiltration",
    "heartbleed": "Heartbleed",
}

IDENTIFIER_COLS = {
    "flow id", "fwd id", "source ip", "src ip", "destination ip", "dst ip",
    "timestamp", "unnamed: 0", "protocol_name", "flow_id", "similarhttp",
}
PORT_COLS = {"source port", "src port", "destination port", "dst port"}


def _norm(name: str) -> str:
    """Normalise a column/label string for robust matching."""
    return " ".join(str(name).replace("﻿", "").split()).strip().lower()


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
class CICIDS2017Preprocessor:
    def __init__(self, cfg: PreprocessConfig = PreprocessConfig()):
        self.cfg = cfg
        self.cache_dir = Path(cfg.cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.scaler_ = None
        self.report_: Dict = {}

    # -- cache key ---------------------------------------------------------
    def _fingerprint(self) -> str:
        cfg = asdict(self.cfg)
        for volatile in ("num_workers", "pin_memory", "use_cache", "cache_dir"):
            cfg.pop(volatile, None)
        src = Path(self.cfg.csv_path)
        stat = f"{src.name}:{src.stat().st_size}" if src.exists() else src.name
        blob = json.dumps(cfg, sort_keys=True) + "|" + stat
        return hashlib.md5(blob.encode()).hexdigest()[:12]

    # -- step 1: chunked, memory-lean load ---------------------------------
    def _load(self) -> pd.DataFrame:
        cfg = self.cfg
        path = Path(cfg.csv_path)
        if not path.exists():
            raise FileNotFoundError(
                f"{path} not found. Point PreprocessConfig.csv_path at your "
                f"CICIDS2017 ml.csv."
            )

        # NOTE: CICIDS2017 headers carry leading spaces (' Label', ' Flow
        # Duration'). usecols/dtype must use the RAW names, so keep both.
        header = pd.read_csv(path, nrows=0)
        raw_cols = list(header.columns)

        raw_label = cfg.label_col
        if raw_label is None:
            for c in raw_cols:
                if _norm(c) in {"label", "attack", "class", "attack type"}:
                    raw_label = c
                    break
        if raw_label is None:
            raw_label = raw_cols[-1]
            warnings.warn(f"Label column auto-guessed as '{raw_label}'.")
        self.label_col_ = str(raw_label).strip()   # post-strip name

        # Identifier / port columns are skipped AT PARSE TIME with usecols:
        # they are never tokenised, never allocated and never copied. This is
        # cheaper than reading then dropping, and it is also what keeps the
        # float32 dtype map valid (Flow ID and IPs are strings).
        skip = set()
        if cfg.drop_identifier_cols:
            skip |= {c for c in raw_cols if _norm(c) in IDENTIFIER_COLS}
        if cfg.drop_port_cols:
            skip |= {c for c in raw_cols if _norm(c) in PORT_COLS}
        skip.discard(raw_label)
        usecols = [c for c in raw_cols if c not in skip]
        self.report_["skipped_at_parse"] = sorted(str(c).strip() for c in skip)

        # Everything except the label is read as float32 -> ~2.1x less RAM.
        dtypes = {c: cfg.float_dtype for c in usecols if c != raw_label}
        dtypes[raw_label] = "object"
        label_col = self.label_col_

        def _read(dtype_map):
            return pd.read_csv(
                path,
                usecols=usecols,
                dtype=dtype_map,
                engine="c",
                low_memory=False,
                na_values=["Infinity", "-Infinity", "inf", "-inf",
                           "NaN", "nan", ""],
                chunksize=cfg.chunksize,
                on_bad_lines="skip",
            )

        frames = []
        try:
            reader = _read(dtypes)
            for chunk in reader:
                chunk.columns = [str(c).strip() for c in chunk.columns]
                chunk[label_col] = chunk[label_col].astype("category")
                frames.append(chunk)
        except (ValueError, TypeError) as exc:
            # A stray non-numeric column survived the skip list. Re-read
            # untyped and coerce; slower, but the run does not die.
            warnings.warn(f"Strict float32 read failed ({exc}); "
                          f"falling back to coercion.")
            frames = []
            label_norm = label_col
            for chunk in _read(None):
                chunk.columns = [str(c).strip() for c in chunk.columns]
                feats = [c for c in chunk.columns if c != label_norm]
                chunk[feats] = chunk[feats].apply(
                    pd.to_numeric, errors="coerce").astype(cfg.float_dtype)
                chunk[label_norm] = chunk[label_norm].astype("category")
                frames.append(chunk)

        df = pd.concat(frames, ignore_index=True, copy=False)
        del frames
        self.report_["rows_raw"] = int(len(df))
        self.report_["cols_raw"] = int(df.shape[1])
        return df

    # -- step 2: column hygiene -------------------------------------------
    def _clean_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        cfg = self.cfg
        dropped: Dict[str, List[str]] = {}

        drop = []
        if cfg.drop_identifier_cols:
            drop += [c for c in df.columns if _norm(c) in IDENTIFIER_COLS]
        if cfg.drop_port_cols:
            drop += [c for c in df.columns if _norm(c) in PORT_COLS]
        drop = [c for c in dict.fromkeys(drop) if c != self.label_col_]
        if drop:
            df = df.drop(columns=drop)
            dropped["identifier/port"] = drop

        if cfg.drop_duplicate_cols:
            # Duplicate *content* (the classic 'Fwd Header Length.1' twin).
            feats = [c for c in df.columns if c != self.label_col_]
            seen, dup = {}, []
            sample = df[feats].head(50_000)
            for c in feats:
                key = hashlib.md5(
                    np.ascontiguousarray(sample[c].to_numpy())
                ).hexdigest()
                if key in seen:
                    dup.append(c)
                else:
                    seen[key] = c
            if dup:
                df = df.drop(columns=dup)
                dropped["duplicate_columns"] = dup

        self.report_["dropped_columns"] = dropped
        return df

    # -- step 3: row hygiene ----------------------------------------------
    def _clean_rows(self, df: pd.DataFrame) -> pd.DataFrame:
        cfg = self.cfg
        feats = [c for c in df.columns if c != self.label_col_]

        # inf -> NaN (Flow Bytes/s and Flow Packets/s are the usual offenders)
        df[feats] = df[feats].replace([np.inf, -np.inf], np.nan)
        n_nan = int(df[feats].isna().to_numpy().sum())

        if cfg.nan_strategy == "drop":
            df = df.dropna(subset=feats)
        elif cfg.nan_strategy == "median":
            df[feats] = df[feats].fillna(df[feats].median(numeric_only=True))
        else:
            df[feats] = df[feats].fillna(0.0)
        df = df.dropna(subset=[self.label_col_])

        if cfg.clip_negative:
            sentinel = {c for c in feats
                        if _norm(c) in {_norm(s) for s in cfg.negative_sentinel_cols}}
            clip_cols = [c for c in feats if c not in sentinel]
            arr = df[clip_cols].to_numpy(copy=False)
            np.clip(arr, 0, None, out=arr)
            df[clip_cols] = arr

        before = len(df)
        if cfg.drop_duplicate_rows:
            # BEFORE the split — otherwise identical flows leak across splits
            # and every reported metric is optimistic.
            df = df.drop_duplicates()
        self.report_["duplicate_rows_removed"] = int(before - len(df))
        self.report_["nan_or_inf_cells"] = n_nan

        if cfg.drop_constant_cols:
            feats = [c for c in df.columns if c != self.label_col_]
            nun = df[feats].nunique(dropna=False)
            const = nun[nun <= 1].index.tolist()
            if const:
                df = df.drop(columns=const)
                self.report_.setdefault("dropped_columns", {})["constant"] = const

        return df

    # -- step 4: collinearity pruning --------------------------------------
    def _prune_correlated(self, df: pd.DataFrame) -> pd.DataFrame:
        thr = self.cfg.corr_threshold
        if not thr or thr >= 1.0:
            return df
        feats = [c for c in df.columns if c != self.label_col_]
        n = min(len(df), self.cfg.corr_sample_rows)
        sample = df[feats].sample(n=n, random_state=self.cfg.random_state) \
            if len(df) > n else df[feats]

        corr = np.corrcoef(sample.to_numpy(dtype=np.float64, copy=False), rowvar=False)
        corr = np.nan_to_num(corr)
        upper = np.triu(np.abs(corr), k=1)
        to_drop = {feats[j] for i, j in zip(*np.where(upper > thr))}
        if to_drop:
            df = df.drop(columns=list(to_drop))
            self.report_.setdefault("dropped_columns", {})["collinear"] = sorted(to_drop)
        return df

    # -- step 5: labels -----------------------------------------------------
    def _encode_labels(self, df: pd.DataFrame):
        cfg = self.cfg
        raw = df[self.label_col_].astype(str).map(
            lambda s: CANONICAL_LABELS.get(_norm(s.replace("\x96", "-")), s.strip())
        )
        if cfg.merge_web_attacks:
            raw = raw.map(lambda s: "Web Attack" if s.startswith("Web Attack") else s)

        counts = raw.value_counts()
        keep = counts[counts >= cfg.min_class_count].index
        mask = raw.isin(keep)
        df, raw = df[mask], raw[mask]

        if cfg.benign_cap is not None:
            # Undersampling BENIGN is the single largest epoch-time saving on
            # CICIDS2017 (BENIGN is ~80% of rows) and it improves minority
            # recall. Report the cap in the paper.
            idx = np.arange(len(raw))
            ben = idx[(raw == "BENIGN").to_numpy()]
            rng = np.random.default_rng(cfg.random_state)
            if len(ben) > cfg.benign_cap:
                drop = rng.choice(ben, size=len(ben) - cfg.benign_cap, replace=False)
                keep_mask = np.ones(len(raw), dtype=bool)
                keep_mask[drop] = False
                df, raw = df[keep_mask], raw[keep_mask]

        class_names = sorted(raw.unique().tolist())
        # BENIGN is index 0 by convention (useful for binary collapse later).
        if "BENIGN" in class_names:
            class_names.remove("BENIGN")
            class_names = ["BENIGN"] + class_names
        mapping = {c: i for i, c in enumerate(class_names)}
        y = raw.map(mapping).to_numpy(dtype=np.int64)

        X = df.drop(columns=[self.label_col_])
        self.report_["class_distribution"] = {
            c: int((y == i).sum()) for c, i in mapping.items()
        }
        return X, y, class_names

    # -- step 6: split + scale ---------------------------------------------
    def _split_and_scale(self, X: pd.DataFrame, y: np.ndarray):
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import (QuantileTransformer, StandardScaler,
                                           RobustScaler, MinMaxScaler,
                                           FunctionTransformer)
        from sklearn.pipeline import Pipeline

        cfg = self.cfg
        feature_names = X.columns.tolist()
        Xv = X.to_numpy(dtype=np.float32, copy=False)

        X_tmp, X_test, y_tmp, y_test = train_test_split(
            Xv, y, test_size=cfg.test_size, stratify=y,
            random_state=cfg.random_state)
        X_train, X_val, y_train, y_val = train_test_split(
            X_tmp, y_tmp, test_size=cfg.val_size, stratify=y_tmp,
            random_state=cfg.random_state)
        del X_tmp, y_tmp

        if cfg.scaler == "quantile":
            scaler = QuantileTransformer(
                n_quantiles=min(cfg.n_quantiles, len(X_train)),
                output_distribution="normal",
                subsample=200_000,
                random_state=cfg.random_state,
                copy=False,
            )
        elif cfg.scaler == "robust":
            scaler = RobustScaler(copy=False)
        elif cfg.scaler == "minmax":
            scaler = MinMaxScaler(copy=False)
        elif cfg.scaler == "log-standard":
            scaler = Pipeline([
                ("log1p", FunctionTransformer(np.log1p, validate=False)),
                ("std", StandardScaler(copy=False)),
            ])
        else:
            scaler = StandardScaler(copy=False)

        # FIT ON TRAIN ONLY — this is the line that keeps the results honest.
        X_train = scaler.fit_transform(X_train).astype(np.float32, copy=False)
        X_val = scaler.transform(X_val).astype(np.float32, copy=False)
        X_test = scaler.transform(X_test).astype(np.float32, copy=False)
        self.scaler_ = scaler

        return (X_train, y_train, X_val, y_val, X_test, y_test, feature_names)

    # -- orchestration ------------------------------------------------------
    def run(self) -> DataBundle:
        cfg = self.cfg
        key = self._fingerprint()
        cdir = self.cache_dir / key

        if cfg.use_cache and (cdir / "manifest.json").exists():
            return self._load_cache(cdir)

        df = self._load()
        df = self._clean_columns(df)
        df = self._clean_rows(df)
        df = self._prune_correlated(df)
        X, y, class_names = self._encode_labels(df)
        del df

        (X_train, y_train, X_val, y_val,
         X_test, y_test, feature_names) = self._split_and_scale(X, y)

        counts = np.bincount(y_train, minlength=len(class_names)).astype(np.float64)
        # Inverse-frequency weights, normalised to mean 1 so the loss scale
        # stays comparable to the unweighted run.
        w = np.where(counts > 0, counts.sum() / (len(class_names) * np.maximum(counts, 1)), 0.0)
        class_weights = (w / w[w > 0].mean()).astype(np.float32)

        manifest = {
            "cache_key": key,
            "input_dim": int(X_train.shape[1]),
            "num_classes": len(class_names),
            "class_names": class_names,
            "feature_names": feature_names,
            "n_train": int(len(y_train)),
            "n_val": int(len(y_val)),
            "n_test": int(len(y_test)),
            "config": asdict(cfg),
            "report": self.report_,
        }

        bundle = DataBundle(X_train, y_train, X_val, y_val, X_test, y_test,
                            feature_names, class_names, class_weights, manifest)
        if cfg.use_cache:
            self._save_cache(cdir, bundle)
        return bundle

    # -- cache I/O ----------------------------------------------------------
    def _save_cache(self, cdir: Path, b: DataBundle) -> None:
        cdir.mkdir(parents=True, exist_ok=True)
        for name in ("X_train", "y_train", "X_val", "y_val", "X_test", "y_test"):
            np.save(cdir / f"{name}.npy", getattr(b, name))
        np.save(cdir / "class_weights.npy", b.class_weights)
        (cdir / "manifest.json").write_text(json.dumps(b.manifest, indent=2))
        try:
            import joblib
            joblib.dump(self.scaler_, cdir / "scaler.joblib")
        except Exception:
            pass

    def _load_cache(self, cdir: Path) -> DataBundle:
        manifest = json.loads((cdir / "manifest.json").read_text())
        # mmap_mode='r' -> arrays are paged in on demand, so a 2 GB cache
        # costs no resident memory until the batch actually touches it.
        ld = lambda n: np.load(cdir / f"{n}.npy", mmap_mode="r")
        self.report_ = manifest.get("report", {})
        try:
            import joblib
            self.scaler_ = joblib.load(cdir / "scaler.joblib")
        except Exception:
            pass
        return DataBundle(
            ld("X_train"), np.load(cdir / "y_train.npy"),
            ld("X_val"), np.load(cdir / "y_val.npy"),
            ld("X_test"), np.load(cdir / "y_test.npy"),
            manifest["feature_names"], manifest["class_names"],
            np.load(cdir / "class_weights.npy"), manifest,
        )

    # -- torch plumbing -----------------------------------------------------
    def make_dataloaders(self, b: DataBundle, batch_size: int = 1024,
                         balanced_sampler: bool = False):
        import torch
        from torch.utils.data import TensorDataset, DataLoader, WeightedRandomSampler

        def ds(X, y):
            return TensorDataset(torch.from_numpy(np.ascontiguousarray(X)),
                                 torch.from_numpy(np.ascontiguousarray(y)))

        train_ds, val_ds, test_ds = (ds(b.X_train, b.y_train),
                                     ds(b.X_val, b.y_val),
                                     ds(b.X_test, b.y_test))

        common = dict(num_workers=self.cfg.num_workers,
                      pin_memory=self.cfg.pin_memory,
                      persistent_workers=self.cfg.num_workers > 0,
                      drop_last=False)

        if balanced_sampler:
            w = b.class_weights[b.y_train]
            sampler = WeightedRandomSampler(torch.as_tensor(w, dtype=torch.double),
                                            num_samples=len(w), replacement=True)
            train_dl = DataLoader(train_ds, batch_size=batch_size,
                                  sampler=sampler, **common)
        else:
            train_dl = DataLoader(train_ds, batch_size=batch_size,
                                  shuffle=True, **common)

        val_dl = DataLoader(val_ds, batch_size=batch_size * 4, shuffle=False, **common)
        test_dl = DataLoader(test_ds, batch_size=batch_size * 4, shuffle=False, **common)
        return train_dl, val_dl, test_dl

    # -- reporting ----------------------------------------------------------
    def summary(self, b: DataBundle) -> str:
        r = b.manifest.get("report", {})
        lines = [
            "CICIDS2017 preprocessing summary",
            "=" * 60,
            f"raw rows / cols        : {r.get('rows_raw')} / {r.get('cols_raw')}",
            f"NaN or +/-inf cells    : {r.get('nan_or_inf_cells')}",
            f"duplicate rows removed : {r.get('duplicate_rows_removed')}",
            f"final feature count    : {b.input_dim}",
            f"classes                : {b.num_classes}",
            f"split (train/val/test) : {len(b.y_train)} / {len(b.y_val)} / {len(b.y_test)}",
            f"scaler                 : {self.cfg.scaler}",
            "",
            "dropped columns by reason:",
        ]
        for reason, cols in (r.get("dropped_columns") or {}).items():
            lines.append(f"  {reason:<18} ({len(cols)}): {', '.join(cols[:8])}"
                         + (" ..." if len(cols) > 8 else ""))
        lines += ["", "class distribution:"]
        for c, n in sorted((r.get("class_distribution") or {}).items(),
                           key=lambda kv: -kv[1]):
            lines.append(f"  {c:<28} {n:>10,}")
        return "\n".join(lines)
