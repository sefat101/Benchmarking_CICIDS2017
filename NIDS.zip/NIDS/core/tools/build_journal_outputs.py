"""
Regenerate every journal artefact. Code lives in core/; artefacts are written
OUTSIDE core/, into the per-model folders at the project root.

    python core/tools/build_journal_outputs.py [--input-dim 78] [--num-classes 15]

Writes, for each model, into <project_root>/<id>/ :
    README.md          methods text, hyperparameters, verified trace, LaTeX
    architecture.svg   print-ready block diagram
    architecture.mmd   Mermaid source for the same diagram
    summary.txt        torchinfo layer table
    shape_trace.txt    per-layer input/output shapes for a [32, F] batch
    params.json        machine-readable metrics

and at the project root: comparison.csv, comparison.md, verification_log.txt.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import torch

CORE = Path(__file__).resolve().parents[1]      # .../core
ROOT = CORE.parent                              # project root (E:\NIDS)
sys.path.insert(0, str(ROOT))

from core.models import REGISTRY, build                      # noqa: E402
from core.common.model_utils import (                        # noqa: E402
    count_parameters, parameters_by_module, trace_shapes, analytic_macs,
    measure_latency, render_svg, render_mermaid,
)


def torchinfo_summary(model, input_dim) -> str:
    try:
        from torchinfo import summary
        return str(summary(model, input_size=(32, input_dim), verbose=0,
                           col_names=("input_size", "output_size",
                                      "num_params", "kernel_size"),
                           row_settings=("var_names",)))
    except Exception as exc:                    # torchinfo is optional
        return f"[torchinfo unavailable: {exc}]"


def write_readme(folder: Path, meta, stats, trace, out_shape, module_file):
    hp = "\n".join(f"| `{k}` | {v} | {d} |" for k, v, d in meta["hyperparams"])
    blocks = "\n".join(
        f"| {i+1} | {label} | {sub} |"
        for i, (_k, label, sub) in enumerate(meta["blocks"]))
    layers = "\n".join(
        f"| `{r['layer']}` | {r['type']} | {r['in']} | {r['out']} | {r['params']:,} |"
        for r in trace)
    notes = "\n".join(f"- {n}" for n in meta["notes"])

    txt = f"""# {meta['id']} — {meta['name']}

**{meta['full_name']}** · family: *{meta['family']}*

{meta['tagline']}

> **Source code:** [`core/models/{module_file}`](../core/models/{module_file}) — class `{meta['class_name']}`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `{meta['input_shape']}` (raw 2D tabular batch) |
| Output tensor | `{meta['output_shape']}` — {meta['output_semantics']} |
| Verified output for `torch.randn(32, {stats['input_dim']})` | `{out_shape}` |
| Reshaping | {meta['reshape_strategy']} |
| Parameters (total / trainable) | {stats['total_parameters']:,} / {stats['trainable_parameters']:,} |
| Model size (fp32) | {stats['size_fp32_mb']} MB |
| MACs per sample | {stats['macs_per_sample']:,} |
| CPU latency @ batch 32 | {stats['latency']['latency_ms_per_batch']} ms ({stats['latency']['throughput_samples_per_s']:,.0f} samples/s) |

## 2. Inductive bias — why this model is in the study

{meta['inductive_bias']}

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
{blocks}

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
{hp}

## 4. Verified layer trace (`torch.randn(32, {stats['input_dim']})`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
{layers}

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
{meta['latex']}
```

## 6. Reporting notes

{notes}

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import {meta['class_name']}

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = {meta['class_name']}(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
"""
    (folder / "README.md").write_text(txt, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-dim", type=int, default=78)
    ap.add_argument("--num-classes", type=int, default=15)
    args = ap.parse_args()

    torch.manual_seed(0)
    rows, log = [], []

    for model_id, (module_file, _cls, meta) in REGISTRY.items():
        folder = ROOT / model_id
        folder.mkdir(parents=True, exist_ok=True)
        model = build(model_id, args.input_dim, args.num_classes)

        x = torch.randn(32, args.input_dim)
        trace, out = trace_shapes(model, x)
        out_t = out[0] if isinstance(out, tuple) else out
        out_shape = "x".join(str(s) for s in out_t.shape)

        stats = count_parameters(model)
        stats["input_dim"] = args.input_dim
        stats["num_classes"] = args.num_classes
        stats["source_file"] = f"core/models/{module_file}"
        stats["macs_per_sample"] = analytic_macs(model, x)
        stats["latency"] = measure_latency(model, args.input_dim, 32)
        stats["latency_bs1024"] = measure_latency(model, args.input_dim, 1024,
                                                  warmup=2, iters=8)
        stats["output_shape_bs32"] = out_shape
        stats["modules"] = [{"name": n, "type": t, "params": p}
                            for n, t, p in parameters_by_module(model)]
        stats["meta"] = {k: meta[k] for k in
                         ("id", "name", "full_name", "family", "class_name",
                          "input_shape", "output_shape", "output_semantics",
                          "reshape_strategy")}

        (folder / "summary.txt").write_text(
            f"{meta['name']} — torchinfo summary (input 32x{args.input_dim})\n"
            f"source: core/models/{module_file}\n\n"
            + torchinfo_summary(model, args.input_dim) + "\n", encoding="utf-8")

        trace_lines = [
            f"{meta['name']}: shape trace for torch.randn(32, {args.input_dim})",
            f"source: core/models/{module_file}",
            "=" * 88,
            f"{'layer':<28}{'type':<22}{'input':<16}{'output':<16}{'params':>8}",
            "-" * 88]
        for r in trace:
            trace_lines.append(
                f"{r['layer']:<28}{r['type']:<22}{r['in']:<16}{r['out']:<16}"
                f"{r['params']:>8,}")
        trace_lines += ["-" * 88,
                        f"final output: {out_shape}  ({meta['output_semantics']})",
                        f"total parameters: {stats['total_parameters']:,}"]
        (folder / "shape_trace.txt").write_text("\n".join(trace_lines) + "\n",
                                                encoding="utf-8")

        (folder / "params.json").write_text(json.dumps(stats, indent=2),
                                            encoding="utf-8")
        (folder / "architecture.svg").write_text(render_svg(meta, stats),
                                                 encoding="utf-8")
        (folder / "architecture.mmd").write_text(render_mermaid(meta),
                                                 encoding="utf-8")
        write_readme(folder, meta, stats, trace, out_shape, module_file)

        rows.append({
            "id": meta["id"],
            "model": meta["name"],
            "family": meta["family"],
            "class": meta["class_name"],
            "source_file": f"core/models/{module_file}",
            "input_shape": f"[32, {args.input_dim}]",
            "output_shape": f"[{out_shape.replace('x', ', ')}]",
            "output_type": meta["output_semantics"],
            "reshape_in_forward": meta["reshape_strategy"].split(";")[0]
                                      .split(". ")[0].strip().rstrip("."),
            "total_parameters": stats["total_parameters"],
            "size_fp32_mb": stats["size_fp32_mb"],
            "macs_per_sample": stats["macs_per_sample"],
            "latency_ms_bs32": stats["latency"]["latency_ms_per_batch"],
            "throughput_sps_bs1024": stats["latency_bs1024"]["throughput_samples_per_s"],
            "n_leaf_layers": len(trace),
        })
        log.append(f"{meta['name']:<14} torch.randn(32, {args.input_dim}) -> "
                   f"[{out_shape.replace('x', ', ')}]   "
                   f"{stats['total_parameters']:>9,} params   OK")
        print(log[-1])

    with open(ROOT / "comparison.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    hdr = list(rows[0].keys())
    md = ["# Baseline comparison — CICIDS2017 (ml.csv), 8 architectures", "",
          f"Verified with `torch.randn(32, {args.input_dim})`, "
          f"`num_classes={args.num_classes}`, PyTorch {torch.__version__}, CPU.", "",
          "| " + " | ".join(hdr) + " |",
          "|" + "|".join("---" for _ in hdr) + "|"]
    for r in rows:
        md.append("| " + " | ".join(
            f"{v:,}" if isinstance(v, int) else str(v) for v in r.values()) + " |")
    md += ["", "Latency measured single-threaded on CPU; treat it as a relative "
           "ordering, not an absolute deployment figure.", ""]
    (ROOT / "comparison.md").write_text("\n".join(md), encoding="utf-8")
    (ROOT / "verification_log.txt").write_text("\n".join(log) + "\n",
                                               encoding="utf-8")
    print(f"\nArtefacts written to the project root: {ROOT}")


if __name__ == "__main__":
    main()
