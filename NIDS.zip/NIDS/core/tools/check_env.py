"""
Environment check. Run this first, before anything else:

    python core/tools/check_env.py

It reports the Python / PyTorch / CUDA versions, the GPU and its compute
capability, and — the part that actually matters on a Pascal card — whether
the installed PyTorch wheel was built with kernels for your GPU. A wheel
without your architecture imports fine and reports `cuda.is_available() ==
True`, then fails at the first kernel launch with

    CUDA error: no kernel image is available for execution on the device

so the check below runs a real matmul on the GPU rather than trusting the
availability flag.
"""

from __future__ import annotations

import platform
import sys


# GTX 1070 = GP104 = Pascal = compute capability 6.1
KNOWN_LEGACY = {
    (5, 0): "Maxwell", (5, 2): "Maxwell", (5, 3): "Maxwell",
    (6, 0): "Pascal", (6, 1): "Pascal", (6, 2): "Pascal",
    (7, 0): "Volta",
}


def main() -> int:
    print("=" * 70)
    print("ENVIRONMENT CHECK — NIDS baselines")
    print("=" * 70)
    print(f"Python        : {sys.version.split()[0]}  ({platform.machine()})")
    print(f"Platform      : {platform.system()} {platform.release()}")
    print(f"Executable    : {sys.executable}")

    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    print(f"Virtualenv    : {'yes' if in_venv else 'NO — you are in the system interpreter'}")

    try:
        import torch
    except ImportError:
        print("\nPyTorch       : NOT INSTALLED")
        print("  pip install torch --index-url https://download.pytorch.org/whl/cu126")
        return 1

    print(f"PyTorch       : {torch.__version__}")
    print(f"Built for CUDA: {torch.version.cuda or 'CPU-only build'}")

    for name in ("numpy", "pandas", "sklearn", "joblib", "torchinfo"):
        try:
            mod = __import__(name)
            print(f"{name:<14}: {getattr(mod, '__version__', 'ok')}")
        except ImportError:
            optional = name == "torchinfo"
            print(f"{name:<14}: MISSING{' (optional)' if optional else ''}")

    print("-" * 70)

    if not torch.cuda.is_available():
        print("CUDA          : not available — training will run on the CPU.")
        if torch.version.cuda is None:
            print("  This is a CPU-only wheel. Reinstall with:")
            print("    pip uninstall -y torch")
            print("    pip install torch --index-url https://download.pytorch.org/whl/cu126")
        else:
            print(f"  The wheel is a CUDA {torch.version.cuda} build, so the GPU or "
                  f"its driver\n  is not visible. Check `nvidia-smi` runs and "
                  f"reports a driver version.")
        return 0

    idx = torch.cuda.current_device()
    name = torch.cuda.get_device_name(idx)
    cap = torch.cuda.get_device_capability(idx)
    vram = torch.cuda.get_device_properties(idx).total_memory / 1024 ** 3
    arch_list = torch.cuda.get_arch_list()

    print(f"GPU           : {name}")
    print(f"Capability    : sm_{cap[0]}{cap[1]}"
          + (f"  ({KNOWN_LEGACY[cap]})" if cap in KNOWN_LEGACY else ""))
    print(f"VRAM          : {vram:.1f} GB")
    print(f"Wheel kernels : {', '.join(arch_list)}")

    target = f"sm_{cap[0]}{cap[1]}"
    if target not in arch_list:
        print(f"\n  !! This wheel has NO kernels for {target}.")
        print("     Uninstall it and install a CUDA 12.6 build, which is the")
        print("     last line carrying Maxwell / Pascal / Volta kernels:")
        print("       pip uninstall -y torch")
        print("       pip install torch --index-url https://download.pytorch.org/whl/cu126")

    # The real test: launch a kernel.
    print("-" * 70)
    try:
        a = torch.randn(512, 512, device="cuda")
        b = (a @ a).sum().item()
        torch.cuda.synchronize()
        print(f"GPU matmul    : OK  (checksum {b:.3f})")
    except Exception as exc:
        print(f"GPU matmul    : FAILED — {type(exc).__name__}: {exc}")
        print("  The GPU is visible but this wheel cannot run kernels on it.")
        return 1

    # Pascal has no tensor cores: fp16 autocast buys little and can be slower.
    if cap[0] < 7:
        print("\nNote: this GPU predates tensor cores, so torch.amp / fp16 gives "
              "little\n      or no speed-up. Train in fp32; TF32 does not exist "
              "on this architecture.")

    print("\nAll good — run:  python core/verify_all.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
