"""
=============================================================================
 VERIFICATION BLOCK — passes torch.randn(32, 78) through all 8 architectures
 and prints the output shapes.

     python core/verify_all.py
=============================================================================
"""

import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.models import (REGISTRY, build, Autoencoder, Encoder)  # noqa: E402


if __name__ == "__main__":
    torch.manual_seed(0)

    BATCH, FEATURES, CLASSES = 32, 78, 15
    x = torch.randn(BATCH, FEATURES)

    print(f"PyTorch {torch.__version__}")
    print(f"Dummy input: torch.randn({BATCH}, {FEATURES})   num_classes={CLASSES}\n")
    print(f"{'#':<3}{'MODEL':<14}{'CLASS':<18}{'OUTPUT SHAPE':<22}"
          f"{'PARAMS':>11}  {'SEMANTICS'}")
    print("-" * 100)

    failures = []
    for i, (model_id, (module_file, _cls, meta)) in enumerate(REGISTRY.items(), 1):
        model = build(model_id, FEATURES, CLASSES)
        model.eval()
        with torch.no_grad():
            out = model(x)
        out_t = out[0] if isinstance(out, tuple) else out
        n_params = sum(p.numel() for p in model.parameters())

        print(f"{i:<3}{meta['name']:<14}{meta['class_name']:<18}"
              f"{str(tuple(out_t.shape)):<22}{n_params:>11,}  "
              f"{meta['output_semantics']}")

        if out_t.shape[0] != BATCH or not torch.isfinite(out_t).all():
            failures.append(meta["name"])

    print("-" * 100)

    # The two non-classifier models must NOT emit logits.
    ae, enc = Autoencoder(input_dim=FEATURES), Encoder(input_dim=FEATURES)
    with torch.no_grad():
        recon, latent = ae(x, return_latent=True)
        emb = enc(x)
        err = ae.reconstruction_error(x)
        head_out = Encoder(input_dim=FEATURES, attach_head=True)(x)
    print(f"Autoencoder  : recon {tuple(recon.shape)} | latent {tuple(latent.shape)} "
          f"| per-sample error {tuple(err.shape)}")
    print(f"Encoder      : embedding {tuple(emb.shape)} | with head -> {tuple(head_out.shape)}")

    assert recon.shape == x.shape, "autoencoder must reconstruct the input shape"
    assert latent.shape == (BATCH, 32), "latent must be [B, 32]"
    assert emb.shape == (BATCH, 32), "encoder must emit [B, 32]"

    # Shape-agnosticism: the same classes accept 80 features unchanged.
    x80 = torch.randn(8, 80)
    for model_id in REGISTRY:
        m = build(model_id, 80, CLASSES)
        m.eval()
        with torch.no_grad():
            m(x80)
    print(f"Shape check  : all {len(REGISTRY)} classes also accept torch.randn(8, 80) "
          "(pass bundle.input_dim, never a hardcoded 78)")

    print()
    if failures:
        print(f"FAILED: {failures}")
        sys.exit(1)
    print(f"All {len(REGISTRY)} architectures compiled and produced finite outputs.")
