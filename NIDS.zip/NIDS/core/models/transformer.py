"""
05 — Transformer (encoder-only) adapted to 1D tabular flow features.

Input : [batch_size, input_dim]
Output: [batch_size, num_classes]

Tokenisation strategy (handled inside forward()):
    [B, F] -> unsqueeze(-1) -> [B, F, 1] -> Linear(1, d_model) -> [B, F, d_model]
i.e. EVERY FEATURE IS A TOKEN. A learnable positional embedding of shape
[1, F, d_model] restores the column identity that self-attention would
otherwise discard, and the sequence is mean-pooled before classification.
"""

import torch
import torch.nn as nn


class TabTransformer(nn.Module):
    """Feature-as-token encoder-only Transformer."""

    def __init__(self, input_dim: int = 78, num_classes: int = 15,
                 d_model: int = 64, nhead: int = 4, num_layers: int = 2,
                 dim_feedforward: int = 128, dropout: float = 0.1,
                 pool: str = "mean"):
        super().__init__()
        assert d_model % nhead == 0, "d_model must be divisible by nhead"
        assert pool in {"mean", "cls"}
        self.input_dim = input_dim
        self.d_model = d_model
        self.pool = pool

        # Scalar feature value -> d_model token embedding (shared across columns).
        self.value_proj = nn.Linear(1, d_model)

        # Learnable per-column positional embedding (column identity).
        self.pos_embed = nn.Parameter(torch.zeros(1, input_dim, d_model))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        # Optional [CLS] token (used when pool="cls").
        self.cls_token = nn.Parameter(torch.zeros(1, 1, d_model))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,          # <-- ATTENTION/FFN DROPOUT LIVES HERE
            activation="gelu",
            batch_first=True,
            norm_first=True,          # pre-LN: more stable for shallow stacks
        )
        self.encoder = nn.TransformerEncoder(
            layer, num_layers=num_layers,
            enable_nested_tensor=False,   # no padding mask -> nested is a no-op
        )
        self.norm = nn.LayerNorm(d_model)
        # nn.Dropout(0.1)             # <-- ADD HEAD DROPOUT HERE
        self.classifier = nn.Linear(d_model, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F] -> [B, F, 1]  (RESHAPE HANDLED HERE)
        x = x.unsqueeze(-1)
        x = self.value_proj(x)                 # [B, F, d_model]
        x = x + self.pos_embed                 # inject column identity

        if self.pool == "cls":
            cls = self.cls_token.expand(x.size(0), -1, -1)   # [B, 1, d_model]
            x = torch.cat([cls, x], dim=1)                   # [B, F+1, d_model]

        x = self.encoder(x)                    # [B, T, d_model]
        x = self.norm(x)

        x = x[:, 0] if self.pool == "cls" else x.mean(dim=1)  # [B, d_model]
        return self.classifier(x)              # [B, num_classes]

    @torch.no_grad()
    def attention_rollout(self, x: torch.Tensor):
        """
        Convenience hook for the interpretability figure: returns the
        per-column attention received, averaged over heads and layers.
        Requires re-running the stack with need_weights=True, so it is kept
        out of forward() for speed. Implement per-layer capture here if the
        journal figure needs it.
        """
        raise NotImplementedError(
            "Register forward hooks on encoder.layers[i].self_attn to collect "
            "attention maps; see README for the recommended recipe."
        )


MODEL_META = {
    "id": "05_transformer",
    "name": "Transformer",
    "full_name": "Encoder-only Transformer (feature-as-token)",
    "family": "Attention",
    "class_name": "TabTransformer",
    "tagline": "Treats each of the 78 flow statistics as a token and lets "
               "self-attention learn the full pairwise feature-interaction "
               "graph.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits",
    "reshape_strategy": "x.unsqueeze(-1) -> [B, F, 1], then a shared "
                        "Linear(1, d_model) lifts every scalar to a token; a "
                        "learnable [1, F, d_model] positional embedding is "
                        "added.",
    "inductive_bias": "No locality assumption — attention is permutation-"
                      "equivariant and the positional embedding is learned, "
                      "so the model can discover long-range feature "
                      "interactions (e.g. flow duration paired with backward "
                      "IAT std) that the 1D-CNN can only reach through "
                      "stacked receptive fields. The cost is quadratic "
                      "attention in F and the largest per-sample latency of "
                      "the eight baselines.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("reshape", "unsqueeze(-1)", "[B, 78, 1]"),
        ("linear", "Value projection", "1 -> 64 (d_model)"),
        ("attn", "+ Positional embedding", "[1, 78, 64] learnable"),
        ("attn", "TransformerEncoderLayer x2", "4 heads, FFN 128, pre-LN"),
        ("pool", "Mean pool over tokens", "[B, 64]"),
        ("out", "Linear (classifier)", "64 -> 15"),
    ],
    "hyperparams": [
        ("d_model", "64", "Token embedding width"),
        ("nhead", "4", "Attention heads (head dim = 16)"),
        ("num_layers", "2", "Encoder blocks (kept shallow by design)"),
        ("dim_feedforward", "128", "FFN inner width (2x d_model)"),
        ("dropout", "0.1", "Applied inside attention and FFN"),
        ("pool", "mean", "Alternative: 'cls' token pooling"),
    ],
    "latex": (
        "Each scalar feature $x_i$ is embedded as "
        "$\\mathbf{t}_i=\\mathbf{W}_v x_i+\\mathbf{b}_v+\\mathbf{p}_i"
        "\\in\\mathbb{R}^{d}$, where $\\mathbf{p}_i$ is a learnable "
        "column-positional code. The token matrix "
        "$\\mathbf{T}\\in\\mathbb{R}^{F\\times d}$ is processed by $L=2$ "
        "pre-norm encoder blocks, each computing\n"
        "\\begin{align}\n"
        "\\mathrm{Attn}(\\mathbf{T})&=\\mathrm{softmax}\\!\\left("
        "\\frac{\\mathbf{Q}\\mathbf{K}^{\\top}}{\\sqrt{d/h}}\\right)\\mathbf{V},"
        "\\\\\n"
        "\\mathbf{T}'&=\\mathbf{T}+\\mathrm{Attn}(\\mathrm{LN}(\\mathbf{T})),"
        "\\qquad\n"
        "\\mathbf{T}''=\\mathbf{T}'+\\mathrm{FFN}(\\mathrm{LN}(\\mathbf{T}')),\n"
        "\\end{align}\n"
        "with $h=4$ heads. The sequence is reduced by mean pooling, "
        "$\\bar{\\mathbf{t}}=\\tfrac{1}{F}\\sum_i \\mathbf{T}''_i$, and mapped "
        "to logits by a single affine layer."
    ),
    "notes": [
        "Complexity is O(F^2 d) per sample; with F = 78 the attention matrix "
        "is 78x78, which is small enough to visualise directly — a "
        "head-averaged attention heat-map over named CICFlowMeter columns is "
        "a strong interpretability figure and differentiates the paper from "
        "the accuracy-only NIDS literature.",
        "Pre-LN (norm_first=True) is used because 2-layer post-LN stacks "
        "need a warm-up schedule to converge; state this to justify the "
        "deviation from the vanilla formulation.",
        "If throughput matters, report tokens/second alongside accuracy — "
        "this model is the natural 'upper bound on cost' row.",
    ],
}
