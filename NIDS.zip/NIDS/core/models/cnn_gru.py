"""
08 — CNN-GRU hybrid: 1D convolutional spatial extraction -> GRU.

Input : [batch_size, input_dim]
Output: [batch_size, num_classes]

Pipeline inside forward():
    [B, F] --unsqueeze(1)--> [B, 1, F] --conv/pool--> [B, C, L]
          --permute(0,2,1)--> [B, L, C] --GRU--> last hidden --> logits
"""

import torch
import torch.nn as nn


class CNNFrontEnd(nn.Module):
    """Shared convolutional stem (duplicated so each folder stands alone)."""

    def __init__(self, channels=(32, 64), kernel_size: int = 3):
        super().__init__()
        c1, c2 = channels
        pad = kernel_size // 2
        self.net = nn.Sequential(
            nn.Conv1d(1, c1, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c1),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(c1, c2, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c2),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.2),      # <-- ADD DROPOUT HERE
        )
        self.out_channels = c2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)   # [B, C, L]


class CNNGRU(nn.Module):
    """Conv stem -> GRU -> linear classifier."""

    def __init__(self, input_dim: int = 78, num_classes: int = 15,
                 channels=(32, 64), kernel_size: int = 3,
                 hidden_size: int = 64, num_layers: int = 1,
                 bidirectional: bool = False):
        super().__init__()
        self.input_dim = input_dim
        self.cnn = CNNFrontEnd(channels=channels, kernel_size=kernel_size)

        self.gru = nn.GRU(
            input_size=self.cnn.out_channels,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=bidirectional,
            # dropout=0.2,        # <-- ONLY EFFECTIVE WHEN num_layers > 1
        )

        directions = 2 if bidirectional else 1
        # nn.Dropout(0.3)         # <-- ADD HEAD DROPOUT HERE
        self.classifier = nn.Linear(hidden_size * directions, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F] -> [B, 1, F]  (RESHAPE HANDLED HERE)
        x = x.unsqueeze(1)
        x = self.cnn(x)                 # [B, C, L]
        x = x.permute(0, 2, 1)          # [B, L, C]
        out, h_n = self.gru(x)          # out: [B, L, H*dir]
        last = out[:, -1, :]            # [B, H*dir]
        return self.classifier(last)    # [B, num_classes]


MODEL_META = {
    "id": "08_cnn_gru",
    "name": "CNN-GRU",
    "full_name": "1D-CNN + Gated Recurrent Unit Network",
    "family": "Hybrid convolutional-recurrent (gated)",
    "class_name": "CNNGRU",
    "tagline": "Same stem as 06/07 with a two-gate recursion — the "
               "accuracy/parameter compromise between the vanilla RNN and "
               "the LSTM.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits",
    "reshape_strategy": "unsqueeze(1) -> [B, 1, F]; permute(0, 2, 1) after "
                        "the conv stem to obtain [B, T, feat] for nn.GRU.",
    "inductive_bias": "Reset and update gates give most of the LSTM's "
                      "gradient-flow benefit with three weight matrices "
                      "instead of four and no separate cell state. On short "
                      "sequences — and 39 pooled positions is short — the "
                      "GRU is the model most likely to match the LSTM at "
                      "lower cost, which makes it the efficiency-frontier "
                      "candidate of the recurrent family.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("reshape", "unsqueeze(1)", "[B, 1, 78]"),
        ("conv", "Conv1d k=3 + ReLU", "1 -> 32 ch"),
        ("pool", "MaxPool1d /2", "78 -> 39"),
        ("conv", "Conv1d k=3 + ReLU", "32 -> 64 ch"),
        ("reshape", "permute(0,2,1)", "[B, 39, 64]"),
        ("rnn", "GRU, 1 layer", "hidden 64, 2 gates"),
        ("pool", "Last time step", "[B, 64]"),
        ("out", "Linear (classifier)", "64 -> 15"),
    ],
    "hyperparams": [
        ("channels", "(32, 64)", "Conv stem feature maps"),
        ("kernel_size", "3", "Conv receptive field"),
        ("hidden_size", "64", "Hidden state width"),
        ("num_layers", "1", "Recurrent depth"),
        ("bidirectional", "False", "Set True for a Bi-GRU ablation"),
    ],
    "latex": (
        "The GRU recursion over the pooled convolutional positions "
        "$\\mathbf{u}_t$ is\n"
        "\\begin{align}\n"
        "\\mathbf{r}_t&=\\varsigma(\\mathbf{W}_r[\\mathbf{u}_t,\\mathbf{h}_{t-1}]+\\mathbf{b}_r),\\\\\n"
        "\\mathbf{z}_t&=\\varsigma(\\mathbf{W}_z[\\mathbf{u}_t,\\mathbf{h}_{t-1}]+\\mathbf{b}_z),\\\\\n"
        "\\tilde{\\mathbf{h}}_t&=\\tanh(\\mathbf{W}_h[\\mathbf{u}_t,\\ \\mathbf{r}_t\\odot\\mathbf{h}_{t-1}]+\\mathbf{b}_h),\\\\\n"
        "\\mathbf{h}_t&=(1-\\mathbf{z}_t)\\odot\\mathbf{h}_{t-1}+\\mathbf{z}_t\\odot\\tilde{\\mathbf{h}}_t,\n"
        "\\end{align}\n"
        "and the terminal state $\\mathbf{h}_L$ is mapped to class logits by "
        "a single affine layer."
    ),
    "notes": [
        "Recurrent parameter count is 3(H(C+H)+2H) — three quarters of the "
        "LSTM at identical hidden_size. If the GRU matches the LSTM's "
        "macro-F1 within the seed variance, that is the headline efficiency "
        "result of the recurrent comparison.",
        "Report mean +/- std over at least 3 seeds before claiming any "
        "ordering among 06/07/08; the gaps between gated variants on short "
        "sequences are routinely smaller than seed noise.",
    ],
}
