"""
The eight baseline architectures. Every class accepts a raw 2D tabular batch
`[batch_size, n_features]` — all reshaping happens inside `forward()`.

    from core.models import ANN, CNN1D, Autoencoder, Encoder, \
                            TabTransformer, CNNRNN, CNNLSTM, CNNGRU
"""

from .ann import ANN, MODEL_META as META_ANN
from .cnn1d import CNN1D, MODEL_META as META_CNN1D
from .autoencoder import Autoencoder, MODEL_META as META_AUTOENCODER
from .encoder import Encoder, MODEL_META as META_ENCODER
from .transformer import TabTransformer, MODEL_META as META_TRANSFORMER
from .cnn_rnn import CNNRNN, MODEL_META as META_CNN_RNN
from .cnn_lstm import CNNLSTM, MODEL_META as META_CNN_LSTM
from .cnn_gru import CNNGRU, MODEL_META as META_CNN_GRU
from .sigma import SIGMANet, MODEL_META as META_SIGMA
from .gated_mlp import GRNMLP, MODEL_META as META_GRN_MLP

# id -> (module filename, class, metadata). The artefact builder walks this in
# order, and the id is also the name of the output folder at the project root.
REGISTRY = {
    "01_ann":          ("ann.py",         ANN,            META_ANN),
    "02_cnn1d":        ("cnn1d.py",       CNN1D,          META_CNN1D),
    "03_autoencoder":  ("autoencoder.py", Autoencoder,    META_AUTOENCODER),
    "04_encoder":      ("encoder.py",     Encoder,        META_ENCODER),
    "05_transformer":  ("transformer.py", TabTransformer, META_TRANSFORMER),
    "06_cnn_rnn":      ("cnn_rnn.py",     CNNRNN,         META_CNN_RNN),
    "07_cnn_lstm":     ("cnn_lstm.py",    CNNLSTM,        META_CNN_LSTM),
    "08_cnn_gru":      ("cnn_gru.py",     CNNGRU,         META_CNN_GRU),
    # --- proposed (Thesis Upgrade) -----------------------------------------
    "09_sigma":        ("sigma.py",       SIGMANet,       META_SIGMA),
    "10_grn_mlp":      ("gated_mlp.py",   GRNMLP,         META_GRN_MLP),
}

# The eight originals, for tables that must not silently include the proposal.
BASELINE_IDS = [k for k in REGISTRY if k.startswith(tuple("0123456789"))
                and int(k.split("_")[0]) <= 8]
PROPOSED_IDS = [k for k in REGISTRY if k not in BASELINE_IDS]


def build(model_id: str, input_dim: int, num_classes: int = 15):
    """Instantiate one baseline by its registry id."""
    _fname, cls, _meta = REGISTRY[model_id]
    try:
        return cls(input_dim=input_dim, num_classes=num_classes)
    except TypeError:                       # Autoencoder / Encoder
        return cls(input_dim=input_dim)


__all__ = [
    "ANN", "CNN1D", "Autoencoder", "Encoder", "TabTransformer",
    "CNNRNN", "CNNLSTM", "CNNGRU", "SIGMANet", "GRNMLP",
    "REGISTRY", "BASELINE_IDS", "PROPOSED_IDS", "build",
]
