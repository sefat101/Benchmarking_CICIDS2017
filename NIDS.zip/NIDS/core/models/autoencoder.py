"""
03 — Autoencoder (reconstruction output) for CICIDS2017 flow features.

Input : [batch_size, input_dim]
Output: [batch_size, input_dim]   (reconstruction — use nn.MSELoss)

Also exposes:
    .encode(x)  -> [B, latent_dim]
    .decode(z)  -> [B, input_dim]
    .forward(x, return_latent=True) -> (recon, latent)

Typical NIDS usage: train on BENIGN traffic only, then threshold the
per-sample reconstruction error for unsupervised / zero-day detection.
"""

import torch
import torch.nn as nn


class Autoencoder(nn.Module):
    """Symmetric undercomplete autoencoder: 78 -> 64 -> 32 -> 64 -> 78."""

    def __init__(self, input_dim: int = 78, latent_dim: int = 32,
                 hidden_dim: int = 64):
        super().__init__()
        self.input_dim = input_dim
        self.latent_dim = latent_dim

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            # nn.BatchNorm1d(hidden_dim),  # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.1),             # <-- ADD DROPOUT HERE (denoising AE)
            nn.Linear(hidden_dim, latent_dim),
            nn.ReLU(inplace=True),         # bottleneck activation
        )

        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            # nn.BatchNorm1d(hidden_dim),  # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, input_dim),
            # Linear output: inputs are standardised/quantile-normalised and
            # therefore unbounded. Swap for nn.Sigmoid() only if you scale
            # the features to [0, 1] with MinMaxScaler.
        )

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)

    def decode(self, z: torch.Tensor) -> torch.Tensor:
        return self.decoder(z)

    def forward(self, x: torch.Tensor, return_latent: bool = False):
        # x: [B, F]
        z = self.encoder(x)         # [B, 32]
        recon = self.decoder(z)     # [B, F]
        if return_latent:
            return recon, z
        return recon

    @torch.no_grad()
    def reconstruction_error(self, x: torch.Tensor) -> torch.Tensor:
        """Per-sample MSE — the anomaly score. Returns [B]."""
        recon = self.forward(x)
        return ((recon - x) ** 2).mean(dim=1)


MODEL_META = {
    "id": "03_autoencoder",
    "name": "Autoencoder",
    "full_name": "Undercomplete Symmetric Autoencoder",
    "family": "Reconstruction / unsupervised",
    "class_name": "Autoencoder",
    "tagline": "Compresses the flow vector to a 32-d bottleneck and rebuilds "
               "it; the residual is the anomaly score.",
    "input_shape": "[B, F]",
    "output_shape": "[B, F]",
    "output_semantics": "reconstruction of the input (not logits)",
    "reshape_strategy": "None — operates directly on the 2D tabular batch.",
    "inductive_bias": "Assumes benign traffic occupies a low-dimensional "
                      "manifold. Attacks are detected as points the decoder "
                      "cannot reproduce, so the model needs no attack labels "
                      "and — unlike the seven discriminative baselines — is "
                      "not upper-bounded by the attack classes present in "
                      "CICIDS2017. This is the zero-day arm of the study.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("linear", "Linear + ReLU (enc)", "78 -> 64"),
        ("latent", "Linear + ReLU (bottleneck)", "64 -> 32"),
        ("linear", "Linear + ReLU (dec)", "32 -> 64"),
        ("out", "Linear (reconstruction)", "64 -> 78"),
    ],
    "hyperparams": [
        ("latent_dim", "32", "Bottleneck width; the compression ratio is F/32"),
        ("hidden_dim", "64", "Encoder/decoder intermediate width"),
        ("output activation", "linear", "Matches standardised, unbounded inputs"),
        ("loss", "MSE", "Per-feature mean squared reconstruction error"),
    ],
    "latex": (
        "The encoder $f_\\theta:\\mathbb{R}^{F}\\!\\to\\!\\mathbb{R}^{d}$ and "
        "decoder $g_\\phi:\\mathbb{R}^{d}\\!\\to\\!\\mathbb{R}^{F}$ with "
        "$d=32\\ll F$ are trained on benign flows only by minimising\n"
        "\\begin{equation}\n"
        "\\mathcal{L}_{\\mathrm{rec}}(\\theta,\\phi)=\\frac{1}{|\\mathcal{D}_{b}|}"
        "\\sum_{\\mathbf{x}\\in\\mathcal{D}_{b}}\\bigl\\|\\mathbf{x}-"
        "g_\\phi(f_\\theta(\\mathbf{x}))\\bigr\\|_2^2 .\n"
        "\\end{equation}\n"
        "At inference a flow is flagged as anomalous when "
        "$s(\\mathbf{x})=\\|\\mathbf{x}-g_\\phi(f_\\theta(\\mathbf{x}))\\|_2^2"
        "\\;>\\;\\tau$, where $\\tau$ is set at the $q$-th percentile of the "
        "benign validation scores (we report $q\\in\\{95,99\\}$)."
    ),
    "notes": [
        "Do NOT report accuracy for this model against the 15-class task — "
        "it is a one-class detector. Report ROC-AUC, PR-AUC and the "
        "TPR at a fixed benign FPR (0.1% and 1% are the conventional "
        "operating points in the NIDS literature).",
        "The threshold must be calibrated on a benign-only validation split, "
        "never on the test set; state this explicitly in the methodology "
        "section to pre-empt a reviewer objection.",
        "Same encoder topology as model 04, which lets you report a clean "
        "pre-train / fine-tune transfer experiment.",
    ],
}
