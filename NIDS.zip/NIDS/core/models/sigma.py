"""
09 — SIGMA-IDS: Shortcut-Invariant Grouped Multi-head Attention for NIDS.

Input : [batch_size, input_dim]      (raw 2D tabular batch, like every baseline)
Output: [batch_size, num_classes]    (class logits from a cosine prototype head)

Optional auxiliary outputs (`forward(x, return_aux=True)`):
    aux["domain_logits"]  [B, n_domains]  gradient-reversed nuisance head
    aux["gate"]           [B, G]          sparse per-group selection weights
    aux["embedding"]      [B, d_model]    pooled representation
    aux["proto_cos"]      [B, C]          raw cosine similarities (open-set score)

Design rationale — one mechanism per identified gap
---------------------------------------------------
G1  Naive feature-as-token attention is 78x78 and ~13x slower than an LSTM
    for no accuracy gain.
    -> GROUPED TOKENISATION. The 78 columns are partitioned into ~11 semantic
       families (see core/common/feature_groups.py), each encoded to one
       token. Attention becomes 11x11: ~50x fewer pairs, and the attention map
       is legible at the level of "IAT-backward" rather than column 47.

G2  Deep models on CICIDS2017 collapse when train/test are separated properly
    (reported macro-F1 drops of ~0.23 for a Transformer, with false-alarm rate
    rising ~67x), because they ride testbed shortcuts rather than attack
    semantics.
    -> SHORTCUT-ADVERSARIAL INVARIANCE. A gradient-reversal head is trained to
       predict a nuisance variable (destination-port bucket, victim host,
       capture day) from the pooled embedding. Minimising its accuracy through
       the reversed gradient forces the encoder to discard the fingerprint
       while keeping whatever is left that is class-discriminative.

G3  Rare classes dominate macro-F1 and plain softmax under a ~1,150:1 prior
    is biased toward BENIGN.
    -> COSINE PROTOTYPE HEAD. Class prototypes on the unit sphere with a
       learnable scale, paired with the logit-adjusted loss in
       core/common/balancing.py. Prototype distance also gives a
       ready-made open-set score for free.

G4  Tree ensembles remain the strongest models on this feature set, which is
    evidence that a purely attentional path is the wrong prior for tabular
    data.
    -> WIDE RESIDUAL PATH. A direct MLP over the full raw vector is summed
       into the pooled token representation, so the model never has to route
       a simple axis-aligned rule through attention. Ablate it to show what
       attention is actually contributing.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from core.common.feature_groups import build_groups   # noqa: E402


# ---------------------------------------------------------------------------
# Building blocks
# ---------------------------------------------------------------------------
class _GradientReversal(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad):
        return -ctx.lambd * grad, None


def grad_reverse(x: torch.Tensor, lambd: float = 1.0) -> torch.Tensor:
    return _GradientReversal.apply(x, lambd)


def sparsemax(z: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """
    Euclidean projection onto the simplex — softmax's sparse sibling.

    Used for the group gate because softmax never assigns exactly zero, so
    "this alert used only the flag and IAT groups" would not be a true
    statement. Sparsemax can, which is what makes the gate an explanation
    rather than a heat-map.
    """
    z_sorted, _ = torch.sort(z, dim=dim, descending=True)
    cumsum = z_sorted.cumsum(dim) - 1.0
    shape = [1] * z.dim()
    shape[dim] = -1
    k = torch.arange(1, z.size(dim) + 1, device=z.device,
                     dtype=z.dtype).view(shape)
    support = (k * z_sorted) > cumsum
    k_z = support.sum(dim=dim, keepdim=True).clamp_min(1)
    tau = cumsum.gather(dim, k_z - 1) / k_z.to(z.dtype)
    return torch.clamp(z - tau, min=0.0)


class GroupTokenizer(nn.Module):
    """One small encoder per semantic feature family -> one token each."""

    def __init__(self, groups: Dict[str, List[int]], d_model: int = 64):
        super().__init__()
        self.group_names = list(groups.keys())
        self.register_buffer(
            "flat_index",
            torch.as_tensor([i for g in groups.values() for i in g],
                            dtype=torch.long))
        self.sizes = [len(v) for v in groups.values()]

        self.encoders = nn.ModuleList([
            nn.Sequential(
                nn.Linear(n, d_model),
                nn.LayerNorm(d_model),
                nn.GELU(),
                # nn.Dropout(0.1),     # <-- ADD PER-GROUP DROPOUT HERE
            )
            for n in self.sizes
        ])
        self.group_embed = nn.Parameter(torch.zeros(1, len(self.sizes), d_model))
        nn.init.trunc_normal_(self.group_embed, std=0.02)

    @property
    def n_groups(self) -> int:
        return len(self.sizes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F] -> gather each group's columns -> [B, G, d]
        parts = torch.split(x[:, self.flat_index], self.sizes, dim=1)
        tokens = torch.stack([enc(p) for enc, p in zip(self.encoders, parts)],
                             dim=1)
        return tokens + self.group_embed


# ---------------------------------------------------------------------------
# The model
# ---------------------------------------------------------------------------
class SIGMANet(nn.Module):
    """Grouped attention + shortcut-invariance + prototype head."""

    def __init__(self, input_dim: int = 78, num_classes: int = 10,
                 feature_names: Optional[Sequence[str]] = None,
                 d_model: int = 64, nhead: int = 4, num_layers: int = 2,
                 dim_feedforward: int = 128, dropout: float = 0.1,
                 n_groups: int = 11, use_gate: bool = True,
                 use_wide_path: bool = True, wide_hidden: int = 128,
                 n_domains: int = 16, grl_lambda: float = 0.3,
                 proto_scale: float = 10.0):
        super().__init__()
        assert d_model % nhead == 0, "d_model must be divisible by nhead"

        self.input_dim = input_dim
        self.num_classes = num_classes
        self.grl_lambda = float(grl_lambda)
        self.use_gate = use_gate
        self.use_wide_path = use_wide_path

        groups = build_groups(input_dim, feature_names, n_groups)
        self.tokenizer = GroupTokenizer(groups, d_model)
        self.group_names = self.tokenizer.group_names
        G = self.tokenizer.n_groups

        # Sparse per-sample group selection.
        self.gate_score = nn.Linear(d_model, 1) if use_gate else None

        self.cls_token = nn.Parameter(torch.zeros(1, 1, d_model))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=dim_feedforward,
            dropout=dropout, activation="gelu", batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_layers,
                                             enable_nested_tensor=False)
        self.norm = nn.LayerNorm(d_model)

        # Wide residual path over the raw vector — the axis-aligned shortcut
        # that attention should not have to reinvent.
        self.wide = nn.Sequential(
            nn.Linear(input_dim, wide_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(wide_hidden, d_model),
        ) if use_wide_path else None

        self.head_drop = nn.Dropout(dropout)

        # Cosine prototype classifier.
        self.prototypes = nn.Parameter(torch.empty(num_classes, d_model))
        nn.init.normal_(self.prototypes, std=0.02)
        self.logit_scale = nn.Parameter(torch.tensor(float(proto_scale)))

        # Nuisance head behind the gradient-reversal layer.
        self.domain_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Linear(d_model // 2, n_domains),
        )

        self._G = G

    # -- pieces ------------------------------------------------------------
    def embed(self, x: torch.Tensor):
        tokens = self.tokenizer(x)                       # [B, G, d]

        gate = None
        if self.gate_score is not None:
            scores = self.gate_score(tokens).squeeze(-1)  # [B, G]
            gate = sparsemax(scores, dim=-1)              # [B, G], sparse
            # Scale by G so the gate re-weights rather than shrinks the tokens.
            tokens = tokens * (gate.unsqueeze(-1) * self._G)

        cls = self.cls_token.expand(x.size(0), -1, -1)
        seq = torch.cat([cls, tokens], dim=1)             # [B, 1+G, d]
        seq = self.encoder(seq)
        h = self.norm(seq[:, 0])                          # [B, d]

        if self.wide is not None:
            h = h + self.wide(x)

        return h, gate

    def classify(self, h: torch.Tensor):
        z = F.normalize(self.head_drop(h), dim=1)
        w = F.normalize(self.prototypes, dim=1)
        cos = z @ w.t()                                   # [B, C] in [-1, 1]
        return self.logit_scale * cos, cos

    # -- forward -----------------------------------------------------------
    def forward(self, x: torch.Tensor, return_aux: bool = False):
        h, gate = self.embed(x)
        logits, cos = self.classify(h)

        if not return_aux:
            return logits

        aux = {
            "embedding": h,
            "gate": gate,
            "proto_cos": cos,
            "domain_logits": self.domain_head(grad_reverse(h, self.grl_lambda)),
        }
        return logits, aux

    # -- inference helpers -------------------------------------------------
    @torch.no_grad()
    def open_set_score(self, x: torch.Tensor) -> torch.Tensor:
        """1 - max cosine similarity to any prototype. High = unlike anything
        seen in training, i.e. a candidate zero-day. Threshold it on a
        validation split, never on test."""
        _, cos = self.classify(self.embed(x)[0])
        return 1.0 - cos.max(dim=1).values

    @torch.no_grad()
    def group_importance(self, x: torch.Tensor) -> torch.Tensor:
        """Mean sparse gate weight per group over a batch — the interpretability
        figure. Returns [G]; pair it with `self.group_names`."""
        _, gate = self.embed(x)
        if gate is None:
            return torch.zeros(self._G, device=x.device)
        return gate.mean(dim=0)


MODEL_META = {
    "id": "09_sigma",
    "name": "SIGMA-IDS",
    "full_name": "Shortcut-Invariant Grouped Multi-head Attention IDS",
    "family": "Proposed — grouped attention + invariance",
    "class_name": "SIGMANet",
    "tagline": "Encodes the 78 flow statistics as ~11 semantic family tokens, "
               "gates them sparsely, and trains the pooled embedding to be "
               "uninformative about testbed nuisance variables.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits (scaled cosine to class prototypes)",
    "reshape_strategy": "Group gather inside forward(): [B, F] -> [B, G, d] "
                        "via one small encoder per semantic feature family; a "
                        "[CLS] token is prepended for pooling.",
    "inductive_bias": "Two priors the baselines lack. First, that the feature "
                      "axis has family structure rather than either "
                      "adjacency (1D-CNN) or none at all (ANN) — attention "
                      "runs over ~11 families instead of 78 columns, cutting "
                      "the pairwise cost ~50x and making the attention map "
                      "interpretable at the level of a SOC analyst's "
                      "vocabulary. Second, that a correct detector should be "
                      "*unable* to recover which testbed host, port or "
                      "capture day a flow came from; the gradient-reversal "
                      "head turns that from an assumption into a trained "
                      "constraint, which is what the leakage-free split "
                      "actually measures.",
    "blocks": [
        ("input",   "Input", "[B, 78]"),
        ("reshape", "Group gather (11 families)", "[B, 11, n_i]"),
        ("linear",  "Per-group encoder + LayerNorm", "n_i -> 64 each"),
        ("attn",    "+ Group embedding", "[1, 11, 64] learnable"),
        ("pool",    "Sparsemax group gate", "[B, 11] sparse"),
        ("attn",    "TransformerEncoder x2 (+CLS)", "4 heads, 11x11 attention"),
        ("linear",  "Wide residual path", "78 -> 128 -> 64 (added)"),
        ("latent",  "Pooled embedding", "[B, 64]"),
        ("out",     "Cosine prototype head", "64 -> 10 logits"),
        ("rnn",     "GRL nuisance head (train only)", "64 -> 16 domains"),
    ],
    "hyperparams": [
        ("d_model", "64", "Token width"),
        ("nhead", "4", "Attention heads"),
        ("num_layers", "2", "Encoder blocks over 11+1 tokens"),
        ("n_groups", "11", "Semantic families (contiguous blocks if names absent)"),
        ("use_gate", "True", "Sparsemax group selection; ablate to isolate it"),
        ("use_wide_path", "True", "Raw-vector residual; ablate to isolate attention"),
        ("grl_lambda", "0.3", "Gradient-reversal strength; 0.0 disables invariance"),
        ("n_domains", "16", "Nuisance buckets (port / host / day)"),
        ("proto_scale", "10.0", "Initial cosine logit scale (learnable)"),
    ],
    "latex": (
        "Let $\\mathcal{G}=\\{g_1,\\dots,g_G\\}$ partition the feature indices "
        "into semantic families. Each family is encoded to a token\n"
        "\\begin{equation}\n"
        "\\mathbf{t}_j=\\mathrm{GELU}\\bigl(\\mathrm{LN}(\\mathbf{W}_j\\,"
        "\\mathbf{x}_{g_j}+\\mathbf{b}_j)\\bigr)+\\mathbf{e}_j,\\qquad "
        "\\mathbf{t}_j\\in\\mathbb{R}^{d},\n"
        "\\end{equation}\n"
        "and gated by $\\boldsymbol{\\alpha}=\\mathrm{sparsemax}"
        "(\\mathbf{w}_g^{\\top}\\mathbf{T})$, giving "
        "$\\tilde{\\mathbf{t}}_j=G\\,\\alpha_j\\mathbf{t}_j$. A $[\\mathrm{CLS}]$ "
        "token is prepended and $L$ pre-norm encoder blocks are applied; the "
        "pooled representation is "
        "$\\mathbf{h}=\\mathrm{LN}(\\mathbf{T}^{(L)}_{0})+\\phi(\\mathbf{x})$ "
        "where $\\phi$ is the wide residual path. Classification uses cosine "
        "prototypes $\\mathbf{P}\\in\\mathbb{R}^{C\\times d}$,\n"
        "\\begin{equation}\n"
        "z_c=s\\,\\frac{\\mathbf{h}^{\\top}\\mathbf{p}_c}"
        "{\\|\\mathbf{h}\\|\\,\\|\\mathbf{p}_c\\|},\n"
        "\\end{equation}\n"
        "and the training objective combines the logit-adjusted risk with the "
        "reversed nuisance term,\n"
        "\\begin{equation}\n"
        "\\mathcal{L}=\\underbrace{\\mathrm{CE}\\bigl(\\mathbf{z}+\\tau\\log"
        "\\boldsymbol{\\pi},\\,y\\bigr)}_{\\text{long-tail correction}}"
        "\\;-\\;\\lambda\\,\\underbrace{\\mathrm{CE}\\bigl(\\psi(\\mathbf{h}),"
        "\\,d\\bigr)}_{\\text{nuisance predictability}},\n"
        "\\end{equation}\n"
        "with $\\boldsymbol{\\pi}$ the training class prior, $d$ the nuisance "
        "label and $\\lambda$ realised by a gradient-reversal layer so that a "
        "single forward pass suffices."
    ),
    "notes": [
        "Construct with `feature_names=bundle.feature_names`. Without them "
        "the model falls back to contiguous blocks, which compiles and trains "
        "but discards the semantic prior the whole design rests on — that "
        "fallback is the smoke-test path, not a configuration to report.",
        "Report the three ablations that matter: grl_lambda=0 (no "
        "invariance), use_gate=False (dense groups), use_wide_path=False "
        "(attention only). If the full model does not beat all three under "
        "the grouped split, say so — the mechanism claim is what is being "
        "tested, not the headline number.",
        "The nuisance labels come from columns you deliberately excluded from "
        "the input (destination port, victim host, capture day). They must be "
        "carried alongside X through the split, never fed to the encoder.",
        "`open_set_score` gives a zero-day score at no extra cost. Calibrate "
        "its threshold on a validation split; a threshold tuned on test is "
        "the most common silent error in this literature.",
    ],
}
