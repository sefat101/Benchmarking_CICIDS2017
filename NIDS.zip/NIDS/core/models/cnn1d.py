"""
02 — 1D-CNN baseline for CICIDS2017 flow features.

Input : [batch_size, input_dim]   (raw 2D tabular batch)
Output: [batch_size, num_classes] (raw logits)

Reshaping is handled INSIDE forward(): [B, F] -> unsqueeze(1) -> [B, 1, F],
i.e. one input channel and a "pseudo-sequence" of length F along which the
1D kernels slide.
"""

import torch
import torch.nn as nn


class CNN1D(nn.Module):
    """Two shallow conv blocks + global pooling head."""

    def __init__(self, input_dim: int = 78, num_classes: int = 15,
                 channels=(32, 64), kernel_size: int = 3):
        super().__init__()
        self.input_dim = input_dim
        c1, c2 = channels
        pad = kernel_size // 2  # 'same' padding keeps the length arithmetic simple

        self.conv1 = nn.Sequential(
            nn.Conv1d(1, c1, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c1),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2),
            # nn.Dropout(0.2),      # <-- ADD DROPOUT HERE
        )

        self.conv2 = nn.Sequential(
            nn.Conv1d(c1, c2, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c2),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.2),      # <-- ADD DROPOUT HERE
        )

        # Adaptive pooling makes the head independent of input_dim,
        # so 78 / 79 / 80 features all work without editing the classifier.
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.classifier = nn.Linear(c2, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F] -> [B, 1, F]  (RESHAPE HANDLED HERE)
        x = x.unsqueeze(1)
        x = self.conv1(x)               # [B, 32, F/2]
        x = self.conv2(x)               # [B, 64, F/2]
        x = self.pool(x).squeeze(-1)    # [B, 64]
        return self.classifier(x)       # [B, num_classes]


MODEL_META = {
    "id": "02_cnn1d",
    "name": "1D-CNN",
    "full_name": "One-Dimensional Convolutional Neural Network",
    "family": "Convolutional",
    "class_name": "CNN1D",
    "tagline": "Slides local kernels along the feature axis to learn "
               "translation-equivariant groups of adjacent flow statistics.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits",
    "reshape_strategy": "x.unsqueeze(1): [B, F] -> [B, 1, F]. One channel, "
                        "sequence length F.",
    "inductive_bias": "Assumes locality along the feature axis — that "
                      "column i and column i+1 are semantically related. For "
                      "CICIDS2017 this holds only because the CICFlowMeter "
                      "column order groups related statistics (forward "
                      "packet-length family, backward packet-length family, "
                      "IAT family, flag counts). This ordering dependence "
                      "must be declared in the paper; a column-shuffle "
                      "ablation is the standard way to quantify it.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("reshape", "unsqueeze(1)", "[B, 1, 78]"),
        ("conv", "Conv1d k=3 + ReLU", "1 -> 32 ch"),
        ("pool", "MaxPool1d /2", "78 -> 39"),
        ("conv", "Conv1d k=3 + ReLU", "32 -> 64 ch"),
        ("pool", "AdaptiveAvgPool1d(1)", "[B, 64]"),
        ("out", "Linear (classifier)", "64 -> 15"),
    ],
    "hyperparams": [
        ("channels", "(32, 64)", "Feature maps in conv block 1 / 2"),
        ("kernel_size", "3", "Receptive field per conv layer (padding=1)"),
        ("pooling", "MaxPool1d(2) then AdaptiveAvgPool1d(1)", "Global head"),
        ("dropout", "0.0 (placeholder)", "Insert after each ReLU"),
    ],
    "latex": (
        "The feature vector is lifted to a single-channel signal "
        "$\\mathbf{X}^{(0)}\\in\\mathbb{R}^{1\\times F}$. Each convolutional "
        "block applies\n"
        "\\begin{equation}\n"
        "X^{(l)}_{c,i}=\\sigma\\!\\left(b_c+\\sum_{c'=1}^{C_{l-1}}"
        "\\sum_{j=-\\lfloor k/2\\rfloor}^{\\lfloor k/2\\rfloor}"
        "W^{(l)}_{c,c',j}\\,X^{(l-1)}_{c',\\,i+j}\\right),\n"
        "\\end{equation}\n"
        "with $k=3$ and zero padding. Block~1 is followed by max pooling "
        "with stride~2; the final map is reduced by global average pooling, "
        "$\\bar{x}_c=\\tfrac{1}{L}\\sum_i X^{(2)}_{c,i}$, and classified by a "
        "single affine layer."
    ),
    "notes": [
        "Global average pooling (rather than a flattened dense head) keeps "
        "the parameter count low and decouples the classifier from the "
        "feature count, so the same checkpoint definition transfers to "
        "UNSW-NB15 or CIC-IDS2018 feature sets.",
        "Report the column-order ablation: retrain on a fixed random "
        "permutation of the feature columns. A large drop is evidence the "
        "convolutional prior is doing real work; no drop suggests the model "
        "has degenerated to a weight-shared MLP.",
    ],
}
