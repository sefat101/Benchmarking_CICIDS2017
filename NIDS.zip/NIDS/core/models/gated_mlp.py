"""
10 — GRN-MLP: gated residual MLP. The honest control for SIGMA-IDS.

Input : [batch_size, input_dim]
Output: [batch_size, num_classes]

Why this model exists
---------------------
A proposal is only as good as the control it beats. If SIGMA-IDS improves on
the eight baselines, the first question any reviewer asks is how much of that
came from the architecture and how much from the two changes that touch every
model equally — the leakage-free protocol and the logit-adjusted loss.

GRN-MLP is built to answer that. It is a plain feed-forward network with two
modernisations that are known to help on tabular data and cost nothing
conceptually — gated linear units and residual connections with pre-norm — and
it is trained with exactly the same loss, sampler, schedule and tuning budget
as SIGMA-IDS. Whatever margin remains between them is attributable to grouped
attention and shortcut invariance, and nothing else.

Expect this control to be strong. On CICIDS2017-style flow features, tuned
tree ensembles and well-regularised MLPs are repeatedly reported at or above
sequence and attention models. If GRN-MLP matches SIGMA-IDS, that is a
publishable finding, not a failure — report it.
"""

import torch
import torch.nn as nn


class GatedResidualBlock(nn.Module):
    """Pre-norm residual block with a gated linear unit."""

    def __init__(self, dim: int, expansion: int = 2, dropout: float = 0.1):
        super().__init__()
        hidden = dim * expansion
        self.norm = nn.LayerNorm(dim)
        self.up = nn.Linear(dim, hidden * 2)   # value and gate halves
        self.down = nn.Linear(hidden, dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.norm(x)
        value, gate = self.up(h).chunk(2, dim=-1)
        h = value * torch.sigmoid(gate)         # GLU
        h = self.down(self.drop(h))
        return x + self.drop(h)                 # residual


class GRNMLP(nn.Module):
    """Stem -> N gated residual blocks -> cosine prototype head."""

    def __init__(self, input_dim: int = 78, num_classes: int = 10,
                 d_model: int = 128, num_blocks: int = 3, expansion: int = 2,
                 dropout: float = 0.1, cosine_head: bool = True,
                 proto_scale: float = 10.0):
        super().__init__()
        self.input_dim = input_dim
        self.cosine_head = cosine_head

        self.stem = nn.Sequential(
            nn.Linear(input_dim, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
        )
        self.blocks = nn.Sequential(*[
            GatedResidualBlock(d_model, expansion, dropout)
            for _ in range(num_blocks)
        ])
        self.norm = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)

        if cosine_head:
            # Same head as SIGMA-IDS, so the comparison isolates the encoder.
            self.prototypes = nn.Parameter(torch.empty(num_classes, d_model))
            nn.init.normal_(self.prototypes, std=0.02)
            self.logit_scale = nn.Parameter(torch.tensor(float(proto_scale)))
            self.classifier = None
        else:
            self.classifier = nn.Linear(d_model, num_classes)

    def embed(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(self.blocks(self.stem(x)))

    def forward(self, x: torch.Tensor, return_aux: bool = False):
        h = self.embed(x)
        if self.classifier is not None:
            logits = self.classifier(self.drop(h))
            cos = None
        else:
            z = nn.functional.normalize(self.drop(h), dim=1)
            w = nn.functional.normalize(self.prototypes, dim=1)
            cos = z @ w.t()
            logits = self.logit_scale * cos
        if return_aux:
            return logits, {"embedding": h, "proto_cos": cos, "gate": None}
        return logits


MODEL_META = {
    "id": "10_grn_mlp",
    "name": "GRN-MLP",
    "full_name": "Gated Residual MLP (control for SIGMA-IDS)",
    "family": "Proposed — control",
    "class_name": "GRNMLP",
    "tagline": "A well-regularised feed-forward network sharing SIGMA-IDS's "
               "head, loss and tuning budget, so the attention margin can be "
               "attributed rather than assumed.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits (scaled cosine to class prototypes)",
    "reshape_strategy": "None — operates directly on the 2D tabular batch.",
    "inductive_bias": "Deliberately minimal: no locality, no ordering, no "
                      "family structure. Gating gives multiplicative feature "
                      "interactions, which is the one thing plain ReLU stacks "
                      "do badly on tabular data and the reason tree ensembles "
                      "beat them. Its role in the study is to absorb every "
                      "improvement that is NOT specific to grouped attention "
                      "or shortcut invariance.",
    "blocks": [
        ("input",  "Input", "[B, 78]"),
        ("linear", "Stem: Linear + LayerNorm + GELU", "78 -> 128"),
        ("linear", "Gated residual block x3", "GLU, expansion 2"),
        ("latent", "LayerNorm", "[B, 128]"),
        ("out",    "Cosine prototype head", "128 -> 10 logits"),
    ],
    "hyperparams": [
        ("d_model", "128", "Residual stream width"),
        ("num_blocks", "3", "Depth"),
        ("expansion", "2", "GLU inner expansion"),
        ("dropout", "0.1", "Applied inside blocks and before the head"),
        ("cosine_head", "True", "Match SIGMA-IDS's head exactly"),
    ],
    "latex": (
        "The stem maps $\\mathbf{x}\\in\\mathbb{R}^{F}$ to "
        "$\\mathbf{h}^{(0)}=\\mathrm{GELU}(\\mathrm{LN}(\\mathbf{W}_s\\mathbf{x}"
        "+\\mathbf{b}_s))\\in\\mathbb{R}^{d}$. Each of the $B$ blocks applies\n"
        "\\begin{equation}\n"
        "\\mathbf{u},\\mathbf{v}=\\mathbf{W}_{\\uparrow}\\mathrm{LN}"
        "(\\mathbf{h}^{(b-1)}),\\qquad\n"
        "\\mathbf{h}^{(b)}=\\mathbf{h}^{(b-1)}+\\mathbf{W}_{\\downarrow}"
        "\\bigl(\\mathbf{u}\\odot\\sigma(\\mathbf{v})\\bigr),\n"
        "\\end{equation}\n"
        "where $\\sigma$ is the logistic sigmoid, so the block realises "
        "second-order feature interactions without an attention matrix. The "
        "head is the cosine prototype classifier of SIGMA-IDS, trained under "
        "the same logit-adjusted objective."
    ),
    "notes": [
        "Give this model the same hyperparameter search budget as SIGMA-IDS. "
        "An under-tuned control is the most common way a weak architectural "
        "claim survives to publication.",
        "At the defaults this control has ~3x SIGMA-IDS's parameters "
        "(310k vs 97k). That asymmetry is deliberate for the smoke test but "
        "unacceptable in the results table: constrain d_model and num_blocks "
        "during tuning so the two land within ~10% of each other, or report "
        "both parameter counts beside every score.",
        "It has no gradient-reversal head, so it also serves as the "
        "'no-invariance' condition at the encoder level — complementing the "
        "grl_lambda=0 ablation inside SIGMA-IDS itself.",
    ],
}
