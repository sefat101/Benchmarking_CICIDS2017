"""
01 — ANN (Standard Multi-Layer Perceptron) baseline for CICIDS2017 flow features.

Input : [batch_size, input_dim]   (raw 2D tabular batch, no reshaping needed)
Output: [batch_size, num_classes] (raw logits — use nn.CrossEntropyLoss)
"""

import torch
import torch.nn as nn


class ANN(nn.Module):
    """Shallow fully-connected baseline: 78 -> 256 -> 128 -> 15."""

    def __init__(self, input_dim: int = 78, num_classes: int = 15,
                 hidden_dims=(256, 128)):
        super().__init__()
        h1, h2 = hidden_dims

        self.block1 = nn.Sequential(
            nn.Linear(input_dim, h1),
            # nn.BatchNorm1d(h1),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.3),      # <-- ADD DROPOUT HERE
        )

        self.block2 = nn.Sequential(
            nn.Linear(h1, h2),
            # nn.BatchNorm1d(h2),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.3),      # <-- ADD DROPOUT HERE
        )

        self.classifier = nn.Linear(h2, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F]
        x = self.block1(x)          # [B, 256]
        x = self.block2(x)          # [B, 128]
        return self.classifier(x)   # [B, num_classes] (logits)


# --------------------------------------------------------------------------
# Journal metadata (consumed by tools/build_journal_outputs.py)
# --------------------------------------------------------------------------
MODEL_META = {
    "id": "01_ann",
    "name": "ANN",
    "full_name": "Artificial Neural Network (Multi-Layer Perceptron)",
    "family": "Fully-connected",
    "class_name": "ANN",
    "tagline": "Densely connected reference baseline; treats the 78 flow "
               "statistics as an unordered feature vector.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits",
    "reshape_strategy": "None — the model consumes the raw 2D tabular batch.",
    "inductive_bias": "Permutation-agnostic. No locality or ordering "
                      "assumption is imposed on the feature axis, which is "
                      "the theoretically correct prior for tabular flow "
                      "statistics and makes this the fairest control "
                      "condition against which the structured models "
                      "(CNN/RNN/Transformer) must be judged.",
    "blocks": [
        ("input",  "Input", "[B, 78]"),
        ("linear", "Linear + ReLU", "78 -> 256"),
        ("linear", "Linear + ReLU", "256 -> 128"),
        ("out",    "Linear (classifier)", "128 -> 15"),
    ],
    "hyperparams": [
        ("hidden_dims", "(256, 128)", "Width of the two dense blocks"),
        ("activation", "ReLU", "Applied after every hidden linear layer"),
        ("dropout", "0.0 (placeholder)", "Insert after each ReLU"),
        ("norm", "none (placeholder)", "BatchNorm1d recommended before ReLU"),
    ],
    "latex": (
        "Let $\\mathbf{x}\\in\\mathbb{R}^{F}$ denote the pre-processed flow "
        "feature vector. The ANN baseline computes\n"
        "\\begin{align}\n"
        "\\mathbf{h}_1 &= \\sigma(\\mathbf{W}_1\\mathbf{x}+\\mathbf{b}_1), "
        "&& \\mathbf{W}_1\\in\\mathbb{R}^{256\\times F},\\\\\n"
        "\\mathbf{h}_2 &= \\sigma(\\mathbf{W}_2\\mathbf{h}_1+\\mathbf{b}_2), "
        "&& \\mathbf{W}_2\\in\\mathbb{R}^{128\\times 256},\\\\\n"
        "\\mathbf{z}  &= \\mathbf{W}_3\\mathbf{h}_2+\\mathbf{b}_3, "
        "&& \\mathbf{W}_3\\in\\mathbb{R}^{C\\times 128},\n"
        "\\end{align}\n"
        "where $\\sigma(\\cdot)=\\max(0,\\cdot)$ and $\\mathbf{z}$ are the "
        "unnormalised class logits optimised with the class-weighted "
        "cross-entropy objective."
    ),
    "notes": [
        "Serves as the control condition: any accuracy gained by the "
        "convolutional, recurrent or attention baselines must be reported "
        "relative to this model at matched parameter budget.",
        "Because no spatial prior is imposed, this architecture is also the "
        "cheapest per sample and is the natural candidate for the "
        "latency/throughput column of the results table.",
    ],
}
