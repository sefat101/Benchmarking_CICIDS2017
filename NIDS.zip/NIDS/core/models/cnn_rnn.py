"""
06 — CNN-RNN hybrid: 1D convolutional spatial extraction -> vanilla RNN.

Input : [batch_size, input_dim]
Output: [batch_size, num_classes]

Pipeline inside forward():
    [B, F] --unsqueeze(1)--> [B, 1, F] --conv/pool--> [B, C, L]
          --permute(0,2,1)--> [B, L, C] --RNN--> last hidden --> logits
"""

import torch
import torch.nn as nn


class CNNFrontEnd(nn.Module):
    """
    Shared convolutional stem for models 06/07/08.

    Deliberately duplicated in each model folder so every folder is a
    self-contained, importable unit for the artefact appendix.
    """

    def __init__(self, channels=(32, 64), kernel_size: int = 3):
        super().__init__()
        c1, c2 = channels
        pad = kernel_size // 2
        self.net = nn.Sequential(
            nn.Conv1d(1, c1, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c1),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(c1, c2, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c2),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.2),      # <-- ADD DROPOUT HERE
        )
        self.out_channels = c2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)   # [B, C, L]


class CNNRNN(nn.Module):
    """Conv stem -> vanilla (tanh) RNN -> linear classifier."""

    def __init__(self, input_dim: int = 78, num_classes: int = 15,
                 channels=(32, 64), kernel_size: int = 3,
                 hidden_size: int = 64, num_layers: int = 1,
                 bidirectional: bool = False):
        super().__init__()
        self.input_dim = input_dim
        self.cnn = CNNFrontEnd(channels=channels, kernel_size=kernel_size)

        self.rnn = nn.RNN(
            input_size=self.cnn.out_channels,
            hidden_size=hidden_size,
            num_layers=num_layers,
            nonlinearity="tanh",
            batch_first=True,
            bidirectional=bidirectional,
            # dropout=0.2,        # <-- ONLY EFFECTIVE WHEN num_layers > 1
        )

        directions = 2 if bidirectional else 1
        # nn.Dropout(0.3)         # <-- ADD HEAD DROPOUT HERE
        self.classifier = nn.Linear(hidden_size * directions, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F] -> [B, 1, F]  (RESHAPE HANDLED HERE)
        x = x.unsqueeze(1)
        x = self.cnn(x)                 # [B, C, L]
        x = x.permute(0, 2, 1)          # [B, L, C]  -> RNN expects (B, T, feat)
        out, h_n = self.rnn(x)          # out: [B, L, H*dir]
        # Take the last time step (concatenating directions if bidirectional).
        last = out[:, -1, :]            # [B, H*dir]
        return self.classifier(last)    # [B, num_classes]


MODEL_META = {
    "id": "06_cnn_rnn",
    "name": "CNN-RNN",
    "full_name": "1D-CNN + Vanilla Recurrent Neural Network",
    "family": "Hybrid convolutional-recurrent",
    "class_name": "CNNRNN",
    "tagline": "Convolutional stem compresses the feature axis into 39 "
               "64-channel steps, which a tanh RNN then reads sequentially.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits",
    "reshape_strategy": "unsqueeze(1) -> [B, 1, F]; after the conv stem "
                        "permute(0, 2, 1) turns [B, C, L] into the "
                        "[B, T, feat] layout nn.RNN expects.",
    "inductive_bias": "Two stacked priors: convolutional locality over "
                      "adjacent columns, then a strictly ordered recursion "
                      "over the pooled positions. The recursion is the "
                      "weakest of the three recurrent variants — the "
                      "single tanh gate gives it the shortest effective "
                      "memory — which is precisely why it belongs in the "
                      "study as the vanishing-gradient control for the LSTM "
                      "and GRU rows.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("reshape", "unsqueeze(1)", "[B, 1, 78]"),
        ("conv", "Conv1d k=3 + ReLU", "1 -> 32 ch"),
        ("pool", "MaxPool1d /2", "78 -> 39"),
        ("conv", "Conv1d k=3 + ReLU", "32 -> 64 ch"),
        ("reshape", "permute(0,2,1)", "[B, 39, 64]"),
        ("rnn", "RNN (tanh), 1 layer", "hidden 64"),
        ("pool", "Last time step", "[B, 64]"),
        ("out", "Linear (classifier)", "64 -> 15"),
    ],
    "hyperparams": [
        ("channels", "(32, 64)", "Conv stem feature maps"),
        ("kernel_size", "3", "Conv receptive field"),
        ("hidden_size", "64", "RNN hidden state width"),
        ("num_layers", "1", "Recurrent depth"),
        ("bidirectional", "False", "Set True for a Bi-RNN ablation"),
        ("nonlinearity", "tanh", "Vanilla Elman recursion"),
    ],
    "latex": (
        "The conv stem maps $\\mathbf{x}$ to "
        "$\\mathbf{U}\\in\\mathbb{R}^{C\\times L}$ with $C=64$, "
        "$L=\\lfloor F/2\\rfloor$. Writing $\\mathbf{u}_t$ for the $t$-th "
        "column of $\\mathbf{U}$, the Elman recursion is\n"
        "\\begin{equation}\n"
        "\\mathbf{h}_t=\\tanh\\!\\left(\\mathbf{W}_{ih}\\mathbf{u}_t+"
        "\\mathbf{W}_{hh}\\mathbf{h}_{t-1}+\\mathbf{b}\\right),\\qquad "
        "\\mathbf{h}_0=\\mathbf{0},\n"
        "\\end{equation}\n"
        "and the terminal state $\\mathbf{h}_L$ is classified by "
        "$\\mathbf{z}=\\mathbf{W}_o\\mathbf{h}_L+\\mathbf{b}_o$."
    ),
    "notes": [
        "The 'sequence' here is synthetic — it is the pooled feature axis, "
        "not time. Say so plainly in the paper: several published NIDS "
        "papers apply recurrence to per-flow tabular rows without "
        "acknowledging that no temporal axis exists, and a reviewer will "
        "look for that admission.",
        "Because the recursion is length-39 with a single tanh gate, the "
        "gradient norm at t=1 is the quantity to plot when arguing why the "
        "gated variants (07, 08) outperform this model.",
        "Matched parameter budget with 07/08 is not automatic: LSTM has 4x "
        "and GRU 3x the recurrent weights at equal hidden_size. Either "
        "report parameters per model (see comparison.csv) or shrink "
        "hidden_size for the gated variants when claiming a fair fight.",
    ],
}
