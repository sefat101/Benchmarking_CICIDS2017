"""
07 — CNN-LSTM hybrid: 1D convolutional spatial extraction -> LSTM.

Input : [batch_size, input_dim]
Output: [batch_size, num_classes]

Pipeline inside forward():
    [B, F] --unsqueeze(1)--> [B, 1, F] --conv/pool--> [B, C, L]
          --permute(0,2,1)--> [B, L, C] --LSTM--> last hidden --> logits
"""

import torch
import torch.nn as nn


class CNNFrontEnd(nn.Module):
    """Shared convolutional stem (duplicated so each folder stands alone)."""

    def __init__(self, channels=(32, 64), kernel_size: int = 3):
        super().__init__()
        c1, c2 = channels
        pad = kernel_size // 2
        self.net = nn.Sequential(
            nn.Conv1d(1, c1, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c1),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(c1, c2, kernel_size=kernel_size, padding=pad),
            # nn.BatchNorm1d(c2),   # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.2),      # <-- ADD DROPOUT HERE
        )
        self.out_channels = c2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)   # [B, C, L]


class CNNLSTM(nn.Module):
    """Conv stem -> LSTM -> linear classifier."""

    def __init__(self, input_dim: int = 78, num_classes: int = 15,
                 channels=(32, 64), kernel_size: int = 3,
                 hidden_size: int = 64, num_layers: int = 1,
                 bidirectional: bool = False):
        super().__init__()
        self.input_dim = input_dim
        self.cnn = CNNFrontEnd(channels=channels, kernel_size=kernel_size)

        self.lstm = nn.LSTM(
            input_size=self.cnn.out_channels,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=bidirectional,
            # dropout=0.2,        # <-- ONLY EFFECTIVE WHEN num_layers > 1
        )

        directions = 2 if bidirectional else 1
        # nn.Dropout(0.3)         # <-- ADD HEAD DROPOUT HERE
        self.classifier = nn.Linear(hidden_size * directions, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F] -> [B, 1, F]  (RESHAPE HANDLED HERE)
        x = x.unsqueeze(1)
        x = self.cnn(x)                     # [B, C, L]
        x = x.permute(0, 2, 1)              # [B, L, C]
        out, (h_n, c_n) = self.lstm(x)      # out: [B, L, H*dir]
        last = out[:, -1, :]                # [B, H*dir]
        return self.classifier(last)        # [B, num_classes]


MODEL_META = {
    "id": "07_cnn_lstm",
    "name": "CNN-LSTM",
    "full_name": "1D-CNN + Long Short-Term Memory Network",
    "family": "Hybrid convolutional-recurrent (gated)",
    "class_name": "CNNLSTM",
    "tagline": "Same convolutional stem as 06, but the recursion carries an "
               "explicit cell state guarded by input, forget and output "
               "gates.",
    "input_shape": "[B, F]",
    "output_shape": "[B, C]",
    "output_semantics": "class logits",
    "reshape_strategy": "unsqueeze(1) -> [B, 1, F]; permute(0, 2, 1) after "
                        "the conv stem to obtain [B, T, feat] for nn.LSTM.",
    "inductive_bias": "The additive cell-state path gives a gradient "
                      "highway across the 39 pooled positions, so "
                      "long-range dependencies between the early "
                      "(forward-direction) and late (backward-direction, "
                      "flag-count) regions of the CICFlowMeter feature "
                      "vector survive back-propagation. Four gate matrices "
                      "make it the most parameter-hungry recurrent variant "
                      "of the three.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("reshape", "unsqueeze(1)", "[B, 1, 78]"),
        ("conv", "Conv1d k=3 + ReLU", "1 -> 32 ch"),
        ("pool", "MaxPool1d /2", "78 -> 39"),
        ("conv", "Conv1d k=3 + ReLU", "32 -> 64 ch"),
        ("reshape", "permute(0,2,1)", "[B, 39, 64]"),
        ("rnn", "LSTM, 1 layer", "hidden 64, 4 gates"),
        ("pool", "Last time step", "[B, 64]"),
        ("out", "Linear (classifier)", "64 -> 15"),
    ],
    "hyperparams": [
        ("channels", "(32, 64)", "Conv stem feature maps"),
        ("kernel_size", "3", "Conv receptive field"),
        ("hidden_size", "64", "Hidden and cell state width"),
        ("num_layers", "1", "Recurrent depth"),
        ("bidirectional", "False", "Set True for a Bi-LSTM ablation"),
    ],
    "latex": (
        "With $\\mathbf{u}_t$ the $t$-th pooled convolutional position, the "
        "LSTM cell computes\n"
        "\\begin{align}\n"
        "\\mathbf{i}_t&=\\varsigma(\\mathbf{W}_i[\\mathbf{u}_t,\\mathbf{h}_{t-1}]+\\mathbf{b}_i), &\n"
        "\\mathbf{f}_t&=\\varsigma(\\mathbf{W}_f[\\mathbf{u}_t,\\mathbf{h}_{t-1}]+\\mathbf{b}_f),\\\\\n"
        "\\mathbf{o}_t&=\\varsigma(\\mathbf{W}_o[\\mathbf{u}_t,\\mathbf{h}_{t-1}]+\\mathbf{b}_o), &\n"
        "\\tilde{\\mathbf{c}}_t&=\\tanh(\\mathbf{W}_c[\\mathbf{u}_t,\\mathbf{h}_{t-1}]+\\mathbf{b}_c),\\\\\n"
        "\\mathbf{c}_t&=\\mathbf{f}_t\\odot\\mathbf{c}_{t-1}+\\mathbf{i}_t\\odot\\tilde{\\mathbf{c}}_t, &\n"
        "\\mathbf{h}_t&=\\mathbf{o}_t\\odot\\tanh(\\mathbf{c}_t),\n"
        "\\end{align}\n"
        "where $\\varsigma$ is the logistic sigmoid. The terminal state "
        "$\\mathbf{h}_L$ is mapped to logits by a single affine layer."
    ),
    "notes": [
        "Parameter accounting for the recurrent block is "
        "4(H(C+H)+2H) with C = 64 input channels and H = 64 hidden units — "
        "roughly four times the vanilla RNN of model 06. Cite the exact "
        "counts from comparison.csv rather than approximating.",
        "cuDNN fuses this kernel, so wall-clock time per epoch is usually "
        "closer to the GRU than the parameter ratio suggests; report both "
        "parameters and measured epoch time so the efficiency claim is "
        "defensible.",
        "If the LSTM does not beat the vanilla RNN here, that is a "
        "publishable negative result for 39-step synthetic sequences — "
        "report it rather than tuning until the expected ordering appears.",
    ],
}
