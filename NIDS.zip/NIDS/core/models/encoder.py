"""
04 — Encoder (feature extractor returning a latent vector).

Input : [batch_size, input_dim]
Output: [batch_size, latent_dim]   (embedding — NOT logits)

This is the standalone half of model 03. Two intended uses:
  1. Load the encoder weights from a trained Autoencoder and freeze them,
     then attach a small classifier head (`attach_head=True`).
  2. Train it with a metric / contrastive objective and evaluate the
     embedding with a k-NN or linear probe.
"""

import torch
import torch.nn as nn


class Encoder(nn.Module):
    """Feature extractor: 78 -> 64 -> 32 latent. Optional classifier head."""

    def __init__(self, input_dim: int = 78, latent_dim: int = 32,
                 hidden_dim: int = 64, attach_head: bool = False,
                 num_classes: int = 15):
        super().__init__()
        self.latent_dim = latent_dim
        self.attach_head = attach_head

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            # nn.BatchNorm1d(hidden_dim),  # <-- ADD BATCH-NORM HERE
            nn.ReLU(inplace=True),
            # nn.Dropout(0.2),             # <-- ADD DROPOUT HERE
            nn.Linear(hidden_dim, latent_dim),
            nn.ReLU(inplace=True),
        )

        # Optional linear probe / fine-tuning head.
        self.head = nn.Linear(latent_dim, num_classes) if attach_head else None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, F]
        z = self.encoder(x)          # [B, latent_dim]
        if self.head is not None:
            return self.head(z)      # [B, num_classes]
        return z                     # [B, latent_dim]

    def load_from_autoencoder(self, autoencoder: nn.Module, freeze: bool = True):
        """Copy the encoder weights from a trained Autoencoder (model 03)."""
        self.encoder.load_state_dict(autoencoder.encoder.state_dict())
        if freeze:
            for p in self.encoder.parameters():
                p.requires_grad = False
        return self


MODEL_META = {
    "id": "04_encoder",
    "name": "Encoder",
    "full_name": "Standalone Encoder / Latent Feature Extractor",
    "family": "Representation learning",
    "class_name": "Encoder",
    "tagline": "The autoencoder's encoder used on its own to emit a 32-d "
               "embedding for probing, transfer or clustering.",
    "input_shape": "[B, F]",
    "output_shape": "[B, D]  (D = latent_dim = 32)",
    "output_semantics": "latent embedding (logits only if attach_head=True)",
    "reshape_strategy": "None — operates directly on the 2D tabular batch.",
    "inductive_bias": "Identical to the autoencoder encoder, but the "
                      "representation is evaluated rather than inverted. "
                      "Isolating it lets the paper separate two questions "
                      "that are usually conflated: how much class structure "
                      "the unsupervised bottleneck captures, and how much "
                      "the supervised head adds on top.",
    "blocks": [
        ("input", "Input", "[B, 78]"),
        ("linear", "Linear + ReLU", "78 -> 64"),
        ("latent", "Linear + ReLU (latent)", "64 -> 32"),
        ("out", "Linear head (optional)", "32 -> 15"),
    ],
    "hyperparams": [
        ("latent_dim", "32", "Dimensionality of the emitted embedding"),
        ("hidden_dim", "64", "Intermediate width"),
        ("attach_head", "False", "Set True for the linear-probe experiment"),
        ("freeze", "True (transfer)", "Via load_from_autoencoder()"),
    ],
    "latex": (
        "The encoder realises $f_\\theta:\\mathbb{R}^{F}\\!\\to\\!\\mathbb{R}^{d}$, "
        "$\\mathbf{z}=f_\\theta(\\mathbf{x})="
        "\\sigma(\\mathbf{W}_2\\,\\sigma(\\mathbf{W}_1\\mathbf{x}+\\mathbf{b}_1)"
        "+\\mathbf{b}_2)$ with $d=32$. In the linear-probe protocol $\\theta$ "
        "is frozen after unsupervised pre-training and only "
        "$\\mathbf{W}_{p}\\in\\mathbb{R}^{C\\times d}$ is fitted, so the probe "
        "accuracy is a direct measure of the linear separability of the "
        "learned representation."
    ),
    "notes": [
        "Standard reporting for this model: (i) linear-probe macro-F1, "
        "(ii) k-NN (k=5) accuracy in the embedding space, and (iii) a "
        "2-D t-SNE or UMAP projection coloured by attack class — the "
        "qualitative figure reviewers expect from a representation section.",
        "Because the embedding is only 32-d, it is also the cheapest input "
        "for downstream classical classifiers (RF, XGBoost), which makes a "
        "useful hybrid row in the results table.",
    ],
}
