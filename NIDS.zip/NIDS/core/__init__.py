"""
core — all executable code for the CICIDS2017 NIDS baseline study.

    core/
      common/        preprocessing pipeline + analysis utilities
      models/        the eight nn.Module baselines
      tools/         artefact generation
      verify_all.py  smoke test for all eight models

Everything this package writes lands OUTSIDE core/, in the project root:
the per-model artefact folders (01_ann/ ... 08_cnn_gru/), comparison tables,
data/, checkpoints/, logs/ and docs/.
"""

__version__ = "1.0.0"
