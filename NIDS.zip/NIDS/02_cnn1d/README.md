# 02_cnn1d — 1D-CNN

**One-Dimensional Convolutional Neural Network** · family: *Convolutional*

Slides local kernels along the feature axis to learn translation-equivariant groups of adjacent flow statistics.

> **Source code:** [`core/models/cnn1d.py`](../core/models/cnn1d.py) — class `CNN1D`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | x.unsqueeze(1): [B, F] -> [B, 1, F]. One channel, sequence length F. |
| Parameters (total / trainable) | 7,311 / 7,311 |
| Model size (fp32) | 0.0279 MB |
| MACs per sample | 248,064 |
| CPU latency @ batch 32 | 0.5949 ms (53,787 samples/s) |

## 2. Inductive bias — why this model is in the study

Assumes locality along the feature axis — that column i and column i+1 are semantically related. For CICIDS2017 this holds only because the CICFlowMeter column order groups related statistics (forward packet-length family, backward packet-length family, IAT family, flag counts). This ordering dependence must be declared in the paper; a column-shuffle ablation is the standard way to quantify it.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | unsqueeze(1) | [B, 1, 78] |
| 3 | Conv1d k=3 + ReLU | 1 -> 32 ch |
| 4 | MaxPool1d /2 | 78 -> 39 |
| 5 | Conv1d k=3 + ReLU | 32 -> 64 ch |
| 6 | AdaptiveAvgPool1d(1) | [B, 64] |
| 7 | Linear (classifier) | 64 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `channels` | (32, 64) | Feature maps in conv block 1 / 2 |
| `kernel_size` | 3 | Receptive field per conv layer (padding=1) |
| `pooling` | MaxPool1d(2) then AdaptiveAvgPool1d(1) | Global head |
| `dropout` | 0.0 (placeholder) | Insert after each ReLU |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `conv1.0` | Conv1d | 32x1x78 | 32x32x78 | 128 |
| `conv1.1` | ReLU | 32x32x78 | 32x32x78 | 0 |
| `conv1.2` | MaxPool1d | 32x32x78 | 32x32x39 | 0 |
| `conv2.0` | Conv1d | 32x32x39 | 32x64x39 | 6,208 |
| `conv2.1` | ReLU | 32x64x39 | 32x64x39 | 0 |
| `pool` | AdaptiveAvgPool1d | 32x64x39 | 32x64x1 | 0 |
| `classifier` | Linear | 32x64 | 32x15 | 975 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
The feature vector is lifted to a single-channel signal $\mathbf{X}^{(0)}\in\mathbb{R}^{1\times F}$. Each convolutional block applies
\begin{equation}
X^{(l)}_{c,i}=\sigma\!\left(b_c+\sum_{c'=1}^{C_{l-1}}\sum_{j=-\lfloor k/2\rfloor}^{\lfloor k/2\rfloor}W^{(l)}_{c,c',j}\,X^{(l-1)}_{c',\,i+j}\right),
\end{equation}
with $k=3$ and zero padding. Block~1 is followed by max pooling with stride~2; the final map is reduced by global average pooling, $\bar{x}_c=\tfrac{1}{L}\sum_i X^{(2)}_{c,i}$, and classified by a single affine layer.
```

## 6. Reporting notes

- Global average pooling (rather than a flattened dense head) keeps the parameter count low and decouples the classifier from the feature count, so the same checkpoint definition transfers to UNSW-NB15 or CIC-IDS2018 feature sets.
- Report the column-order ablation: retrain on a fixed random permutation of the feature columns. A large drop is evidence the convolutional prior is doing real work; no drop suggests the model has degenerated to a weight-shared MLP.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import CNN1D

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = CNN1D(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
