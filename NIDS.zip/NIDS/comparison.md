# Baseline comparison — CICIDS2017 (ml.csv), 8 architectures

Verified with `torch.randn(32, 78)`, `num_classes=15`, PyTorch 2.14.0+cu130, CPU.

| id | model | family | class | source_file | input_shape | output_shape | output_type | reshape_in_forward | total_parameters | size_fp32_mb | macs_per_sample | latency_ms_bs32 | throughput_sps_bs1024 | n_leaf_layers |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 01_ann | ANN | Fully-connected | ANN | core/models/ann.py | [32, 78] | [32, 15] | class logits | None — the model consumes the raw 2D tabular batch | 55,055 | 0.21 | 54,656 | 0.128 | 1581697.7 | 5 |
| 02_cnn1d | 1D-CNN | Convolutional | CNN1D | core/models/cnn1d.py | [32, 78] | [32, 15] | class logits | x.unsqueeze(1): [B, F] -> [B, 1, F] | 7,311 | 0.0279 | 248,064 | 0.5613 | 49069.2 | 7 |
| 03_autoencoder | Autoencoder | Reconstruction / unsupervised | Autoencoder | core/models/autoencoder.py | [32, 78] | [32, 78] | reconstruction of the input (not logits) | None — operates directly on the 2D tabular batch | 14,318 | 0.0546 | 14,080 | 0.0883 | 2563262.6 | 7 |
| 04_encoder | Encoder | Representation learning | Encoder | core/models/encoder.py | [32, 78] | [32, 32] | latent embedding (logits only if attach_head=True) | None — operates directly on the 2D tabular batch | 7,136 | 0.0272 | 7,040 | 0.0465 | 6513559.8 | 4 |
| 05_transformer | Transformer | Attention | TabTransformer | core/models/transformer.py | [32, 78] | [32, 15] | class logits | x.unsqueeze(-1) -> [B, F, 1], then a shared Linear(1, d_model) lifts every scalar to a token | 73,231 | 0.2794 | 6,675,264 | 8.0766 | 1803.0 | 17 |
| 06_cnn_rnn | CNN-RNN | Hybrid convolutional-recurrent | CNNRNN | core/models/cnn_rnn.py | [32, 78] | [32, 15] | class logits | unsqueeze(1) -> [B, 1, F] | 15,631 | 0.0596 | 567,552 | 1.7749 | 29674.2 | 7 |
| 07_cnn_lstm | CNN-LSTM | Hybrid convolutional-recurrent (gated) | CNNLSTM | core/models/cnn_lstm.py | [32, 78] | [32, 15] | class logits | unsqueeze(1) -> [B, 1, F] | 40,591 | 0.1548 | 1,526,016 | 2.1013 | 18812.5 | 7 |
| 08_cnn_gru | CNN-GRU | Hybrid convolutional-recurrent (gated) | CNNGRU | core/models/cnn_gru.py | [32, 78] | [32, 15] | class logits | unsqueeze(1) -> [B, 1, F] | 32,271 | 0.1231 | 1,206,528 | 3.6051 | 16705.2 | 7 |
| 09_sigma | SIGMA-IDS | Proposed — grouped attention + invariance | SIGMANet | core/models/sigma.py | [32, 78] | [32, 15] | class logits (scaled cosine to class prototypes) | Group gather inside forward(): [B, F] -> [B, G, d] via one small encoder per semantic feature family | 96,946 | 0.3701 | 847,168 | 3.5295 | 21810.4 | 54 |
| 10_grn_mlp | GRN-MLP | Proposed — control | GRNMLP | core/models/gated_mlp.py | [32, 78] | [32, 15] | class logits (scaled cosine to class prototypes) | None — operates directly on the 2D tabular batch | 310,145 | 1.1831 | 304,896 | 1.1549 | 195769.2 | 20 |

Latency measured single-threaded on CPU; treat it as a relative ordering, not an absolute deployment figure.
