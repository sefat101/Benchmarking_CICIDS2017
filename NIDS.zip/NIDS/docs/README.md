# Paper

- `figures/` — copy an `architecture.svg` here once a figure is final, so
  regenerating artefacts never overwrites a figure already referenced by the
  manuscript.
- `tables/` — exported LaTeX/CSV tables (start from `../comparison.csv`).
