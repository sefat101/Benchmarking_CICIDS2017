# 03_autoencoder — Autoencoder

**Undercomplete Symmetric Autoencoder** · family: *Reconstruction / unsupervised*

Compresses the flow vector to a 32-d bottleneck and rebuilds it; the residual is the anomaly score.

> **Source code:** [`core/models/autoencoder.py`](../core/models/autoencoder.py) — class `Autoencoder`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, F]` — reconstruction of the input (not logits) |
| Verified output for `torch.randn(32, 78)` | `32x78` |
| Reshaping | None — operates directly on the 2D tabular batch. |
| Parameters (total / trainable) | 14,318 / 14,318 |
| Model size (fp32) | 0.0546 MB |
| MACs per sample | 14,080 |
| CPU latency @ batch 32 | 0.1611 ms (198,684 samples/s) |

## 2. Inductive bias — why this model is in the study

Assumes benign traffic occupies a low-dimensional manifold. Attacks are detected as points the decoder cannot reproduce, so the model needs no attack labels and — unlike the seven discriminative baselines — is not upper-bounded by the attack classes present in CICIDS2017. This is the zero-day arm of the study.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | Linear + ReLU (enc) | 78 -> 64 |
| 3 | Linear + ReLU (bottleneck) | 64 -> 32 |
| 4 | Linear + ReLU (dec) | 32 -> 64 |
| 5 | Linear (reconstruction) | 64 -> 78 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `latent_dim` | 32 | Bottleneck width; the compression ratio is F/32 |
| `hidden_dim` | 64 | Encoder/decoder intermediate width |
| `output activation` | linear | Matches standardised, unbounded inputs |
| `loss` | MSE | Per-feature mean squared reconstruction error |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `encoder.0` | Linear | 32x78 | 32x64 | 5,056 |
| `encoder.1` | ReLU | 32x64 | 32x64 | 0 |
| `encoder.2` | Linear | 32x64 | 32x32 | 2,080 |
| `encoder.3` | ReLU | 32x32 | 32x32 | 0 |
| `decoder.0` | Linear | 32x32 | 32x64 | 2,112 |
| `decoder.1` | ReLU | 32x64 | 32x64 | 0 |
| `decoder.2` | Linear | 32x64 | 32x78 | 5,070 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
The encoder $f_\theta:\mathbb{R}^{F}\!\to\!\mathbb{R}^{d}$ and decoder $g_\phi:\mathbb{R}^{d}\!\to\!\mathbb{R}^{F}$ with $d=32\ll F$ are trained on benign flows only by minimising
\begin{equation}
\mathcal{L}_{\mathrm{rec}}(\theta,\phi)=\frac{1}{|\mathcal{D}_{b}|}\sum_{\mathbf{x}\in\mathcal{D}_{b}}\bigl\|\mathbf{x}-g_\phi(f_\theta(\mathbf{x}))\bigr\|_2^2 .
\end{equation}
At inference a flow is flagged as anomalous when $s(\mathbf{x})=\|\mathbf{x}-g_\phi(f_\theta(\mathbf{x}))\|_2^2\;>\;\tau$, where $\tau$ is set at the $q$-th percentile of the benign validation scores (we report $q\in\{95,99\}$).
```

## 6. Reporting notes

- Do NOT report accuracy for this model against the 15-class task — it is a one-class detector. Report ROC-AUC, PR-AUC and the TPR at a fixed benign FPR (0.1% and 1% are the conventional operating points in the NIDS literature).
- The threshold must be calibrated on a benign-only validation split, never on the test set; state this explicitly in the methodology section to pre-empt a reviewer objection.
- Same encoder topology as model 04, which lets you report a clean pre-train / fine-tune transfer experiment.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import Autoencoder

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = Autoencoder(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
