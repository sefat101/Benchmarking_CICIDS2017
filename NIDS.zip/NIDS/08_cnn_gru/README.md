# 08_cnn_gru — CNN-GRU

**1D-CNN + Gated Recurrent Unit Network** · family: *Hybrid convolutional-recurrent (gated)*

Same stem as 06/07 with a two-gate recursion — the accuracy/parameter compromise between the vanilla RNN and the LSTM.

> **Source code:** [`core/models/cnn_gru.py`](../core/models/cnn_gru.py) — class `CNNGRU`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | unsqueeze(1) -> [B, 1, F]; permute(0, 2, 1) after the conv stem to obtain [B, T, feat] for nn.GRU. |
| Parameters (total / trainable) | 32,271 / 32,271 |
| Model size (fp32) | 0.1231 MB |
| MACs per sample | 1,206,528 |
| CPU latency @ batch 32 | 2.7027 ms (11,840 samples/s) |

## 2. Inductive bias — why this model is in the study

Reset and update gates give most of the LSTM's gradient-flow benefit with three weight matrices instead of four and no separate cell state. On short sequences — and 39 pooled positions is short — the GRU is the model most likely to match the LSTM at lower cost, which makes it the efficiency-frontier candidate of the recurrent family.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | unsqueeze(1) | [B, 1, 78] |
| 3 | Conv1d k=3 + ReLU | 1 -> 32 ch |
| 4 | MaxPool1d /2 | 78 -> 39 |
| 5 | Conv1d k=3 + ReLU | 32 -> 64 ch |
| 6 | permute(0,2,1) | [B, 39, 64] |
| 7 | GRU, 1 layer | hidden 64, 2 gates |
| 8 | Last time step | [B, 64] |
| 9 | Linear (classifier) | 64 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `channels` | (32, 64) | Conv stem feature maps |
| `kernel_size` | 3 | Conv receptive field |
| `hidden_size` | 64 | Hidden state width |
| `num_layers` | 1 | Recurrent depth |
| `bidirectional` | False | Set True for a Bi-GRU ablation |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `cnn.net.0` | Conv1d | 32x1x78 | 32x32x78 | 128 |
| `cnn.net.1` | ReLU | 32x32x78 | 32x32x78 | 0 |
| `cnn.net.2` | MaxPool1d | 32x32x78 | 32x32x39 | 0 |
| `cnn.net.3` | Conv1d | 32x32x39 | 32x64x39 | 6,208 |
| `cnn.net.4` | ReLU | 32x64x39 | 32x64x39 | 0 |
| `gru` | GRU | 32x39x64 | (32x39x64, 1x32x64) | 24,960 |
| `classifier` | Linear | 32x64 | 32x15 | 975 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
The GRU recursion over the pooled convolutional positions $\mathbf{u}_t$ is
\begin{align}
\mathbf{r}_t&=\varsigma(\mathbf{W}_r[\mathbf{u}_t,\mathbf{h}_{t-1}]+\mathbf{b}_r),\\
\mathbf{z}_t&=\varsigma(\mathbf{W}_z[\mathbf{u}_t,\mathbf{h}_{t-1}]+\mathbf{b}_z),\\
\tilde{\mathbf{h}}_t&=\tanh(\mathbf{W}_h[\mathbf{u}_t,\ \mathbf{r}_t\odot\mathbf{h}_{t-1}]+\mathbf{b}_h),\\
\mathbf{h}_t&=(1-\mathbf{z}_t)\odot\mathbf{h}_{t-1}+\mathbf{z}_t\odot\tilde{\mathbf{h}}_t,
\end{align}
and the terminal state $\mathbf{h}_L$ is mapped to class logits by a single affine layer.
```

## 6. Reporting notes

- Recurrent parameter count is 3(H(C+H)+2H) — three quarters of the LSTM at identical hidden_size. If the GRU matches the LSTM's macro-F1 within the seed variance, that is the headline efficiency result of the recurrent comparison.
- Report mean +/- std over at least 3 seeds before claiming any ordering among 06/07/08; the gaps between gated variants on short sequences are routinely smaller than seed noise.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import CNNGRU

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = CNNGRU(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
