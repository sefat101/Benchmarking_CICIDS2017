Put the CICIDS2017 `ml.csv` here.

`data/cache/` is written automatically by
`core/common/preprocessing.py` (cleaned .npy arrays + scaler.joblib +
manifest.json, keyed by a hash of the PreprocessConfig). Safe to delete —
it rebuilds on the next run.
