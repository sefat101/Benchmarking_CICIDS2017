@echo off
REM ---------------------------------------------------------------------
REM  NIDS baselines — one-shot environment setup (Windows, GTX 1070)
REM  Run from the project root:   setup.bat
REM  See SETUP.md for what each step does and why cu126 is not optional.
REM ---------------------------------------------------------------------
setlocal

cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    echo [1/4] .venv already exists - reusing it.
) else (
    echo [1/4] Creating virtual environment with Python 3.12...
    py -3.12 -m venv .venv
    if errorlevel 1 (
        echo.
        echo   Python 3.12 not found. Check what you have with:  py -0p
        echo   Then edit this file to use an installed 3.11 or 3.12.
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip --quiet

echo [2/4] Installing PyTorch from the cu126 index (Pascal / sm_61 kernels)...
pip install torch --index-url https://download.pytorch.org/whl/cu126
if errorlevel 1 exit /b 1

echo [3/4] Installing the remaining requirements...
pip install -r core\requirements.txt
if errorlevel 1 exit /b 1

echo [4/4] Checking the environment...
python core\tools\check_env.py

echo.
echo Done. Activate this environment in future sessions with:
echo    .venv\Scripts\activate
echo.
echo Then run:  python core\verify_all.py
endlocal
