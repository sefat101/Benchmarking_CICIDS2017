# 09_sigma — SIGMA-IDS

**Shortcut-Invariant Grouped Multi-head Attention IDS** · family: *Proposed — grouped attention + invariance*

Encodes the 78 flow statistics as ~11 semantic family tokens, gates them sparsely, and trains the pooled embedding to be uninformative about testbed nuisance variables.

> **Source code:** [`core/models/sigma.py`](../core/models/sigma.py) — class `SIGMANet`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits (scaled cosine to class prototypes) |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | Group gather inside forward(): [B, F] -> [B, G, d] via one small encoder per semantic feature family; a [CLS] token is prepended for pooling. |
| Parameters (total / trainable) | 96,946 / 96,946 |
| Model size (fp32) | 0.3701 MB |
| MACs per sample | 847,168 |
| CPU latency @ batch 32 | 3.5295 ms (9,067 samples/s) |

## 2. Inductive bias — why this model is in the study

Two priors the baselines lack. First, that the feature axis has family structure rather than either adjacency (1D-CNN) or none at all (ANN) — attention runs over ~11 families instead of 78 columns, cutting the pairwise cost ~50x and making the attention map interpretable at the level of a SOC analyst's vocabulary. Second, that a correct detector should be *unable* to recover which testbed host, port or capture day a flow came from; the gradient-reversal head turns that from an assumption into a trained constraint, which is what the leakage-free split actually measures.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | Group gather (11 families) | [B, 11, n_i] |
| 3 | Per-group encoder + LayerNorm | n_i -> 64 each |
| 4 | + Group embedding | [1, 11, 64] learnable |
| 5 | Sparsemax group gate | [B, 11] sparse |
| 6 | TransformerEncoder x2 (+CLS) | 4 heads, 11x11 attention |
| 7 | Wide residual path | 78 -> 128 -> 64 (added) |
| 8 | Pooled embedding | [B, 64] |
| 9 | Cosine prototype head | 64 -> 10 logits |
| 10 | GRL nuisance head (train only) | 64 -> 16 domains |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `d_model` | 64 | Token width |
| `nhead` | 4 | Attention heads |
| `num_layers` | 2 | Encoder blocks over 11+1 tokens |
| `n_groups` | 11 | Semantic families (contiguous blocks if names absent) |
| `use_gate` | True | Sparsemax group selection; ablate to isolate it |
| `use_wide_path` | True | Raw-vector residual; ablate to isolate attention |
| `grl_lambda` | 0.3 | Gradient-reversal strength; 0.0 disables invariance |
| `n_domains` | 16 | Nuisance buckets (port / host / day) |
| `proto_scale` | 10.0 | Initial cosine logit scale (learnable) |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `tokenizer.encoders.0.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.0.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.0.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.1.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.1.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.1.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.2.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.2.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.2.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.3.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.3.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.3.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.4.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.4.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.4.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.5.0` | Linear | 32x8 | 32x64 | 576 |
| `tokenizer.encoders.5.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.5.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.6.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.6.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.6.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.7.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.7.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.7.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.8.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.8.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.8.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.9.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.9.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.9.2` | GELU | 32x64 | 32x64 | 0 |
| `tokenizer.encoders.10.0` | Linear | 32x7 | 32x64 | 512 |
| `tokenizer.encoders.10.1` | LayerNorm | 32x64 | 32x64 | 128 |
| `tokenizer.encoders.10.2` | GELU | 32x64 | 32x64 | 0 |
| `gate_score` | Linear | 32x11x64 | 32x11x1 | 65 |
| `encoder.layers.0.norm1` | LayerNorm | 32x12x64 | 32x12x64 | 128 |
| `encoder.layers.0.dropout1` | Dropout | 32x12x64 | 32x12x64 | 0 |
| `encoder.layers.0.norm2` | LayerNorm | 32x12x64 | 32x12x64 | 128 |
| `encoder.layers.0.linear1` | Linear | 32x12x64 | 32x12x128 | 8,320 |
| `encoder.layers.0.dropout` | Dropout | 32x12x128 | 32x12x128 | 0 |
| `encoder.layers.0.linear2` | Linear | 32x12x128 | 32x12x64 | 8,256 |
| `encoder.layers.0.dropout2` | Dropout | 32x12x64 | 32x12x64 | 0 |
| `encoder.layers.1.norm1` | LayerNorm | 32x12x64 | 32x12x64 | 128 |
| `encoder.layers.1.dropout1` | Dropout | 32x12x64 | 32x12x64 | 0 |
| `encoder.layers.1.norm2` | LayerNorm | 32x12x64 | 32x12x64 | 128 |
| `encoder.layers.1.linear1` | Linear | 32x12x64 | 32x12x128 | 8,320 |
| `encoder.layers.1.dropout` | Dropout | 32x12x128 | 32x12x128 | 0 |
| `encoder.layers.1.linear2` | Linear | 32x12x128 | 32x12x64 | 8,256 |
| `encoder.layers.1.dropout2` | Dropout | 32x12x64 | 32x12x64 | 0 |
| `norm` | LayerNorm | 32x64 | 32x64 | 128 |
| `wide.0` | Linear | 32x78 | 32x128 | 10,112 |
| `wide.1` | GELU | 32x128 | 32x128 | 0 |
| `wide.2` | Dropout | 32x128 | 32x128 | 0 |
| `wide.3` | Linear | 32x128 | 32x64 | 8,256 |
| `head_drop` | Dropout | 32x64 | 32x64 | 0 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
Let $\mathcal{G}=\{g_1,\dots,g_G\}$ partition the feature indices into semantic families. Each family is encoded to a token
\begin{equation}
\mathbf{t}_j=\mathrm{GELU}\bigl(\mathrm{LN}(\mathbf{W}_j\,\mathbf{x}_{g_j}+\mathbf{b}_j)\bigr)+\mathbf{e}_j,\qquad \mathbf{t}_j\in\mathbb{R}^{d},
\end{equation}
and gated by $\boldsymbol{\alpha}=\mathrm{sparsemax}(\mathbf{w}_g^{\top}\mathbf{T})$, giving $\tilde{\mathbf{t}}_j=G\,\alpha_j\mathbf{t}_j$. A $[\mathrm{CLS}]$ token is prepended and $L$ pre-norm encoder blocks are applied; the pooled representation is $\mathbf{h}=\mathrm{LN}(\mathbf{T}^{(L)}_{0})+\phi(\mathbf{x})$ where $\phi$ is the wide residual path. Classification uses cosine prototypes $\mathbf{P}\in\mathbb{R}^{C\times d}$,
\begin{equation}
z_c=s\,\frac{\mathbf{h}^{\top}\mathbf{p}_c}{\|\mathbf{h}\|\,\|\mathbf{p}_c\|},
\end{equation}
and the training objective combines the logit-adjusted risk with the reversed nuisance term,
\begin{equation}
\mathcal{L}=\underbrace{\mathrm{CE}\bigl(\mathbf{z}+\tau\log\boldsymbol{\pi},\,y\bigr)}_{\text{long-tail correction}}\;-\;\lambda\,\underbrace{\mathrm{CE}\bigl(\psi(\mathbf{h}),\,d\bigr)}_{\text{nuisance predictability}},
\end{equation}
with $\boldsymbol{\pi}$ the training class prior, $d$ the nuisance label and $\lambda$ realised by a gradient-reversal layer so that a single forward pass suffices.
```

## 6. Reporting notes

- Construct with `feature_names=bundle.feature_names`. Without them the model falls back to contiguous blocks, which compiles and trains but discards the semantic prior the whole design rests on — that fallback is the smoke-test path, not a configuration to report.
- Report the three ablations that matter: grl_lambda=0 (no invariance), use_gate=False (dense groups), use_wide_path=False (attention only). If the full model does not beat all three under the grouped split, say so — the mechanism claim is what is being tested, not the headline number.
- The nuisance labels come from columns you deliberately excluded from the input (destination port, victim host, capture day). They must be carried alongside X through the split, never fed to the encoder.
- `open_set_score` gives a zero-day score at no extra cost. Calibrate its threshold on a validation split; a threshold tuned on test is the most common silent error in this literature.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import SIGMANet

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = SIGMANet(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
