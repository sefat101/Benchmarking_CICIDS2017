# 07_cnn_lstm — CNN-LSTM

**1D-CNN + Long Short-Term Memory Network** · family: *Hybrid convolutional-recurrent (gated)*

Same convolutional stem as 06, but the recursion carries an explicit cell state guarded by input, forget and output gates.

> **Source code:** [`core/models/cnn_lstm.py`](../core/models/cnn_lstm.py) — class `CNNLSTM`.
> This folder holds generated artefacts only; do not edit them by hand.
> Regenerate with `python core/tools/build_journal_outputs.py`.

![architecture](architecture.svg)

## 1. Interface

| | |
|---|---|
| Input tensor | `[B, F]` (raw 2D tabular batch) |
| Output tensor | `[B, C]` — class logits |
| Verified output for `torch.randn(32, 78)` | `32x15` |
| Reshaping | unsqueeze(1) -> [B, 1, F]; permute(0, 2, 1) after the conv stem to obtain [B, T, feat] for nn.LSTM. |
| Parameters (total / trainable) | 40,591 / 40,591 |
| Model size (fp32) | 0.1548 MB |
| MACs per sample | 1,526,016 |
| CPU latency @ batch 32 | 1.6167 ms (19,794 samples/s) |

## 2. Inductive bias — why this model is in the study

The additive cell-state path gives a gradient highway across the 39 pooled positions, so long-range dependencies between the early (forward-direction) and late (backward-direction, flag-count) regions of the CICFlowMeter feature vector survive back-propagation. Four gate matrices make it the most parameter-hungry recurrent variant of the three.

## 3. Architecture

| # | Block | Configuration |
|---|---|---|
| 1 | Input | [B, 78] |
| 2 | unsqueeze(1) | [B, 1, 78] |
| 3 | Conv1d k=3 + ReLU | 1 -> 32 ch |
| 4 | MaxPool1d /2 | 78 -> 39 |
| 5 | Conv1d k=3 + ReLU | 32 -> 64 ch |
| 6 | permute(0,2,1) | [B, 39, 64] |
| 7 | LSTM, 1 layer | hidden 64, 4 gates |
| 8 | Last time step | [B, 64] |
| 9 | Linear (classifier) | 64 -> 15 |

### Hyperparameters

| Argument | Default | Meaning |
|---|---|---|
| `channels` | (32, 64) | Conv stem feature maps |
| `kernel_size` | 3 | Conv receptive field |
| `hidden_size` | 64 | Hidden and cell state width |
| `num_layers` | 1 | Recurrent depth |
| `bidirectional` | False | Set True for a Bi-LSTM ablation |

## 4. Verified layer trace (`torch.randn(32, 78)`)

| Layer | Type | Input | Output | Params |
|---|---|---|---|---|
| `cnn.net.0` | Conv1d | 32x1x78 | 32x32x78 | 128 |
| `cnn.net.1` | ReLU | 32x32x78 | 32x32x78 | 0 |
| `cnn.net.2` | MaxPool1d | 32x32x78 | 32x32x39 | 0 |
| `cnn.net.3` | Conv1d | 32x32x39 | 32x64x39 | 6,208 |
| `cnn.net.4` | ReLU | 32x64x39 | 32x64x39 | 0 |
| `lstm` | LSTM | 32x39x64 | (32x39x64, (1x32x64, 1x32x64)) | 33,280 |
| `classifier` | Linear | 32x64 | 32x15 | 975 |

Full `torchinfo` table: [`summary.txt`](summary.txt) · raw trace: [`shape_trace.txt`](shape_trace.txt) · machine-readable: [`params.json`](params.json)

## 5. Formal description (LaTeX, ready for the methodology section)

```latex
With $\mathbf{u}_t$ the $t$-th pooled convolutional position, the LSTM cell computes
\begin{align}
\mathbf{i}_t&=\varsigma(\mathbf{W}_i[\mathbf{u}_t,\mathbf{h}_{t-1}]+\mathbf{b}_i), &
\mathbf{f}_t&=\varsigma(\mathbf{W}_f[\mathbf{u}_t,\mathbf{h}_{t-1}]+\mathbf{b}_f),\\
\mathbf{o}_t&=\varsigma(\mathbf{W}_o[\mathbf{u}_t,\mathbf{h}_{t-1}]+\mathbf{b}_o), &
\tilde{\mathbf{c}}_t&=\tanh(\mathbf{W}_c[\mathbf{u}_t,\mathbf{h}_{t-1}]+\mathbf{b}_c),\\
\mathbf{c}_t&=\mathbf{f}_t\odot\mathbf{c}_{t-1}+\mathbf{i}_t\odot\tilde{\mathbf{c}}_t, &
\mathbf{h}_t&=\mathbf{o}_t\odot\tanh(\mathbf{c}_t),
\end{align}
where $\varsigma$ is the logistic sigmoid. The terminal state $\mathbf{h}_L$ is mapped to logits by a single affine layer.
```

## 6. Reporting notes

- Parameter accounting for the recurrent block is 4(H(C+H)+2H) with C = 64 input channels and H = 64 hidden units — roughly four times the vanilla RNN of model 06. Cite the exact counts from comparison.csv rather than approximating.
- cuDNN fuses this kernel, so wall-clock time per epoch is usually closer to the GRU than the parameter ratio suggests; report both parameters and measured epoch time so the efficiency claim is defensible.
- If the LSTM does not beat the vanilla RNN here, that is a publishable negative result for 39-step synthetic sequences — report it rather than tuning until the expected ordering appears.

## 7. Usage

```python
from core.common.preprocessing import CICIDS2017Preprocessor, PreprocessConfig
from core.models import CNNLSTM

bundle = CICIDS2017Preprocessor(PreprocessConfig(csv_path="data/ml.csv")).run()
model  = CNNLSTM(input_dim=bundle.input_dim, num_classes=bundle.num_classes)
```

Never hardcode 78 — pass `bundle.input_dim`, because the constant-column and
collinearity pruning in the preprocessing pipeline changes the final feature
count.
