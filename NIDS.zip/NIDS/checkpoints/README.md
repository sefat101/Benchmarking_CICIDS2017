Trained weights (`.pt`). Suggested naming:
`<model_id>_seed<N>_<YYYYMMDD>.pt`, e.g. `07_cnn_lstm_seed0_20260908.pt`.
