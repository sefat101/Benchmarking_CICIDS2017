# SIGMA — Proposal Guideline

Semantically-Indexed Group-Modulated Architecture for reduced-class intrusion
detection on CICFlowMeter flow features.

> **Status of this document.** This is a research plan, not a report. It
> contains a problem statement, an architecture, two falsifiable hypotheses,
> and the decision rules that will be applied to the results. It contains **no
> measured results**, and every table below is a template with empty cells.
> Statements labelled CONJECTURE are conjecture and must not be copied into a
> results section. If SIGMA does not survive the tests specified here, this
> document tells you what to write instead.

---

## 1. The problem, stated narrowly

Broad framing ("deep learning improves intrusion detection") is unfalsifiable
and unpublishable. The problem this work addresses is specific:

**Under a leakage-free grouped evaluation of the reduced 10-class CICIDS2017
task, at a fixed operating point of 95% pooled attack recall, what false
positive rate is achievable, and can it be reduced without collapsing recall
on the minority classes?**

Three constraints make it hard, and all three are properties of the data
rather than of any model:

**Prevalence.** BENIGN is 80.4% of the retained flows. At 2,828,516 flows,
every 1 percentage point of FPR is roughly 22,700 false alarms. An analyst
team cannot triage that. FPR, not accuracy, is the operational currency.

**Imbalance.** BENIGN:Bot is 1,156:1. Bot has 1,966 flows in the entire
dataset. Any method whose minority-class performance depends on abundant
examples has nothing to work with here.

**Pooled recall hides the failure.** DoS Hulk, PortScan and DDoS together are
about 92% of all attack flows (arithmetic from `config.EXPECTED_CLASS_COUNTS`,
not a measurement). A model can reach 95% pooled attack recall while detecting
almost no Bot and almost no Slowhttptest. This is why the evaluation reports
per-class recall for all ten classes next to the pooled figure — the pooled
number alone would conceal exactly the failure mode this work targets.

The saturated random-split protocol, where macro-F1 sits near 0.99, cannot
show any of this. That is why it is a reference and not a claim surface.

---

## 2. The observation the architecture is built on

CICFlowMeter emits its 78 columns in an order fixed by its output code.
Column 34 sits next to column 35 because of how the extractor was written,
not because the two quantities are related. In the released files, timing
features, flag counters and packet-size statistics are interleaved.

Four of the eight baselines — `cnn1d`, `cnn_rnn`, `cnn_lstm`, `cnn_gru` —
apply convolution or recurrence along that axis. Doing so asserts that
neighbouring columns are related, which is an assumption about the extractor's
source code rather than about network traffic.

> **CONJECTURE.** These models are fitting to an artefact of column ordering.
> Their inductive bias contributes nothing that a permutation-invariant model
> could not obtain, and may actively cost them.

This is stated as conjecture because it has not been measured. Section 5.1
specifies the experiment that tests it and the sentence to write if it fails.

---

## 3. The architecture

Eleven semantic groups partition the 77 unique features (the released 78
columns include `Fwd Header Length.1`, which is byte-identical to
`Fwd Header Length`). The partition is in `core/common/feature_groups.py` and
is asserted disjoint and exhaustive at import.

| Group | n | What it measures |
| --- | --- | --- |
| endpoint | 4 | destination port, TCP initial windows, min segment size |
| volume | 9 | packet and byte totals, subflow counts |
| rate | 6 | duration, bytes/s, packets/s, down-up ratio |
| size_fwd | 5 | forward packet length distribution |
| size_bwd | 5 | backward packet length distribution |
| size_agg | 6 | direction-agnostic packet length distribution |
| iat | 14 | inter-arrival times, flow and per-direction |
| idle_active | 8 | active and idle burst structure |
| flags | 12 | TCP flag counters |
| header | 2 | header lengths |
| bulk | 6 | bulk-transfer statistics |

The forward pass:

1. Each group is encoded independently by its own small MLP to a shared
   embedding width. Weights are not shared across groups — the groups differ
   in both size and meaning.
2. A gate reads a summary of all group embeddings and emits a per-sample
   weight vector over the eleven groups.
3. Embeddings are modulated by those weights, concatenated, and read out by a
   classifier head.

Because group membership is resolved from **column names**, not column
positions, the model is invariant to column order by construction.

**Fairness.** SIGMA trains through the same loop, optimiser, schedule, loss,
balancing and calibration as all nine other models. Only the forward pass
differs. This is structural: models in this repo cannot define their own
training, because the loop lives in `core/common/model_utils.py`. The
gate-entropy regulariser is default-off; if enabled it becomes part of the
architecture definition, must be reported as such, and the same switch exists
on the control.

---

## 4. What would make this a contribution, and what would not

An honest accounting of where the novelty is, and is not.

**Not novel.** Gating and feature-group attention are established. Grouped
splits are established practice in evaluation methodology. FPR at fixed
recall is a standard detection metric. None of these is claimed as new.

**Candidate contribution.** The combination applied to a specific, measured
problem: reducing FPR at a fixed operational recall under leakage-free
evaluation on flow features, with the group structure derived from the
extractor's semantics rather than learned or arbitrary, and with an ablation
that isolates whether the semantics matter.

**The contribution is contingent on measurement.** If SIGMA does not separate
from its control by more than one standard deviation, the semantic partition
is not the mechanism, and the claim must be rewritten. Section 5.2 gives the
exact replacement sentence.

**Possible secondary contribution.** The gate weights are a per-sample,
per-group relevance vector. Averaged per class they form a 10 × 11 matrix
that is a direct readout of the model's own computation, not a post-hoc
saliency approximation. Whether it is *informative* is an empirical question
and must not be claimed in advance.

---

## 5. The two hypotheses, and the decision rules

Both decision rules are fixed **now**, before results exist. That is the point
of pre-registration: it removes the freedom to choose the interpretation after
seeing the numbers.

### 5.1 H1 — column-order sensitivity

*Models applying convolution or recurrence along the feature axis are
sensitive to a random permutation of column order; permutation-invariant
architectures are not, beyond retraining noise.*

```
python -m core.tools.run_experiment --protocols grouped --permute-columns
python -m core.tools.aggregate
```

| Model | Canonical macro-F1 | Permuted macro-F1 | Delta | Beyond 1 std? |
| --- | --- | --- | --- | --- |
| cnn1d | | | | |
| cnn_rnn | | | | |
| cnn_lstm | | | | |
| cnn_gru | | | | |
| transformer | | | | |
| ann | | | | |
| sigma | | | | |
| gated_mlp | | | | |

Decision rule, fixed in advance:

- Conv/recurrent rows degrade beyond one std, MLP-family rows do not →
  H1 survives; the architectural motivation holds and may be stated.
- **cnn1d does not degrade → H1 is falsified.** Write: *"We hypothesised that
  convolutional baselines exploit an artefact of CICFlowMeter's column
  ordering. A permutation test did not support this: cnn1d's macro-F1 was
  unchanged within one standard deviation under a random column permutation.
  The architectural motivation for SIGMA is therefore not supported by this
  evidence, and its case rests on the measured FPR comparison alone."*
- Mixed result → report per model. Do not aggregate into a single verdict.

The permutation seed is fixed in the runner, not drawn per run, specifically
so that "try another permutation" is not available as a response to an
unfavourable outcome.

### 5.2 H2 — the semantic partition does the work

*Grouping features by extractor semantics outperforms grouping them
arbitrarily, holding the gating machinery and capacity fixed.*

The control, `gated_mlp`, is SIGMA with the column-to-group assignment
scrambled by a fixed seed and the group *sizes* preserved, so parameter count
and capacity are matched. The comparison decomposes cleanly:

| Contrast | Isolates |
| --- | --- |
| sigma − gated_mlp | the semantic partition |
| gated_mlp − ann | the gating machinery |
| sigma − ann | the proposal as a whole |

| Model | FPR @ 95% recall | Macro-F1 | Bot recall |
| --- | --- | --- | --- |
| ann | | | |
| gated_mlp | | | |
| sigma | | | |

Decision rule, fixed in advance:

- sigma beats gated_mlp beyond one std → the semantic partition is load-bearing
  and the contribution stands as written.
- **sigma and gated_mlp tied within one std → H2 is falsified.** The
  contribution becomes *"group-gated MLPs are competitive on flow features,
  and the specific grouping does not matter"* — a smaller, different, still
  reportable claim. Rewrite the contribution sentence; do not rerun with a
  different arbitrary partition until one loses.
- gated_mlp beats sigma → report it. The semantic partition would then be
  actively harmful, which is an interesting negative result and belongs in the
  paper.

---

## 6. The full experimental grid

| Axis | Values | n |
| --- | --- | --- |
| Models | 8 baselines + sigma + gated_mlp | 10 |
| Protocols | random (reference), grouped (claim surface) | 2 |
| Seeds | 0–4 | 5 |
| **Main grid** | | **100 runs** |
| Permutation test | grouped only, all models | +50 |
| Gate ablation | sigma with uniform gate, grouped | +5 |
| Balancing sensitivity | one alternative strategy, all models, grouped | +50 |

Balancing deserves a note. The strategy is chosen **once** and applied to all
ten models. It is not a per-model knob. If you report a balancing sensitivity
study, every model appears in it, or it measures the balancing strategy rather
than the architecture.

Run order, and the reason for it:

1. Smoke run, two models, to prove the pipeline works.
2. Full grid on **random** first. It is the reference and it is fast to
   sanity-check — if macro-F1 there is not near 0.99, something is broken
   upstream, because that saturation is the known behaviour of this protocol.
3. Full grid on **grouped**. This is where the claim lives.
4. Permutation test.
5. Ablations.

---

## 7. Threats to validity — write these before someone asks

**Single dataset.** Every result is CICIDS2017. Nothing here demonstrates
generalisation to other networks, other capture periods, or other extractors.
State this as a limitation; do not soften it. CIC-IDS-2018 is the natural
external check and is out of scope for the current hardware budget.

**Known dataset defects.** CICIDS2017 has documented issues: duplicated flows,
labelling errors around attack-window boundaries, and defects in the
CICFlowMeter extraction itself (several bulk-transfer columns are constant
zero across the release). The pipeline audits and reports these rather than
silently cleaning them, because silently cleaning them would break
comparability with published baselines. Cite the corrected-dataset literature
and state that this work uses the original release for comparability.

**Episode definition is a modelling choice.** The 60-second gap and 300-second
cap are parameters. A reviewer may reasonably ask what happens at other
values. Run the grouped split at two alternative settings and report whether
the ordering of models changes. If it does, the ordering is an artefact of the
grouping parameters and must be reported as such.

**Grouped is stricter than random, not maximally strict.** Host-holdout is
stricter still, and this dataset cannot support it — too few attacker hosts,
so entire classes vanish from training. `build_host_holdout_split` exists as a
diagnostic to *demonstrate* that, which is itself a reportable finding about
the dataset. Do not report macro-F1 from it, because it changes the class set
between folds.

**Deterministic split under temporal assignment.** Under temporal assignment
the grouped split does not vary with seed. The reported standard deviation is
therefore model variance only, not split variance. State this explicitly —
a reviewer who assumes otherwise will read the error bars as wider evidence
than they are.

---

## 8. What to write if SIGMA simply does not win

This section exists so that the answer is decided before the results are.

A negative result here is publishable and is not a failure of the work. The
evaluation protocol is itself a contribution: a leakage-free grouped split for
CICIDS2017, a fixed-recall operating point, ten architectures compared under
one identical training recipe, five seeds with spread reported, and two
pre-registered falsification tests. That contribution does not depend on which
architecture wins.

If SIGMA is tied with or worse than the baselines on the grouped protocol:

- Report it in the abstract, not in a footnote.
- Keep the permutation test — an architecture-independent finding about what
  conv baselines are actually fitting has standalone value.
- Keep the gap between the random and grouped protocols. Quantifying how much
  of the field's reported ~0.99 macro-F1 survives a leakage-free split is
  useful to everyone working on this dataset.
- Reframe the contribution as evaluation methodology plus a negative
  architectural result.

What not to do, stated plainly because each is tempting and each is
misconduct: do not move the claim to the random split where scores saturate;
do not tune the threshold on test; do not drop Bot because it is hard; do not
drop the seed that came out worst; do not compare macro-F1 against a paper
using a different class set.

---

## 9. Reproduction

```
python -m core.tools.check_env
python -m core.tools.get_data_kaggle --search
python -m core.tools.get_data_kaggle --dataset <owner>/<slug>
python -m core.tools.build_dataset
python -m core.tools.run_experiment --protocols random grouped
python -m core.tools.run_experiment --protocols grouped --permute-columns
python -m core.tools.aggregate --latex
python -m core.tools.build_journal_outputs
```

Every run writes a manifest containing the git commit, the full argv, library
versions, the device, the balancing strategy, and the data fingerprint. A
number that cannot be traced to a manifest does not go in the paper.
