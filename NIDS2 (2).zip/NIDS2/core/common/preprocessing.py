"""Load, clean, audit, and join the two CICIDS2017 distributions.

WHAT THIS FILE REFUSES TO DO SILENTLY
-------------------------------------
* It will not drop a column because it looks useless. It AUDITS columns and
  reports what it found; the drop list is then explicit and recorded.
* It will not impute away infinities. CICFlowMeter emits +Inf in
  'Flow Bytes/s' and 'Flow Packets/s' whenever Flow Duration == 0. That is a
  real, informative event (single-packet flows), so it is clipped to a finite
  sentinel and a boolean indicator column is NOT added -- because adding one
  would change the feature set relative to the published baselines. The
  choice is recorded in the audit so a reviewer can see it.
* It will not fit a scaler on anything but train. The scaler is fit inside
  the split, never before it.
* It will not accept a class-count mismatch. If the archive you downloaded has
  different counts from config.EXPECTED_CLASS_COUNTS, you have a modified
  re-upload and the run stops.

THE JOIN
--------
MachineLearningCVE gives features; GeneratedLabelledFlows gives the group
keys (Timestamp, IPs). The two distributions are the same flows in the same
order, file for file -- but that is an ASSUMPTION, not a guarantee, so
join_metadata() VERIFIES it on the columns the two share and reports the
agreement rate. Below --join-min-agreement the join is rejected rather than
used, because a misaligned join would attach the wrong timestamps to flows
and quietly corrupt the grouped split -- producing a leakage-free-looking
protocol that is nothing of the kind.

PROVENANCE: everything here is measured from the files on disk at run time.
No number in this module is hard-coded except the CITED expectations in
config.py, which exist to be asserted against.
"""
from __future__ import annotations

import json
import warnings
from dataclasses import dataclass, asdict, field
from pathlib import Path

import numpy as np
import pandas as pd

from core import config
from core.common.feature_groups import (
    ALL_FEATURES, DUPLICATE_COLUMN, normalise_col,
)

# Sentinel for clipped infinities. Large but finite; the scaler sees it after
# clipping so it does not blow up the standardisation.
INF_SENTINEL = 1e12


@dataclass
class DataAudit:
    """Everything the loader noticed. Written next to the dataset."""
    n_rows_raw: int = 0
    n_rows_kept: int = 0
    retention: float = 0.0
    class_counts_found: dict[str, int] = field(default_factory=dict)
    class_counts_expected: dict[str, int] = field(default_factory=dict)
    class_count_mismatches: dict[str, int] = field(default_factory=dict)
    dropped_class_counts: dict[str, int] = field(default_factory=dict)
    n_dropped_nan_rows: int = 0
    n_inf_clipped: dict[str, int] = field(default_factory=dict)
    n_exact_duplicate_rows: int = 0
    constant_columns: list[str] = field(default_factory=list)
    near_constant_columns: dict[str, float] = field(default_factory=dict)
    duplicate_column_dropped: str | None = None
    negative_value_columns: dict[str, int] = field(default_factory=dict)
    columns_final: list[str] = field(default_factory=list)
    join_agreement: float | None = None
    join_method: str | None = None
    notes: list[str] = field(default_factory=list)

    def save(self, path: Path) -> None:
        path = config.assert_artefact_path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")

    def report(self) -> str:
        L = ["=" * 74, "DATA AUDIT", "=" * 74,
             f"rows raw           : {self.n_rows_raw:,}",
             f"rows kept          : {self.n_rows_kept:,}",
             f"retention          : {self.retention:.6%}",
             f"exact dup rows     : {self.n_exact_duplicate_rows:,}",
             f"rows dropped (NaN) : {self.n_dropped_nan_rows:,}",
             f"duplicate column   : {self.duplicate_column_dropped}",
             f"constant columns   : {len(self.constant_columns)} "
             f"{self.constant_columns}"]
        if self.near_constant_columns:
            L.append("near-constant (>99.9% one value):")
            for k, v in self.near_constant_columns.items():
                L.append(f"    {k:<40} {v:.5%}")
        if self.n_inf_clipped:
            L.append("infinities clipped:")
            for k, v in self.n_inf_clipped.items():
                L.append(f"    {k:<40} {v:,}")
        if self.class_count_mismatches:
            L.append("!! CLASS COUNT MISMATCH vs cited composition:")
            for k, v in self.class_count_mismatches.items():
                L.append(f"    {k:<25} {v:+,}")
        if self.join_agreement is not None:
            L.append(f"join method        : {self.join_method}")
            L.append(f"join agreement     : {self.join_agreement:.6%}")
        for n in self.notes:
            L.append(f"note: {n}")
        L.append("=" * 74)
        return "\n".join(L)


# --------------------------------------------------------------------------
def normalise_label(raw: str) -> str:
    """Map a raw label string onto the canonical set.

    Handles the mojibake in the Web Attack labels: the source CSVs contain a
    0x96 byte (cp1252 en-dash) that decodes variously as '\\x96', 'â\\x80\\x93'
    or U+FFFD depending on the reader's encoding. Anything containing
    'web attack' collapses to a single canonical name, which is then dropped.
    """
    s = str(raw).replace("�", "-").replace("\x96", "-")
    s = " ".join(s.split()).strip()
    low = s.lower()
    if "web attack" in low:
        if "brute" in low:
            return "Web Attack - Brute Force"
        if "xss" in low:
            return "Web Attack - XSS"
        if "sql" in low:
            return "Web Attack - Sql Injection"
        return "Web Attack - Brute Force"
    return config.LABEL_ALIASES.get(low, s)


def _dedup_names(names: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    out = []
    for n in names:
        if n in seen:
            seen[n] += 1
            out.append(f"{n}.{seen[n]}")
        else:
            seen[n] = 0
            out.append(n)
    return out


def _read_csv(path: Path) -> pd.DataFrame:
    """Read one CSV with high-performance pyarrow, falling back to pandas."""
    try:
        import pyarrow.csv as pv
        table = pv.read_csv(str(path))
        df = table.to_pandas()
        df.columns = _dedup_names(list(table.column_names))
        return df
    except Exception:
        pass

    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            return pd.read_csv(path, encoding=enc, low_memory=True,
                               skipinitialspace=True)
        except (UnicodeDecodeError, Exception):
            continue
    raise RuntimeError(f"could not decode {path} with utf-8/latin-1/cp1252")


def load_ml_csvs(ml_dir: Path, audit: DataAudit) -> pd.DataFrame:
    """Concatenate the 8 MachineLearningCVE CSVs, preserving file order."""
    import gc
    files = sorted(Path(ml_dir).rglob("*.csv"))
    if not files:
        raise FileNotFoundError(
            f"no CSVs under {ml_dir}. Run:\n"
            "  python -m core.tools.get_data --which both")
    audit.notes.append(f"{len(files)} ML csv file(s): "
                       f"{[f.name for f in files]}")
    frames = []
    total_raw = 0
    for f in files:
        df = _read_csv(f)
        total_raw += len(df)
        df.columns = [normalise_col(c) for c in df.columns]
        if DUPLICATE_COLUMN in df.columns:
            base = normalise_col("Fwd Header Length")
            if base in df.columns and df[DUPLICATE_COLUMN].equals(df[base]):
                audit.duplicate_column_dropped = DUPLICATE_COLUMN
            df = df.drop(columns=[DUPLICATE_COLUMN])
        df["__source_file"] = f.name
        df["__file_row"] = np.arange(len(df), dtype=np.int64)

        # Downcast feature columns to float32 immediately to minimize RAM footprint
        for col in df.columns:
            if col not in ("__source_file", "__file_row", "label"):
                df[col] = pd.to_numeric(df[col], errors="coerce").astype(np.float32)

        frames.append(df)
        gc.collect()

    out = pd.concat(frames, ignore_index=True)
    audit.n_rows_raw = total_raw
    return out


def clean_features(df: pd.DataFrame, audit: DataAudit) -> pd.DataFrame:
    """Label normalisation, class filtering, NaN/Inf handling, column audit."""
    label_col = "label"
    if label_col not in df.columns:
        cands = [c for c in df.columns if "label" in c]
        if not cands:
            raise KeyError(f"no label column found among {list(df.columns)[:20]}")
        label_col = cands[0]

    df["label_name"] = df[label_col].map(normalise_label)

    found_all = df["label_name"].value_counts().to_dict()
    audit.dropped_class_counts = {
        k: int(v) for k, v in found_all.items() if k in config.DROPPED_CLASSES}

    keep = df["label_name"].isin(config.CLASSES)
    unknown = set(found_all) - set(config.CLASSES) - set(config.DROPPED_CLASSES)
    if unknown:
        raise ValueError(
            f"unrecognised labels in the data: {sorted(unknown)}.\n"
            "Refusing to guess. Either this is not the CICIDS2017 release "
            "this pipeline targets, or normalise_label needs a new alias.")
    df = df.loc[keep].copy()
    audit.n_rows_kept = len(df)
    audit.retention = len(df) / max(audit.n_rows_raw, 1)

    # ---- assert composition against the cited counts --------------------
    counts = df["label_name"].value_counts().to_dict()
    audit.class_counts_found = {c: int(counts.get(c, 0)) for c in config.CLASSES}
    audit.class_counts_expected = dict(config.EXPECTED_CLASS_COUNTS)
    mism = {c: audit.class_counts_found[c] - config.EXPECTED_CLASS_COUNTS[c]
            for c in config.CLASSES
            if audit.class_counts_found[c] != config.EXPECTED_CLASS_COUNTS[c]}
    audit.class_count_mismatches = mism
    if mism and config.CLASS_COUNT_TOLERANCE == 0.0:
        raise ValueError(
            "class counts do not match the cited composition of "
            "MachineLearningCVE:\n"
            + "\n".join(f"  {k:<25} {v:+,}" for k, v in mism.items())
            + "\n\nThis usually means the archive is a third-party re-upload "
              "that has been deduplicated or re-labelled. Results from it are "
              "not comparable with the literature. Re-download from the CIC, "
              "or set config.CLASS_COUNT_TOLERANCE deliberately and document "
              "the deviation in the paper.")

    df["label_idx"] = df["label_name"].map(config.CLASS_TO_IDX).astype(np.int64)

    # ---- feature columns -------------------------------------------------
    if DUPLICATE_COLUMN in df.columns:
        a = df[DUPLICATE_COLUMN]
        base = normalise_col("Fwd Header Length")
        if base in df.columns and a.equals(df[base]):
            audit.duplicate_column_dropped = DUPLICATE_COLUMN
            audit.notes.append(
                f"{DUPLICATE_COLUMN!r} was byte-identical to {base!r}; dropped. "
                "The released file has 78 feature columns but only 77 unique "
                "features.")
        else:
            audit.notes.append(
                f"{DUPLICATE_COLUMN!r} present but NOT identical to {base!r}; "
                "dropped anyway to keep the feature set at 77, but this "
                "differs from the expected release and should be inspected.")
        df = df.drop(columns=[DUPLICATE_COLUMN])

    missing = [c for c in ALL_FEATURES if c not in df.columns]
    if missing:
        raise KeyError(f"expected feature columns absent: {missing}")

    X = df[list(ALL_FEATURES)].apply(pd.to_numeric, errors="coerce")

    # infinities -> finite sentinel, counted per column
    inf_mask = np.isinf(X.to_numpy(dtype=np.float64, na_value=np.nan))
    if inf_mask.any():
        per_col = inf_mask.sum(axis=0)
        audit.n_inf_clipped = {c: int(n)
                               for c, n in zip(ALL_FEATURES, per_col) if n}
        X = X.replace([np.inf, -np.inf], [INF_SENTINEL, -INF_SENTINEL])
        audit.notes.append(
            "Infinities arise where Flow Duration == 0 (single-packet flows). "
            f"Clipped to +/-{INF_SENTINEL:g}. No indicator column was added, "
            "because that would change the feature set relative to the "
            "published baselines.")

    nan_rows = X.isna().any(axis=1)
    audit.n_dropped_nan_rows = int(nan_rows.sum())
    if nan_rows.any():
        X = X.loc[~nan_rows]
        df = df.loc[~nan_rows]
        audit.notes.append(
            f"{audit.n_dropped_nan_rows:,} rows dropped for NaN features. "
            "If this number is large, inspect before trusting anything.")

    # ---- column audit: report, do not auto-drop -------------------------
    nun = X.nunique(dropna=False)
    audit.constant_columns = [c for c in ALL_FEATURES if nun.get(c, 0) <= 1]
    near: dict[str, float] = {}
    for c in ALL_FEATURES:
        if c in audit.constant_columns:
            continue
        top = X[c].value_counts(normalize=True, dropna=False)
        if len(top) and top.iloc[0] > 0.999:
            near[c] = float(top.iloc[0])
    audit.near_constant_columns = near
    neg = {c: int((X[c] < 0).sum()) for c in ALL_FEATURES if (X[c] < 0).any()}
    audit.negative_value_columns = neg
    if neg:
        audit.notes.append(
            "Negative values present in columns where they are not physically "
            f"meaningful: {sorted(neg)}. This is a known CICFlowMeter defect. "
            "They are LEFT AS IS -- removing them would deviate from the "
            "baselines' input. Flagged for the limitations section.")
    if audit.constant_columns:
        audit.notes.append(
            f"{len(audit.constant_columns)} constant column(s) carry zero "
            "information but are RETAINED, because every published baseline "
            "on this dataset consumes them. Dropping them would change the "
            "input relative to the literature. A standardiser maps them to 0.")

    dup_rows = df.duplicated(subset=list(ALL_FEATURES) + ["label_name"]).sum()
    audit.n_exact_duplicate_rows = int(dup_rows)
    audit.notes.append(
        f"{dup_rows:,} exact duplicate (features+label) rows detected. They "
        "are NOT removed here. Under the random protocol they are a leakage "
        "source; the grouped protocol handles them by construction. "
        "build_dataset.py --drop-exact-duplicates removes them if you want "
        "that variant -- applied to every model or not at all.")

    audit.columns_final = list(ALL_FEATURES)
    out = X.copy()
    out["label_idx"] = df["label_idx"].to_numpy()
    out["label_name"] = df["label_name"].to_numpy()
    out["__source_file"] = df["__source_file"].to_numpy()
    out["__file_row"] = df["__file_row"].to_numpy()
    return out.reset_index(drop=True)


# --------------------------------------------------------------------------
# The join that makes the grouped protocol possible
# --------------------------------------------------------------------------
_FLOW_KEY_ALIASES = {
    "timestamp": ["timestamp"],
    "src_ip": ["source ip", "src ip", "source address"],
    "dst_ip": ["destination ip", "dst ip", "destination address"],
    "src_port": ["source port", "src port"],
    "dst_port": ["destination port", "dst port"],
    "flow_id": ["flow id"],
}


def _find(df: pd.DataFrame, names: list[str]) -> str | None:
    for n in names:
        if n in df.columns:
            return n
    return None


def load_flow_metadata(flows_dir: Path, audit: DataAudit) -> pd.DataFrame:
    """Read TrafficLabelling_ CSVs, keeping only the key columns."""
    files = sorted(Path(flows_dir).rglob("*.csv"))
    if not files:
        raise FileNotFoundError(
            f"no CSVs under {flows_dir}. The grouped protocol needs "
            "GeneratedLabelledFlows. Run:\n"
            "  python -m core.tools.get_data --which both")
    frames = []
    for f in files:
        df = _read_csv(f)
        df.columns = [normalise_col(c) for c in df.columns]
        cols: dict[str, str] = {}
        for canon, aliases in _FLOW_KEY_ALIASES.items():
            src = _find(df, aliases)
            if src:
                cols[src] = canon
        keep = list(cols) + [c for c in df.columns if c == "label"]
        sub = df[keep].rename(columns=cols)
        sub["__source_file"] = f.name
        sub["__file_row"] = np.arange(len(df), dtype=np.int64)
        # carry a few numeric columns for join verification
        for probe in ("flow duration", "total fwd packets"):
            if probe in df.columns:
                sub[f"__probe_{probe.replace(' ', '_')}"] = pd.to_numeric(
                    df[probe], errors="coerce").to_numpy()
        frames.append(sub)
    meta = pd.concat(frames, ignore_index=True)

    if "timestamp" not in meta.columns:
        raise KeyError(
            "no Timestamp column in GeneratedLabelledFlows. Without it the "
            "grouped protocol cannot be built.")
    # The release mixes 12h and 24h forms and both D/M/Y and M/D/Y orders
    # across files. dayfirst=True matches the CIC's stated capture dates
    # (3-7 July 2017); parsing is verified below by checking the date range.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        meta["timestamp"] = pd.to_datetime(meta["timestamp"], errors="coerce",
                                           dayfirst=True)
    bad = int(meta["timestamp"].isna().sum())
    if bad:
        audit.notes.append(f"{bad:,} timestamps failed to parse -> NaT.")
    ok = meta["timestamp"].dropna()
    if len(ok):
        lo, hi = ok.min(), ok.max()
        audit.notes.append(f"timestamp range parsed as {lo} .. {hi}")
        if not (pd.Timestamp("2017-07-01") <= lo <= pd.Timestamp("2017-07-10")):
            audit.notes.append(
                "!! parsed timestamp range is outside the CICIDS2017 capture "
                "week (3-7 July 2017). dayfirst parsing is probably wrong for "
                "some files. The grouped split depends on this being right -- "
                "fix before reporting.")
    return meta


def join_metadata(feats: pd.DataFrame, meta: pd.DataFrame, audit: DataAudit,
                  min_agreement: float = 0.98) -> pd.DataFrame:
    """Attach timestamp/IP to the feature rows, and VERIFY the alignment.

    Method: positional, per source file. The two distributions are believed to
    be the same flows in the same order. That belief is tested by comparing a
    probe column ('flow duration') present in both. If agreement is below
    `min_agreement` the join is REJECTED -- a misaligned join silently
    corrupts the grouped split into something that looks leakage-free but is
    not.
    """
    audit.join_method = "positional per source file, verified on flow duration"

    # File names differ between distributions ('Monday-WorkingHours.pcap_ISCX
    # .csv' vs the ML variant). Align on sorted order of unique file names.
    f_files = sorted(feats["__source_file"].unique())
    m_files = sorted(meta["__source_file"].unique())
    if len(f_files) != len(m_files):
        raise RuntimeError(
            f"file-count mismatch: {len(f_files)} feature files vs "
            f"{len(m_files)} flow files. Cannot align positionally. "
            "Inspect both directories.")
    audit.notes.append(f"file pairing: {list(zip(f_files, m_files))}")

    pieces = []
    agree_num = agree_den = 0
    for ff, mf in zip(f_files, m_files):
        fsub = feats[feats["__source_file"] == ff].sort_values("__file_row")
        msub = meta[meta["__source_file"] == mf].sort_values("__file_row")
        # feature rows may be fewer (NaN rows dropped); realign on __file_row
        msub = msub.set_index("__file_row")
        idx = fsub["__file_row"].to_numpy()
        common = np.intersect1d(idx, msub.index.to_numpy())
        if len(common) != len(idx):
            audit.notes.append(
                f"{ff}: {len(idx) - len(common):,} feature rows had no "
                "positional counterpart in the flow file")
        msel = msub.loc[common]
        fsel = fsub.set_index("__file_row").loc[common]

        probe = "__probe_flow_duration"
        if probe in msel.columns and "flow duration" in fsel.columns:
            a = fsel["flow duration"].to_numpy(dtype=np.float64)
            b = msel[probe].to_numpy(dtype=np.float64)
            ok = np.isclose(a, b, rtol=1e-6, atol=1e-6, equal_nan=True)
            agree_num += int(ok.sum())
            agree_den += int(len(ok))

        out = fsel.copy()
        for c in ("timestamp", "src_ip", "dst_ip"):
            out[c] = msel[c].to_numpy() if c in msel.columns else np.nan
        out["__file_row"] = common
        pieces.append(out.reset_index(drop=True))

    joined = pd.concat(pieces, ignore_index=True)
    audit.join_agreement = (agree_num / agree_den) if agree_den else None

    if audit.join_agreement is None:
        raise RuntimeError(
            "could not verify the join -- no probe column common to both "
            "distributions. Refusing to proceed on an unverified alignment.")
    if audit.join_agreement < min_agreement:
        raise RuntimeError(
            f"JOIN REJECTED. Probe agreement {audit.join_agreement:.4%} is "
            f"below the required {min_agreement:.2%}.\n"
            "The two distributions are not in the same row order, so the "
            "timestamps would be attached to the wrong flows. The grouped "
            "split built on that would LOOK leakage-free and would not be. "
            "Fix the alignment (try matching on Flow ID) before continuing.")
    audit.notes.append(
        f"join verified: {audit.join_agreement:.4%} of rows agree on flow "
        "duration between the two distributions.")
    for c in ("src_ip", "dst_ip"):
        if joined[c].isna().any():
            audit.notes.append(f"{int(joined[c].isna().sum()):,} rows missing {c}")
    return joined


# --------------------------------------------------------------------------
# Scaling -- fit on TRAIN ONLY
# --------------------------------------------------------------------------
class Standardiser:
    """Log1p-then-standardise. Fit on train indices only.

    The log1p is applied to heavy-tailed non-negative columns before
    standardising, because raw byte/duration columns span ~12 orders of
    magnitude and a plain z-score leaves the tail dominating every gradient.
    Applied identically to every model's input (rule 5).
    """

    def __init__(self, log_transform: bool = True):
        self.log_transform = log_transform
        self.mean_: np.ndarray | None = None
        self.std_: np.ndarray | None = None
        self.log_cols_: np.ndarray | None = None

    def fit(self, X: np.ndarray) -> "Standardiser":
        X = np.asarray(X, dtype=np.float64)
        if self.log_transform:
            self.log_cols_ = (X >= 0).all(axis=0) & (X.max(axis=0) > 1e3)
            Xt = self._apply_log(X)
        else:
            self.log_cols_ = np.zeros(X.shape[1], dtype=bool)
            Xt = X
        self.mean_ = Xt.mean(axis=0)
        s = Xt.std(axis=0)
        s[s < 1e-8] = 1.0          # constant columns -> map to exactly 0
        self.std_ = s
        return self

    def _apply_log(self, X: np.ndarray) -> np.ndarray:
        Xt = X.copy()
        c = self.log_cols_
        Xt[:, c] = np.log1p(np.clip(Xt[:, c], 0, None))
        return Xt

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.mean_ is None:
            raise RuntimeError("Standardiser used before fit")
        Xt = self._apply_log(np.asarray(X, dtype=np.float64)) \
            if self.log_transform else np.asarray(X, dtype=np.float64)
        return ((Xt - self.mean_) / self.std_).astype(np.float32)

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)


def fit_scaler_on_train(X: np.ndarray, train_idx: np.ndarray) -> Standardiser:
    """The only sanctioned way to build a scaler.

    Fitting on the full matrix leaks test statistics into training. It is a
    small leak and it is still a leak; reviewers look for it.
    """
    return Standardiser().fit(np.asarray(X)[train_idx])
