"""Minimal dependency-free PDF writer, and a markdown subset renderer.

WHY THIS EXISTS INSTEAD OF reportlab / weasyprint / pandoc
----------------------------------------------------------
The guideline documents in this repo must be regenerable on any machine that
can run the rest of the code, with no extra install and no network. This
module uses only the standard library and the 14 built-in PDF base fonts, so
it works anywhere Python does.

WHAT IT SUPPORTS
----------------
    # / ## / ###      headings
    plain paragraphs  wrapped to the text column, with **bold** runs
    - bullet          bullets, one level
    1. numbered       numbered items
    | a | b |         tables; long cells WRAP, they are not truncated
    ```               fenced code blocks (monospaced, hard-wrapped)
    ---               horizontal rule
    \\pagebreak        force a new page
    > quote           shaded callout

WHAT IT DOES NOT SUPPORT
------------------------
Italics (no italic base font is loaded; `*text*` renders upright), images,
nested lists, unicode beyond Latin-1. Inline `code` spans lose their
backticks. Link syntax renders as the link text.

CORRECTNESS NOTES
-----------------
1. The cross-reference table stores absolute byte offsets, so every offset is
   recorded from the live buffer as each object is appended -- never computed
   in advance. Each xref entry is exactly 20 bytes as the spec requires.

2. Characters outside Latin-1 that have no transliteration are recorded in
   UNMAPPED rather than silently becoming '?'. A build tool can then report
   them. Silent character substitution in a document whose whole job is to be
   precise is the kind of defect nobody notices until a reviewer does.

3. Table cells wrap. An earlier version truncated them to fit, which quietly
   removed the right-hand column of every prose-bearing table -- exactly the
   column that carried the reasoning.

4. The font metrics below are the standard Helvetica / Helvetica-Bold /
   Courier advance widths, used ONLY for line wrapping. An error of a few
   thousandths of an em produces a marginally short or long line, never a
   malformed file. A 3% safety margin is applied to the text column.
"""
from __future__ import annotations

import re
import textwrap
from pathlib import Path

# --------------------------------------------------------------------------
# Font metrics (units per 1000 em) for the base-14 fonts used here.
# --------------------------------------------------------------------------
_HELV = {
    ' ': 278, '!': 278, '"': 355, '#': 556, '$': 556, '%': 889, '&': 667,
    "'": 191, '(': 333, ')': 333, '*': 389, '+': 584, ',': 278, '-': 333,
    '.': 278, '/': 278, ':': 278, ';': 278, '<': 584, '=': 584, '>': 584,
    '?': 556, '@': 1015, '[': 278, '\\': 278, ']': 278, '^': 469, '_': 556,
    '`': 333, '{': 334, '|': 260, '}': 334, '~': 584,
    'A': 667, 'B': 667, 'C': 722, 'D': 722, 'E': 667, 'F': 611, 'G': 778,
    'H': 722, 'I': 278, 'J': 500, 'K': 667, 'L': 556, 'M': 833, 'N': 722,
    'O': 778, 'P': 667, 'Q': 778, 'R': 722, 'S': 667, 'T': 611, 'U': 722,
    'V': 667, 'W': 944, 'X': 667, 'Y': 667, 'Z': 611,
    'a': 556, 'b': 556, 'c': 500, 'd': 556, 'e': 556, 'f': 278, 'g': 556,
    'h': 556, 'i': 222, 'j': 222, 'k': 500, 'l': 222, 'm': 833, 'n': 556,
    'o': 556, 'p': 556, 'q': 556, 'r': 333, 's': 500, 't': 278, 'u': 556,
    'v': 500, 'w': 722, 'x': 500, 'y': 500, 'z': 500,
}
_HELV_B = dict(_HELV)
_HELV_B.update({
    '!': 333, '"': 474, '&': 722, "'": 238, '?': 611, '@': 975, ':': 333,
    ';': 333, '[': 333, ']': 333, '^': 584, '`': 333, '{': 389, '|': 280,
    '}': 389,
    'A': 722, 'B': 722, 'C': 722, 'D': 722, 'E': 667, 'F': 611, 'G': 778,
    'H': 722, 'I': 278, 'J': 556, 'K': 722, 'L': 611, 'M': 833, 'N': 722,
    'O': 778, 'P': 667, 'Q': 778, 'R': 722, 'S': 667, 'T': 611, 'U': 722,
    'V': 667, 'W': 944, 'X': 667, 'Y': 667, 'Z': 611,
    'a': 556, 'b': 611, 'c': 556, 'd': 611, 'e': 556, 'f': 333, 'g': 611,
    'h': 611, 'i': 278, 'j': 278, 'k': 556, 'l': 278, 'm': 889, 'n': 611,
    'o': 611, 'p': 611, 'q': 611, 'r': 389, 's': 556, 't': 333, 'u': 611,
    'v': 556, 'w': 778, 'x': 556, 'y': 556, 'z': 500,
})
for _d in (_HELV, _HELV_B):
    for _c in "0123456789":
        _d[_c] = 556

#: name -> (BaseFont, width table or None, monospace advance or 0)
FONTS = {
    "F1": ("Helvetica", _HELV, 0),
    "F2": ("Helvetica-Bold", _HELV_B, 0),
    "F3": ("Courier", None, 600),
    "F4": ("Courier-Bold", None, 600),
}
FONT_ORDER = ("F1", "F2", "F3", "F4")
MONO, MONO_B = "F3", "F4"


def text_width(s: str, font: str, size: float) -> float:
    _, table, mono = FONTS[font]
    if mono:
        return len(s) * mono * size / 1000.0
    total = 0
    for ch in s:
        total += table.get(ch, 500)
    return total * size / 1000.0


# --------------------------------------------------------------------------
# Latin-1 transliteration.
# UNMAPPED records anything we had to destroy, so the caller can report it.
# --------------------------------------------------------------------------
_TRANSLIT = {
    "—": "--",   # em dash
    "–": "-",    # en dash
    "−": "-",    # MINUS SIGN -- used in "sigma - gated_mlp" contrasts
    "‘": "'", "’": "'",
    "“": '"', "”": '"',
    "…": "...",
    "±": "+/-",
    "→": "->", "←": "<-",
    "≤": "<=", "≥": ">=",
    "≠": "!=", "≈": "~",
    "×": "x", "÷": "/",
    "•": "-", " ": " ", "‑": "-",
    "σ": "sigma", "μ": "mu", "Δ": "Delta", "α": "alpha",
    "✓": "[x]", "✗": "[ ]",
    "’": "'",
}

#: char -> occurrence count, for characters lost to the Latin-1 encoder.
UNMAPPED: dict[str, int] = {}


def to_latin1(s: str) -> str:
    for k, v in _TRANSLIT.items():
        if k in s:
            s = s.replace(k, v)
    try:
        s.encode("latin-1")
    except UnicodeEncodeError:
        for ch in s:
            if ord(ch) > 255:
                UNMAPPED[ch] = UNMAPPED.get(ch, 0) + 1
        s = s.encode("latin-1", "replace").decode("latin-1")
    return s


def esc(s: str) -> str:
    return (to_latin1(s).replace("\\", r"\\")
            .replace("(", r"\(").replace(")", r"\)"))


# --------------------------------------------------------------------------
# Inline markup
# --------------------------------------------------------------------------
_LINK = re.compile(r"\[([^\]]+)\]\([^)]*\)")
_CODE = re.compile(r"`([^`]+)`")
_BOLD = re.compile(r"\*\*(.+?)\*\*|__(.+?)__")
_ITAL = re.compile(r"(?<![*\w])\*([^*]+)\*(?![*\w])")


def strip_inline(s: str) -> str:
    """Remove markup we cannot render, keeping the text."""
    s = to_latin1(s)
    s = _LINK.sub(r"\1", s)
    s = _CODE.sub(r"\1", s)
    s = _BOLD.sub(lambda m: m.group(1) or m.group(2), s)
    s = _ITAL.sub(r"\1", s)
    return s


def parse_runs(s: str) -> list[tuple[str, bool]]:
    """Split a line into (text, is_bold) runs."""
    s = to_latin1(s)
    s = _LINK.sub(r"\1", s)
    s = _CODE.sub(r"\1", s)
    runs: list[tuple[str, bool]] = []
    pos = 0
    for m in _BOLD.finditer(s):
        if m.start() > pos:
            runs.append((s[pos:m.start()], False))
        runs.append((m.group(1) or m.group(2), True))
        pos = m.end()
    if pos < len(s):
        runs.append((s[pos:], False))
    out = []
    for t, b in runs:
        t = _ITAL.sub(r"\1", t)
        if t:
            out.append((t, b))
    return out or [("", False)]


def _tokens(runs: list[tuple[str, bool]]) -> list[tuple[str, bool]]:
    toks: list[tuple[str, bool]] = []
    for text, bold in runs:
        for w in text.split():
            toks.append((w, bold))
    return toks


# --------------------------------------------------------------------------
# Page geometry (A4)
# --------------------------------------------------------------------------
PW, PH = 595.28, 841.89
ML, MR, MT, MB = 56.0, 56.0, 64.0, 56.0
COL = (PW - ML - MR) * 0.97          # 3% safety margin on wrap width


class _Page:
    def __init__(self) -> None:
        self.ops: list[str] = []
        self.y = PH - MT


class PDF:
    """Accumulates drawing operations, then serialises with exact offsets."""

    def __init__(self, title: str, footer: str = "") -> None:
        self.title = title
        self.footer = footer
        self.pages: list[_Page] = [_Page()]
        self._saved = False

    # -- low level ------------------------------------------------------
    @property
    def p(self) -> _Page:
        return self.pages[-1]

    def new_page(self) -> None:
        self.pages.append(_Page())

    def space(self, h: float) -> None:
        if self.p.y - h < MB:
            self.new_page()
        else:
            self.p.y -= h

    def _need(self, h: float) -> None:
        if self.p.y - h < MB:
            self.new_page()

    def line_at(self, x: float, y: float, s: str, font: str, size: float,
                gray: float | None = None) -> None:
        if not s:
            return
        g = f"{gray:.3f} {gray:.3f} {gray:.3f} rg\n" if gray is not None else ""
        reset = "0 0 0 rg\n" if gray is not None else ""
        self.p.ops.append(
            f"{g}BT\n/{font} {size:.2f} Tf\n1 0 0 1 {x:.2f} {y:.2f} Tm\n"
            f"({esc(s)}) Tj\nET\n{reset}")

    def draw_runs(self, x: float, y: float, line: list[tuple[str, bool]],
                  size: float, gray: float | None = None) -> None:
        """Draw one wrapped line, merging adjacent same-font tokens."""
        cx, i, n = x, 0, len(line)
        while i < n:
            bold = line[i][1]
            j, chunk = i, []
            while j < n and line[j][1] == bold:
                chunk.append(line[j][0])
                j += 1
            font = "F2" if bold else "F1"
            if i:
                cx += text_width(" ", font, size)
            s = " ".join(chunk)
            self.line_at(cx, y, s, font, size, gray)
            cx += text_width(s, font, size)
            i = j

    def rule(self, gray: float = 0.75, pad: float = 6.0) -> None:
        self._need(pad * 2)
        self.p.y -= pad
        self.p.ops.append(
            f"{gray} {gray} {gray} RG\n0.6 w\n{ML:.2f} {self.p.y:.2f} m\n"
            f"{PW - MR:.2f} {self.p.y:.2f} l\nS\n0 0 0 RG\n")
        self.p.y -= pad

    def box(self, height: float, gray: float = 0.94, pad_top: float = 10.0
            ) -> None:
        """Filled background block, drawn before the text that sits on it."""
        self.p.ops.append(
            f"{gray} {gray} {gray} rg\n{ML - 6:.2f} "
            f"{self.p.y - height + pad_top:.2f} "
            f"{PW - ML - MR + 12:.2f} {height:.2f} re\nf\n0 0 0 rg\n")

    # -- wrapping -------------------------------------------------------
    @staticmethod
    def wrap(s: str, font: str, size: float, width: float) -> list[str]:
        words = to_latin1(s).split()
        if not words:
            return [""]
        lines, cur = [], words[0]
        for w in words[1:]:
            trial = cur + " " + w
            if text_width(trial, font, size) <= width:
                cur = trial
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
        return lines

    @staticmethod
    def wrap_runs(toks: list[tuple[str, bool]], size: float, width: float
                  ) -> list[list[tuple[str, bool]]]:
        if not toks:
            return [[]]
        lines: list[list[tuple[str, bool]]] = []
        cur: list[tuple[str, bool]] = []
        curw = 0.0
        for tok, bold in toks:
            font = "F2" if bold else "F1"
            tw = text_width(tok, font, size)
            adv = tw if not cur else tw + text_width(" ", font, size)
            if cur and curw + adv > width:
                lines.append(cur)
                cur, curw = [(tok, bold)], tw
            else:
                cur.append((tok, bold))
                curw += adv
        if cur:
            lines.append(cur)
        return lines or [[]]

    # -- block elements -------------------------------------------------
    def heading(self, text: str, level: int) -> None:
        size = {1: 19.0, 2: 13.5, 3: 11.0}[level]
        lead = {1: 25.0, 2: 18.0, 3: 15.0}[level]
        before = {1: 16.0, 2: 18.0, 3: 12.0}[level]
        text = strip_inline(text)
        self.space(before)
        # Widow guard: never leave a heading alone at the foot of a page.
        self._need(lead * 2 + 34.0)
        for ln in self.wrap(text, "F2", size, COL):
            self._need(lead)
            self.p.y -= lead
            self.line_at(ML, self.p.y, ln, "F2", size)
        if level == 1:
            self.rule(0.6, 5.0)
        self.space(4.0)

    def para(self, text: str, size: float = 9.6, lead: float = 13.2,
             indent: float = 0.0, gray: float | None = None) -> None:
        toks = _tokens(parse_runs(text))
        for ln in self.wrap_runs(toks, size, COL - indent):
            self._need(lead)
            self.p.y -= lead
            self.draw_runs(ML + indent, self.p.y, ln, size, gray)
        self.space(3.0)

    def bullet(self, text: str, marker: str = "-", size: float = 9.6,
               lead: float = 12.6, indent: float = 12.0) -> None:
        hang = indent + text_width(marker + "  ", "F1", size)
        toks = _tokens(parse_runs(text))
        lines = self.wrap_runs(toks, size, COL - hang)
        for i, ln in enumerate(lines):
            self._need(lead)
            self.p.y -= lead
            if i == 0:
                self.line_at(ML + indent, self.p.y, marker, "F2", size)
            self.draw_runs(ML + hang, self.p.y, ln, size)
        self.space(1.5)

    def quote(self, text: str, size: float = 9.4, lead: float = 12.6) -> None:
        toks = _tokens(parse_runs(text))
        lines = self.wrap_runs(toks, size, COL - 24)
        h = len(lines) * lead + 14
        self._need(h)
        self.box(h, 0.93)
        for ln in lines:
            self.p.y -= lead
            self.draw_runs(ML + 12, self.p.y, ln, size, 0.12)
        self.space(10.0)

    def code(self, lines: list[str], size: float = 8.3, lead: float = 10.4
             ) -> None:
        """Monospaced block. Long lines HARD-WRAP rather than being clipped.

        Clipping would silently amputate the end of a shell command, which in
        a document whose purpose is to tell you what to run is a real defect
        rather than a cosmetic one.
        """
        maxc = max(20, int((COL - 16) / (600 * size / 1000.0)))
        block: list[str] = []
        for raw in lines:
            ln = to_latin1(raw.replace("\t", "    ")).rstrip()
            if not ln:
                block.append("")
                continue
            while len(ln) > maxc:
                block.append(ln[:maxc])
                ln = "    " + ln[maxc:]      # continuation, visibly indented
            block.append(ln)

        i = 0
        while i < len(block):
            avail = int((self.p.y - MB - 14) // lead)
            if avail < 1:
                self.new_page()
                avail = int((self.p.y - MB - 14) // lead)
            take = block[i:i + avail]
            self.box(len(take) * lead + 14, 0.95)
            for ln in take:
                self.p.y -= lead
                self.line_at(ML + 8, self.p.y, ln, MONO, size)
            i += len(take)
            if i < len(block):
                self.new_page()
        self.space(9.0)

    def table(self, rows: list[list[str]], size: float = 8.3,
              lead: float = 11.0) -> None:
        """Monospaced table. Cells WRAP to fit; nothing is truncated.

        Header and body are both monospaced (Courier-Bold / Courier) so the
        columns actually line up -- a proportional header over a monospaced
        body does not.
        """
        if not rows:
            return
        ncol = max(len(r) for r in rows)
        grid = [[strip_inline(c) for c in r] + [""] * (ncol - len(r))
                for r in rows]

        cw = 600 * size / 1000.0
        total = max(ncol * 4, int((COL - 12) / cw))
        budget = total - 2 * (ncol - 1)
        nat = [max(1, max(len(r[c]) for r in grid)) for c in range(ncol)]

        if sum(nat) <= budget:
            w = nat[:]
        else:
            floor = 8 if budget >= ncol * 8 else max(3, budget // ncol)
            w = [max(floor, int(budget * v / sum(nat))) for v in nat]
            guard = 0
            while sum(w) > budget and guard < 10_000:
                k = w.index(max(w))
                if w[k] <= floor:
                    break
                w[k] -= 1
                guard += 1
            while sum(w) < budget:
                w[w.index(min(w))] += 1

        def cell_lines(row: list[str]) -> list[str]:
            cols = [textwrap.wrap(row[c], w[c]) or [""] for c in range(ncol)]
            height = max(len(c) for c in cols)
            out = []
            for k in range(height):
                out.append("  ".join(
                    (cols[c][k] if k < len(cols[c]) else "").ljust(w[c])
                    for c in range(ncol)).rstrip())
            return out

        head = cell_lines(grid[0])
        sep = "  ".join("-" * x for x in w)

        def emit_head() -> None:
            for hl in head:
                self.p.y -= lead
                self.line_at(ML + 4, self.p.y, hl, MONO_B, size)
            self.p.y -= lead
            self.line_at(ML + 4, self.p.y, sep, MONO, size, 0.45)

        self.space(3.0)
        self._need((len(head) + 2) * lead)
        emit_head()

        for row in grid[1:]:
            body = cell_lines(row)
            if self.p.y - len(body) * lead < MB:
                self.new_page()
                emit_head()
            for bl in body:
                self.p.y -= lead
                self.line_at(ML + 4, self.p.y, bl, MONO, size)
        self.space(9.0)

    # -- serialisation ---------------------------------------------------
    def _decorate(self) -> None:
        n = len(self.pages)
        for i, pg in enumerate(self.pages, start=1):
            pg.ops.append(
                f"0.55 0.55 0.55 rg\nBT\n/F1 7.5 Tf\n"
                f"1 0 0 1 {ML:.2f} {MB - 22:.2f} Tm\n"
                f"({esc(self.footer or self.title)}) Tj\nET\n"
                f"BT\n/F1 7.5 Tf\n1 0 0 1 {PW - MR - 52:.2f} {MB - 22:.2f} Tm\n"
                f"({esc(f'page {i} of {n}')}) Tj\nET\n0 0 0 rg\n")
            pg.ops.append(
                f"0.8 0.8 0.8 RG\n0.5 w\n{ML:.2f} {MB - 12:.2f} m\n"
                f"{PW - MR:.2f} {MB - 12:.2f} l\nS\n0 0 0 RG\n")

    def save(self, path: str | Path) -> Path:
        if self._saved:
            raise RuntimeError("save() called twice; footers would double")
        self._saved = True
        self._decorate()
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        buf = bytearray()
        buf += b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
        offsets: dict[int, int] = {}

        def add(num: int, body: bytes) -> None:
            offsets[num] = len(buf)          # recorded live, never computed
            buf.extend(f"{num} 0 obj\n".encode("latin-1"))
            buf.extend(body)
            buf.extend(b"\nendobj\n")

        npages = len(self.pages)
        first_font = 3
        first_page = first_font + len(FONT_ORDER)
        page_obj = [first_page + 2 * i for i in range(npages)]
        cont_obj = [first_page + 1 + 2 * i for i in range(npages)]

        res = " ".join(f"/{k} {first_font + i} 0 R"
                       for i, k in enumerate(FONT_ORDER))
        kids = " ".join(f"{n} 0 R" for n in page_obj)

        add(1, b"<< /Type /Catalog /Pages 2 0 R >>")
        add(2, f"<< /Type /Pages /Kids [{kids}] /Count {npages} >>"
               .encode("latin-1"))
        for i, key in enumerate(FONT_ORDER):
            add(first_font + i,
                f"<< /Type /Font /Subtype /Type1 /BaseFont /{FONTS[key][0]} "
                f"/Encoding /WinAnsiEncoding >>".encode("latin-1"))

        for i, pg in enumerate(self.pages):
            add(page_obj[i],
                (f"<< /Type /Page /Parent 2 0 R "
                 f"/MediaBox [0 0 {PW:.2f} {PH:.2f}] "
                 f"/Resources << /Font << {res} >> >> "
                 f"/Contents {cont_obj[i]} 0 R >>").encode("latin-1"))
            stream = "".join(pg.ops).encode("latin-1", "replace")
            add(cont_obj[i],
                b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n"
                + stream + b"\nendstream")

        size = cont_obj[-1] + 1
        xref_at = len(buf)
        buf += f"xref\n0 {size}\n".encode("latin-1")
        buf += b"0000000000 65535 f \n"          # exactly 20 bytes
        for n in range(1, size):
            buf += f"{offsets.get(n, 0):010d} 00000 n \n".encode("latin-1")
        buf += (f"trailer\n<< /Size {size} /Root 1 0 R "
                f"/Info << /Title ({esc(self.title)}) "
                f"/Producer (NIDS2 stdlib pdf writer) >> >>\n"
                f"startxref\n{xref_at}\n%%EOF\n").encode("latin-1")

        path.write_bytes(bytes(buf))
        return path


# --------------------------------------------------------------------------
# Markdown subset -> PDF
# --------------------------------------------------------------------------
_TABLE_SEP = re.compile(r"^\s*\|?[\s:|-]+\|[\s:|-]*$")
_BLOCK_START = re.compile(
    r"^\s*(#{1,3}\s|[-*]\s|\d+[.)]\s|\||```|>|-{3,}|\\pagebreak)")


def render_markdown(md: str, title: str, out: str | Path,
                    footer: str = "") -> Path:
    pdf = PDF(title, footer or title)
    lines = md.replace("\r\n", "\n").split("\n")
    i, n = 0, len(lines)
    while i < n:
        ln = lines[i]
        s = ln.strip()

        if s == "\\pagebreak":
            pdf.new_page()
            i += 1
            continue
        if not s:
            pdf.space(4.0)
            i += 1
            continue
        if s.startswith("```"):
            i += 1
            blk: list[str] = []
            while i < n and not lines[i].strip().startswith("```"):
                blk.append(lines[i].rstrip("\n"))
                i += 1
            i += 1                     # closing fence (or EOF)
            pdf.code(blk)
            continue
        if re.fullmatch(r"-{3,}|\*{3,}|_{3,}", s):
            pdf.rule()
            i += 1
            continue
        m = re.match(r"^(#{1,3})\s+(.*)$", s)
        if m:
            pdf.heading(m.group(2).strip(), len(m.group(1)))
            i += 1
            continue
        if s.startswith(">"):
            blk = []
            while i < n and lines[i].strip().startswith(">"):
                blk.append(lines[i].strip().lstrip(">").strip())
                i += 1
            pdf.quote(" ".join(x for x in blk if x))
            continue
        if s.startswith("|") and i + 1 < n and _TABLE_SEP.match(lines[i + 1]):
            rows = [[c.strip() for c in s.strip().strip("|").split("|")]]
            i += 2
            while i < n and lines[i].strip().startswith("|"):
                rows.append([c.strip()
                             for c in lines[i].strip().strip("|").split("|")])
                i += 1
            pdf.table(rows)
            continue
        m = re.match(r"^[-*]\s+(.*)$", s)
        if m:
            txt, i = m.group(1), i + 1
            while (i < n and lines[i].startswith("  ") and lines[i].strip()
                   and not re.match(r"^\s*[-*]\s", lines[i])):
                txt += " " + lines[i].strip()
                i += 1
            pdf.bullet(txt)
            continue
        m = re.match(r"^(\d+)[.)]\s+(.*)$", s)
        if m:
            txt, marker, i = m.group(2), m.group(1) + ".", i + 1
            while i < n and lines[i].startswith("   ") and lines[i].strip():
                txt += " " + lines[i].strip()
                i += 1
            pdf.bullet(txt, marker=marker, indent=8.0)
            continue

        blk = [s]
        i += 1
        while i < n and lines[i].strip() and not _BLOCK_START.match(lines[i]):
            blk.append(lines[i].strip())
            i += 1
        pdf.para(" ".join(blk))

    return pdf.save(out)


def md_file_to_pdf(md_path: str | Path, pdf_path: str | Path,
                   title: str | None = None, footer: str = "") -> Path:
    md_path = Path(md_path)
    text = md_path.read_text(encoding="utf-8")
    t = title or md_path.stem.replace("_", " ").replace("-", " ").title()
    return render_markdown(text, t, pdf_path, footer)
