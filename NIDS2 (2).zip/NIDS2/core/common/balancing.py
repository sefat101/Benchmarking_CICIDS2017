"""Class-imbalance handling. ONE place, applied to ALL models identically.

Evaluation rule 5 again: whatever imbalance treatment is in force is in force
for every model, or the experiment measures the treatment and not the
architecture. So the *runner* picks a strategy and hands the resulting
weights/sampler to the shared training loop, which applies them the same way
to all ten models. No model chooses its own.

STRATEGIES
----------
none      : nothing. The 1156:1 imbalance stands.
inverse   : class weights proportional to 1/frequency, normalised to mean 1.
effective : Cui et al. class-balanced weights, (1-beta)/(1-beta^n). Softer
            than raw inverse; beta=0.9999 by default. CITED method.
sampler   : WeightedRandomSampler that draws classes evenly per batch.

WHICH TO USE FOR THE HEADLINE
-----------------------------
This is a decision to make ONCE and apply everywhere, not a knob to tune per
model on the test set (which is forbidden). Recommendation, labelled as
CONJECTURE until measured: 'effective' weights, because raw inverse weighting
at 1156:1 puts almost all gradient on Bot and destabilises the majority
classes, and the sampler variant changes the effective epoch length which
complicates the equal-training-budget comparison. Decide on validation.
"""
from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import WeightedRandomSampler

from core import config


def class_frequencies(y_train: np.ndarray) -> np.ndarray:
    return np.bincount(np.asarray(y_train), minlength=config.N_CLASSES).astype(np.float64)


def inverse_frequency_weights(y_train: np.ndarray) -> np.ndarray:
    n = class_frequencies(y_train)
    n[n == 0] = 1.0
    w = 1.0 / n
    return (w / w.mean()).astype(np.float32)


def effective_number_weights(y_train: np.ndarray, beta: float = 0.9999) -> np.ndarray:
    """Cui et al. 2019, class-balanced loss. CITED."""
    n = class_frequencies(y_train)
    eff = 1.0 - np.power(beta, n)
    eff[eff == 0] = 1.0
    w = (1.0 - beta) / eff
    return (w / w.mean()).astype(np.float32)


def make_sampler(y_train: np.ndarray, seed: int = 0) -> WeightedRandomSampler:
    w_class = inverse_frequency_weights(y_train)
    sample_w = w_class[np.asarray(y_train)]
    g = torch.Generator()
    g.manual_seed(seed)
    return WeightedRandomSampler(
        weights=torch.as_tensor(sample_w, dtype=torch.double),
        num_samples=len(y_train), replacement=True, generator=g)


def resolve_balancing(strategy: str, y_train: np.ndarray, seed: int = 0):
    """Return (class_weights, sampler). Exactly one is non-None, or neither."""
    if strategy == "none":
        return None, None
    if strategy == "inverse":
        return inverse_frequency_weights(y_train), None
    if strategy == "effective":
        return effective_number_weights(y_train), None
    if strategy == "sampler":
        return None, make_sampler(y_train, seed)
    raise ValueError(f"unknown balancing strategy {strategy!r}")
