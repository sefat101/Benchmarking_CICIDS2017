"""Shared machinery: config-driven preprocessing, the model contract, metrics."""
