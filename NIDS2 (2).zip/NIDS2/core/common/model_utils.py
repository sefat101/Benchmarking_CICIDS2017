"""The model contract, the registry, and the ONE shared training loop.

WHY THE TRAINING LOOP LIVES HERE AND NOT IN THE MODELS
------------------------------------------------------
Evaluation rule 5: any change applied to the proposal is applied identically
to all baselines, or the comparison measures the change and not the
architecture. A per-model train() method makes that rule unenforceable --
somebody eventually gives the proposal a longer schedule or a better
scheduler and the comparison silently dies.

So: models define *only* a forward pass. Optimiser, schedule, loss,
class weighting, early stopping, seeding and calibration are defined once,
here and in balancing.py / metrics.py, and are byte-identical for all ten
models. A model that "needs" a different learning rate does not get one.
Change it for everybody or not at all.

WHAT A MODEL MAY DECLARE
------------------------
INPUT_KIND  'flat'  -> (B, F)        dense vector, most models
            'seq'   -> (B, 1, F)     channel-first, for conv/recurrent models
            'group' -> (B, F) + group index map, for sigma/gated_mlp
AUX_LOSS_WEIGHT  float, default 0.0. Only the autoencoder uses a nonzero
            value; that is part of its definition as a baseline architecture,
            declared here in the open, not a training advantage handed to it.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

import json
import os
import random
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from core import config

# --------------------------------------------------------------------------
# Determinism
# --------------------------------------------------------------------------
def set_seed(seed: int, deterministic: bool = True) -> None:
    """Seed every RNG that can affect a run.

    NOTE (cited, not measured): cuDNN's deterministic mode can change kernel
    selection and therefore wall-clock time. It does not change the protocol.
    We prefer reproducibility over speed here because rule 4 requires the
    spread across seeds to mean something.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        # Some ops have no deterministic implementation; warn instead of dying.
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except Exception:
            pass


# --------------------------------------------------------------------------
# The contract
# --------------------------------------------------------------------------
class NIDSModel(nn.Module, ABC):
    """Base class for all ten models.

    Subclasses implement __init__(n_features, n_classes, group_idx, **shape)
    and forward(x) -> logits  (B, n_classes)
    or               (logits, {'name': aux_loss_tensor})

    Subclasses must NOT implement: training loops, optimisers, schedulers,
    loss functions, class weighting, or thresholding.
    """

    INPUT_KIND: str = "flat"
    AUX_LOSS_WEIGHT: float = 0.0
    #: Whether this architecture's reachable performance is invariant to column
    #: order, read by the permutation test (H1) to form its stated expectation
    #: via partition_by_permutation_claim. The test RETRAINS on permuted
    #: columns, so the question is whether the hypothesis space is closed under
    #: permutation, NOT whether one fixed parameter vector gives the same
    #: output. Those two readings disagree, so read the concrete definition:
    #: set True if, for any permutation pi, some parameter setting reproduces
    #: the original function on pi-permuted input. Under that reading a plain
    #: MLP is True (permute the first weight matrix) and a width-k convolution
    #: is False (a kernel cannot span an arbitrary permutation of the column
    #: axis). Overriding this to True without that argument is overclaiming:
    #: the flag decides which half of the printed expectation the model lands
    #: in, so it is the one place where a wrong value turns a falsification
    #: test into a restatement of the author's belief.
    CLAIMS_PERMUTATION_INVARIANCE: bool = False

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None, **shape: Any):
        super().__init__()
        self.n_features = int(n_features)
        self.n_classes = int(n_classes)
        self.group_idx = group_idx
        self.shape_cfg = dict(shape)

    @abstractmethod
    def forward(self, x: torch.Tensor):  # -> Tensor | tuple[Tensor, dict]
        ...

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def shape_input(self, x: torch.Tensor) -> torch.Tensor:
        """Adapt a (B, F) batch to what this model's forward expects."""
        if self.INPUT_KIND == "seq":
            return x.unsqueeze(1)          # (B, 1, F) channel-first
        return x                            # 'flat' and 'group' both take (B,F)


MODEL_REGISTRY: dict[str, type[NIDSModel]] = {}


def register_model(name: str) -> Callable[[type[NIDSModel]], type[NIDSModel]]:
    def deco(cls: type[NIDSModel]) -> type[NIDSModel]:
        if name in MODEL_REGISTRY:
            raise KeyError(f"model {name!r} already registered")
        if not issubclass(cls, NIDSModel):
            raise TypeError(f"{cls.__name__} must subclass NIDSModel")
        MODEL_REGISTRY[name] = cls
        cls.REGISTERED_NAME = name  # type: ignore[attr-defined]
        return cls
    return deco


def build_model(name: str, n_features: int, n_classes: int,
                group_idx: dict[str, list[int]] | None = None,
                **shape: Any) -> NIDSModel:
    import core.models  # noqa: F401  (populates the registry)
    if name not in MODEL_REGISTRY:
        raise KeyError(
            f"unknown model {name!r}. Registered: {sorted(MODEL_REGISTRY)}")
    return MODEL_REGISTRY[name](n_features, n_classes, group_idx, **shape)


def build_model_seeded(name: str, n_features: int, n_classes: int,
                       group_idx: dict[str, list[int]] | None = None,
                       *, seed: int, **shape: Any) -> NIDSModel:
    """Seed, THEN construct. Use this, not build_model, in the runner.

    train_model() seeds at entry, but by then the model object already
    exists, so its weight initialisation was drawn from whatever RNG state
    happened to be current. That makes init irreproducible and inflates the
    across-seed spread with a component that has nothing to do with the seed.
    Seeding immediately before construction is what makes the 5-seed std
    mean what rule 4 says it means.
    """
    set_seed(seed)
    return build_model(name, n_features, n_classes, group_idx, **shape)


def available_models() -> list[str]:
    import core.models  # noqa: F401
    return sorted(MODEL_REGISTRY)


def partition_by_permutation_claim(
        names: list[str] | None = None) -> tuple[list[str], list[str]]:
    """Split model names into (claims_invariance, does_not), both sorted.

    Derived from the registry rather than hardcoded at the call site, so that
    adding a model cannot leave it out of the H1 falsification test's stated
    expectation. A hand-written list would silently omit the new model and the
    reader would never see that it was missing -- the exact failure mode where
    an expectation gets narrated after the fact.
    """
    import core.models  # noqa: F401
    names = sorted(MODEL_REGISTRY) if names is None else sorted(names)
    claims, no_claim = [], []
    for n in names:
        if n not in MODEL_REGISTRY:
            raise KeyError(
                f"unknown model {n!r}. Registered: {sorted(MODEL_REGISTRY)}")
        cls = MODEL_REGISTRY[n]
        (claims if cls.CLAIMS_PERMUTATION_INVARIANCE else no_claim).append(n)
    return claims, no_claim


# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------
@dataclass
class TrainLog:
    """Everything needed to reconstruct what happened in one run."""
    model: str
    protocol: str
    seed: int
    n_params: int
    epochs_ran: int = 0
    best_epoch: int = -1
    best_val_metric: float = float("-inf")
    history: list[dict[str, float]] = field(default_factory=list)
    wall_seconds: float = 0.0
    peak_vram_mb: float = 0.0
    stopped_early: bool = False
    notes: list[str] = field(default_factory=list)

    def to_json(self, path: Path) -> None:
        path = config.assert_artefact_path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")


def _make_loader(X: np.ndarray, y: np.ndarray, batch_size: int,
                 shuffle: bool, sampler=None, seed: int = 0) -> DataLoader:
    ds = TensorDataset(torch.from_numpy(np.ascontiguousarray(X)).float(),
                       torch.from_numpy(np.ascontiguousarray(y)).long())
    g = torch.Generator()
    g.manual_seed(seed)
    # drop_last=True ONLY while training. Every model in this repo uses
    # BatchNorm1d, which raises in train mode on a batch of size 1, and a
    # training split whose size is congruent to 1 mod batch_size produces
    # exactly that. Dropping at most `batch_size - 1` rows of ~1.7M is
    # negligible and applies identically to all ten models. Evaluation
    # loaders keep every row (drop_last=False) -- no test flow is ever
    # silently discarded.
    return DataLoader(
        ds, batch_size=batch_size,
        shuffle=(shuffle and sampler is None),
        sampler=sampler,
        num_workers=0,          # Windows + CUDA: workers cost more than they save here
        pin_memory=torch.cuda.is_available(),
        drop_last=bool(shuffle or sampler is not None),
        generator=g,
    )


@torch.no_grad()
def predict_proba(model: NIDSModel, X: np.ndarray, device: torch.device,
                  batch_size: int = 4096) -> np.ndarray:
    """Softmax probabilities, (N, n_classes). No thresholding here."""
    model.eval()
    out = np.empty((len(X), model.n_classes), dtype=np.float32)
    for i in range(0, len(X), batch_size):
        xb = torch.from_numpy(
            np.ascontiguousarray(X[i:i + batch_size])).float().to(device)
        res = model(model.shape_input(xb))
        logits = res[0] if isinstance(res, tuple) else res
        out[i:i + batch_size] = torch.softmax(logits, dim=1).cpu().numpy()
    return out


def train_model(
    model: NIDSModel,
    X_train: np.ndarray, y_train: np.ndarray,
    X_val: np.ndarray, y_val: np.ndarray,
    *,
    seed: int,
    protocol: str,
    class_weights: np.ndarray | None = None,
    sampler=None,
    device: torch.device | None = None,
    train_cfg: dict | None = None,
    log: TrainLog | None = None,
    verbose: bool = True,
) -> tuple[NIDSModel, TrainLog]:
    """The single training loop. Identical for all ten models.

    class_weights / sampler come from common/balancing.py and are chosen by
    the *runner*, not by the model, so that whatever balancing is in force is
    in force for everybody (rule 5).

    Early stopping is on val macro-F1. Validation is the ONLY thing that
    touches model selection -- test is never seen here (rule 3).
    """
    from core.common.metrics import macro_f1_from_proba

    cfg = dict(config.SHARED_TRAIN)
    if train_cfg:
        # A caller may override, but the override is recorded in the log and
        # the runner applies the same override to every model in a sweep.
        cfg.update(train_cfg)

    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    set_seed(seed)
    model = model.to(device)

    log = log or TrainLog(model=getattr(model, "REGISTERED_NAME", type(model).__name__),
                          protocol=protocol, seed=seed, n_params=model.n_params())
    log.n_params = model.n_params()
    if train_cfg:
        log.notes.append(f"train_cfg override applied to ALL models: {train_cfg}")

    if class_weights is not None:
        w = torch.from_numpy(np.asarray(class_weights, dtype=np.float32)).to(device)
    else:
        w = None
    criterion = nn.CrossEntropyLoss(weight=w)

    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"],
                            weight_decay=cfg["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg["epochs"])

    loader = _make_loader(X_train, y_train, cfg["batch_size"],
                          shuffle=True, sampler=sampler, seed=seed)

    best_state: dict[str, torch.Tensor] | None = None
    patience = 0
    t0 = time.time()
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    for epoch in range(cfg["epochs"]):
        model.train()
        running, nb = 0.0, 0
        for xb, yb in loader:
            xb = xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            res = model(model.shape_input(xb))
            if isinstance(res, tuple):
                logits, aux = res
                loss = criterion(logits, yb)
                if aux and model.AUX_LOSS_WEIGHT:
                    loss = loss + model.AUX_LOSS_WEIGHT * sum(aux.values())
            else:
                loss = criterion(res, yb)
            loss.backward()
            if cfg["grad_clip"]:
                nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
            opt.step()
            running += float(loss.detach())
            nb += 1
        sched.step()

        val_proba = predict_proba(model, X_val, device)
        val_f1 = macro_f1_from_proba(y_val, val_proba)
        log.history.append({"epoch": epoch,
                            "train_loss": running / max(nb, 1),
                            "val_macro_f1": float(val_f1)})
        if verbose:
            print(f"  epoch {epoch:3d}  loss {running/max(nb,1):.4f}  "
                  f"val_macro_f1 {val_f1:.4f}")

        if val_f1 > log.best_val_metric:
            log.best_val_metric = float(val_f1)
            log.best_epoch = epoch
            best_state = {k: v.detach().cpu().clone()
                          for k, v in model.state_dict().items()}
            patience = 0
        else:
            patience += 1
            if patience >= cfg["early_stop_patience"]:
                log.stopped_early = True
                log.epochs_ran = epoch + 1
                break
    else:
        log.epochs_ran = cfg["epochs"]

    if best_state is not None:
        model.load_state_dict(best_state)
    log.wall_seconds = time.time() - t0
    if torch.cuda.is_available():
        log.peak_vram_mb = torch.cuda.max_memory_allocated() / 1024 ** 2
    return model, log
