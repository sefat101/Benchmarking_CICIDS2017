"""Metrics, and the threshold calibration that must never see test.

TWO DECISION RULES, DEPLOYED SIDE BY SIDE
-----------------------------------------
This repo reports two different things from one model, and conflating them
is the most common way to get a NIDS results table wrong:

1. CLOSED-SET CLASSIFICATION. argmax over the 10 softmax outputs.
   Gives macro-F1 and per-class recall. No threshold involved.

2. DETECTION AT AN OPERATING POINT. Collapse to binary via
       attack_score = 1 - P(BENIGN)
   and compare to a threshold t. Gives attack recall and FPR.
   t is chosen on VALIDATION so that pooled attack recall = 95%, then
   FROZEN and applied to test. FPR at that frozen t is the primary headline.

Reporting an FPR without saying which recall it was measured at is
meaningless, so `fpr_at_fixed_recall` always returns the realised test recall
alongside the FPR. If the realised recall drifts far from 0.95, the operating
point did not transfer and the FPR is not comparable -- the function flags it.

WHY POOLED ATTACK RECALL AND NOT PER-CLASS
------------------------------------------
At 1156:1 imbalance the pooled figure is dominated by DoS Hulk / PortScan /
DDoS, which together are ~90% of attack flows. A model can hit 95% pooled
recall while missing Bot almost entirely. That is precisely why rule 2 also
demands per-class recall for all 10 classes: the pooled number alone hides
the failure this thesis is about. Both are always returned together.

PROVENANCE: this module computes measured quantities from arrays handed to
it. The "~90%" above is CITED arithmetic from config.EXPECTED_CLASS_COUNTS,
not a measurement of any model.
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, asdict, field
from typing import Any

import numpy as np
from sklearn.metrics import f1_score, confusion_matrix

from core import config


class CalibrationError(RuntimeError):
    """Raised on any attempt to calibrate on something that is not validation."""


# --------------------------------------------------------------------------
# Closed-set metrics (argmax rule)
# --------------------------------------------------------------------------
def macro_f1_from_proba(y_true: np.ndarray, proba: np.ndarray) -> float:
    """Macro-F1 over all 10 classes under the argmax rule.

    labels=range(N_CLASSES) is passed explicitly so that a class absent from
    a fold contributes F1=0 rather than being silently dropped from the
    average. Dropping it would change the class set and make the number
    incomparable with other rows in the table.
    """
    y_pred = np.asarray(proba).argmax(axis=1)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # zero_division handled explicitly
        return float(f1_score(y_true, y_pred, average="macro",
                              labels=list(range(config.N_CLASSES)),
                              zero_division=0))


def per_class_recall(y_true: np.ndarray, proba: np.ndarray) -> dict[str, float]:
    """Recall for each of the 10 classes under the argmax rule.

    A class with zero support in y_true gets NaN, not 0.0 -- absent is not the
    same as failed, and a table must show the difference.
    """
    y_pred = np.asarray(proba).argmax(axis=1)
    cm = confusion_matrix(y_true, y_pred,
                          labels=list(range(config.N_CLASSES)))
    support = cm.sum(axis=1)
    out: dict[str, float] = {}
    for i, name in enumerate(config.CLASSES):
        out[name] = float(cm[i, i] / support[i]) if support[i] > 0 else float("nan")
    return out


def accuracy(y_true: np.ndarray, proba: np.ndarray) -> float:
    """Overall accuracy. Reported ONCE, to demonstrate it is uninformative.

    A constant-BENIGN predictor scores the BENIGN prevalence (~80.4% on the
    reduced 10-class set). Any accuracy near that number is evidence of
    nothing.
    """
    return float((np.asarray(proba).argmax(axis=1) == np.asarray(y_true)).mean())


def benign_prevalence(y_true: np.ndarray) -> float:
    """The score a do-nothing predictor achieves. Context for accuracy."""
    return float((np.asarray(y_true) == config.BENIGN_IDX).mean())


# --------------------------------------------------------------------------
# Detection metrics (threshold rule)
# --------------------------------------------------------------------------
def attack_score(proba: np.ndarray) -> np.ndarray:
    """1 - P(BENIGN). Higher means more attack-like."""
    return 1.0 - np.asarray(proba)[:, config.BENIGN_IDX]


def calibrate_threshold(y_val: np.ndarray, proba_val: np.ndarray,
                        target_recall: float | None = None,
                        *, split_name: str = "val") -> dict[str, float]:
    """Choose the threshold on VALIDATION. Never on test.

    `split_name` must be 'val'. It exists so that a caller who passes test
    data gets a loud error instead of a publishable-looking number. This is
    a hard guard for evaluation rule 3.

    Returns the threshold and the validation-side recall/FPR it produces.
    """
    if split_name != "val":
        raise CalibrationError(
            f"calibrate_threshold called with split_name={split_name!r}. "
            "Thresholds are calibrated on validation ONLY. Calibrating on "
            "test invalidates every number downstream of it.")

    target = target_recall if target_recall is not None else config.TARGET_ATTACK_RECALL
    y_val = np.asarray(y_val)
    s = attack_score(proba_val)
    atk = s[y_val != config.BENIGN_IDX]
    ben = s[y_val == config.BENIGN_IDX]
    if len(atk) == 0:
        raise CalibrationError("no attack flows in validation; cannot "
                               "calibrate an attack-recall operating point")

    # Smallest threshold achieving >= target recall: the (1-target) quantile
    # of attack scores. Using 'lower' interpolation keeps recall >= target.
    t = float(np.quantile(atk, 1.0 - target, method="lower"))
    realised_recall = float((atk >= t).mean())
    realised_fpr = float((ben >= t).mean()) if len(ben) else float("nan")
    return {"threshold": t,
            "val_attack_recall": realised_recall,
            "val_fpr": realised_fpr,
            "target_recall": float(target)}


def fpr_at_threshold(y_true: np.ndarray, proba: np.ndarray,
                     threshold: float) -> dict[str, float]:
    """Apply a FROZEN threshold. This is what runs on test.

    Returns FPR, the realised attack recall, and a transfer flag. If realised
    recall on test deviates from the target by more than 2 percentage points,
    `operating_point_transferred` is False and the FPR should not be compared
    across models without saying so -- they are then sitting at different
    points on their own curves.
    """
    y_true = np.asarray(y_true)
    s = attack_score(proba)
    atk = s[y_true != config.BENIGN_IDX]
    ben = s[y_true == config.BENIGN_IDX]
    recall = float((atk >= threshold).mean()) if len(atk) else float("nan")
    fpr = float((ben >= threshold).mean()) if len(ben) else float("nan")
    n_fp = int((ben >= threshold).sum()) if len(ben) else 0
    transferred = (not np.isnan(recall)
                   and abs(recall - config.TARGET_ATTACK_RECALL) <= 0.02)
    return {"fpr": fpr,
            "attack_recall": recall,
            "n_false_positives": n_fp,
            "n_benign": int(len(ben)),
            "threshold": float(threshold),
            "operating_point_transferred": bool(transferred)}


def per_class_recall_at_threshold(y_true: np.ndarray, proba: np.ndarray,
                                  threshold: float) -> dict[str, float]:
    """Per-class DETECTION recall at the frozen threshold.

    Distinct from per_class_recall (argmax): here a Bot flow counts as
    detected if its attack score clears the threshold, regardless of which
    attack class it was assigned. This is the operationally honest view --
    an analyst alerted to the right flow with the wrong label still caught it.
    """
    y_true = np.asarray(y_true)
    s = attack_score(proba)
    out: dict[str, float] = {}
    for i, name in enumerate(config.CLASSES):
        m = y_true == i
        if not m.any():
            out[name] = float("nan")
        elif i == config.BENIGN_IDX:
            out[name] = float((s[m] < threshold).mean())  # correctly not alerted
        else:
            out[name] = float((s[m] >= threshold).mean())
    return out


# --------------------------------------------------------------------------
# One bundle, so no reporting path can pick and choose
# --------------------------------------------------------------------------
@dataclass
class EvalResult:
    model: str
    protocol: str
    seed: int
    is_claim_surface: bool
    # primary
    fpr_at_target_recall: float
    attack_recall_realised: float
    operating_point_transferred: bool
    # secondary
    macro_f1: float
    per_class_recall_argmax: dict[str, float]
    per_class_recall_threshold: dict[str, float]
    # context
    accuracy: float
    benign_prevalence: float
    threshold: float
    val_calibration: dict[str, float]
    n_test: int
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def save(self, path) -> None:
        """Write this result as JSON. Mirrors DataAudit/SplitManifest/TrainLog.

        The single most important artefact in the repo should not depend on
        each caller remembering to serialise it correctly.
        """
        import json
        from pathlib import Path
        p = config.assert_artefact_path(Path(path))
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")


def evaluate(model_name: str, protocol: str, seed: int, is_claim_surface: bool,
             y_val: np.ndarray, proba_val: np.ndarray,
             y_test: np.ndarray, proba_test: np.ndarray) -> EvalResult:
    """Full evaluation. Calibrate on val, freeze, apply to test.

    Every headline number required by the evaluation rules comes out of this
    one function, so no reporting script can quietly omit the inconvenient
    half.

    `is_claim_surface` is CROSS-CHECKED against config, not trusted. A caller
    that mislabels a random-split run as a claim surface gets an exception
    rather than a publishable-looking row.
    """
    expected_claim = (protocol == config.CLAIM_SURFACE)
    if bool(is_claim_surface) != expected_claim:
        raise ValueError(
            f"is_claim_surface={is_claim_surface} contradicts config for "
            f"protocol {protocol!r} (config.CLAIM_SURFACE="
            f"{config.CLAIM_SURFACE!r}, so expected {expected_claim}). "
            "Refusing to label this run. If the claim surface is genuinely "
            "changing, change it in config.py once, deliberately, and rerun "
            "everything -- not per call site.")

    cal = calibrate_threshold(y_val, proba_val, split_name="val")
    t = cal["threshold"]
    det = fpr_at_threshold(y_test, proba_test, t)

    w: list[str] = []
    if not det["operating_point_transferred"]:
        w.append(
            f"operating point did not transfer: target recall "
            f"{config.TARGET_ATTACK_RECALL:.2f}, realised on test "
            f"{det['attack_recall']:.4f}. FPR is not directly comparable "
            "across models at this point without stating the realised recall.")
    if not is_claim_surface:
        w.append(
            f"protocol {protocol!r} is NOT a claim surface. These numbers are "
            "a saturated reference. No improvement claim may be made from "
            "them.")

    pcr = per_class_recall(y_test, proba_test)
    absent = [k for k, v in pcr.items() if np.isnan(v)]
    if absent:
        w.append(f"classes absent from test fold: {absent}. Their recall is "
                 "NaN (absent), not 0 (failed).")

    return EvalResult(
        model=model_name, protocol=protocol, seed=seed,
        is_claim_surface=is_claim_surface,
        fpr_at_target_recall=det["fpr"],
        attack_recall_realised=det["attack_recall"],
        operating_point_transferred=det["operating_point_transferred"],
        macro_f1=macro_f1_from_proba(y_test, proba_test),
        per_class_recall_argmax=pcr,
        per_class_recall_threshold=per_class_recall_at_threshold(
            y_test, proba_test, t),
        accuracy=accuracy(y_test, proba_test),
        benign_prevalence=benign_prevalence(y_test),
        threshold=t, val_calibration=cal, n_test=int(len(y_test)),
        warnings=w,
    )


# --------------------------------------------------------------------------
# Aggregation across seeds. Rule 4: never a mean without its spread.
# --------------------------------------------------------------------------
def mean_std(values: list[float]) -> tuple[float, float, int]:
    """Mean, sample std (ddof=1), n. NaNs excluded and counted out."""
    a = np.asarray([v for v in values if not (isinstance(v, float) and np.isnan(v))],
                   dtype=float)
    if len(a) == 0:
        return float("nan"), float("nan"), 0
    if len(a) == 1:
        return float(a[0]), float("nan"), 1
    return float(a.mean()), float(a.std(ddof=1)), int(len(a))


def format_mean_std(values: list[float], fmt: str = ".4f",
                    expected_n: int | None = None) -> str:
    """Render 'mean +/- std (n)'. Refuses to render a bare mean.

    If fewer seeds are present than expected, the string says so rather than
    quietly averaging what survived -- dropping a seed that hurt the headline
    is explicitly forbidden, and silence is how it happens.
    """
    m, s, n = mean_std(values)
    exp = expected_n if expected_n is not None else len(config.SEEDS)
    if n == 0:
        return "n/a (0 seeds)"
    if n == 1:
        return f"{m:{fmt}} +/- n/a (1 seed -- SPREAD UNKNOWN, NOT REPORTABLE)"
    base = f"{m:{fmt}} +/- {s:{fmt}}"
    if n < exp:
        base += f"  [WARNING: {n}/{exp} seeds present]"
    return base


def separated_by_more_than_one_std(a: list[float], b: list[float]) -> bool:
    """Rule 4: no ordering claimed inside one standard deviation.

    True only if |mean_a - mean_b| exceeds the larger of the two stds. Used by
    the aggregator to decide whether it is allowed to print a ranking arrow.
    """
    ma, sa, na = mean_std(a)
    mb, sb, nb = mean_std(b)
    if na < 2 or nb < 2:
        return False
    return abs(ma - mb) > max(sa, sb)
