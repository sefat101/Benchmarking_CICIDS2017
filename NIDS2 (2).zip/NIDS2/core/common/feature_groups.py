"""Semantic partition of the CICFlowMeter feature set.

WHY THIS MODULE EXISTS
----------------------
The 78 columns of the MachineLearningCVE CSVs are in an arbitrary order that
reflects CICFlowMeter's output code, not any property of network traffic.
Adjacent columns are frequently unrelated (e.g. 'Bwd IAT Min' sits next to
'Fwd PSH Flags'). Any model that applies a 1-D convolution along the column
axis is therefore assuming a locality that the data does not have. That is a
CONJECTURE about why cnn1d / cnn_rnn / cnn_lstm / cnn_gru behave as they do,
and protocol.py ships a pre-registered falsification test for it
(column-permutation sensitivity). It is not a result.

THE PARTITION
-------------
11 disjoint groups covering all 77 unique features. 'Fwd Header Length.1' is
a byte-identical duplicate of 'Fwd Header Length' in the released CSVs and is
excluded from the partition (and dropped in preprocessing) -- so the nominal
78 columns are 77 unique features plus one copy.

The partition is asserted disjoint and exhaustive at import time.
"""
from __future__ import annotations

import re

# --------------------------------------------------------------------------
# Column-name normalisation. The released CSVs have leading spaces on most
# headers (' Flow Duration'), inconsistent internal spacing, and mixed case.
# Everything is matched on the normalised form.
# --------------------------------------------------------------------------
def normalise_col(name: str) -> str:
    """Lowercase, collapse whitespace, unify separators. Order-preserving."""
    s = str(name).replace("﻿", "").strip().lower()
    s = s.replace("\\", "/")
    s = re.sub(r"\s+", " ", s)
    s = s.replace("_", " ")
    return s


# The duplicated column, by normalised name.
DUPLICATE_COLUMN = normalise_col("Fwd Header Length.1")

# --------------------------------------------------------------------------
# Groups, given in human-readable form; normalised below.
# --------------------------------------------------------------------------
_RAW_GROUPS: dict[str, tuple[str, ...]] = {
    # Endpoint / connection configuration. Destination Port is CATEGORICAL
    # in nature but shipped as an integer; preprocessing.py handles it
    # separately and records the choice.
    "endpoint": (
        "Destination Port",
        "Init_Win_bytes_forward",
        "Init_Win_bytes_backward",
        "min_seg_size_forward",
    ),
    # How much was transferred.
    "volume": (
        "Total Fwd Packets",
        "Total Backward Packets",
        "Total Length of Fwd Packets",
        "Total Length of Bwd Packets",
        "Subflow Fwd Packets",
        "Subflow Fwd Bytes",
        "Subflow Bwd Packets",
        "Subflow Bwd Bytes",
        "act_data_pkt_fwd",
    ),
    # How fast, and how long.
    "rate": (
        "Flow Duration",
        "Flow Bytes/s",
        "Flow Packets/s",
        "Fwd Packets/s",
        "Bwd Packets/s",
        "Down/Up Ratio",
    ),
    # Forward packet size distribution.
    "size_fwd": (
        "Fwd Packet Length Max",
        "Fwd Packet Length Min",
        "Fwd Packet Length Mean",
        "Fwd Packet Length Std",
        "Avg Fwd Segment Size",
    ),
    # Backward packet size distribution.
    "size_bwd": (
        "Bwd Packet Length Max",
        "Bwd Packet Length Min",
        "Bwd Packet Length Mean",
        "Bwd Packet Length Std",
        "Avg Bwd Segment Size",
    ),
    # Direction-agnostic packet size distribution.
    "size_agg": (
        "Min Packet Length",
        "Max Packet Length",
        "Packet Length Mean",
        "Packet Length Std",
        "Packet Length Variance",
        "Average Packet Size",
    ),
    # Inter-arrival timing.
    "iat": (
        "Flow IAT Mean",
        "Flow IAT Std",
        "Flow IAT Max",
        "Flow IAT Min",
        "Fwd IAT Total",
        "Fwd IAT Mean",
        "Fwd IAT Std",
        "Fwd IAT Max",
        "Fwd IAT Min",
        "Bwd IAT Total",
        "Bwd IAT Mean",
        "Bwd IAT Std",
        "Bwd IAT Max",
        "Bwd IAT Min",
    ),
    # Burst structure over the flow lifetime. Expected to matter for the
    # slow-rate DoS classes (slowloris, Slowhttptest) -- CONJECTURE, tested
    # by the per-group ablation in proposal_sigma/, not asserted here.
    "idle_active": (
        "Active Mean",
        "Active Std",
        "Active Max",
        "Active Min",
        "Idle Mean",
        "Idle Std",
        "Idle Max",
        "Idle Min",
    ),
    # TCP flags. Several of these are constant-zero in the released data;
    # preprocessing.py audits and reports rather than assuming.
    "flags": (
        "Fwd PSH Flags",
        "Bwd PSH Flags",
        "Fwd URG Flags",
        "Bwd URG Flags",
        "FIN Flag Count",
        "SYN Flag Count",
        "RST Flag Count",
        "PSH Flag Count",
        "ACK Flag Count",
        "URG Flag Count",
        "CWE Flag Count",
        "ECE Flag Count",
    ),
    "header": (
        "Fwd Header Length",
        "Bwd Header Length",
    ),
    # Bulk-transfer features. Known to be constant-zero across the whole
    # release (a CICFlowMeter defect, not a property of the traffic).
    # Audited, not assumed.
    "bulk": (
        "Fwd Avg Bytes/Bulk",
        "Fwd Avg Packets/Bulk",
        "Fwd Avg Bulk Rate",
        "Bwd Avg Bytes/Bulk",
        "Bwd Avg Packets/Bulk",
        "Bwd Avg Bulk Rate",
    ),
}

GROUP_NAMES: tuple[str, ...] = tuple(_RAW_GROUPS.keys())
N_GROUPS = len(GROUP_NAMES)

# Normalised partition.
GROUPS: dict[str, tuple[str, ...]] = {
    g: tuple(normalise_col(c) for c in cols) for g, cols in _RAW_GROUPS.items()
}

ALL_FEATURES: tuple[str, ...] = tuple(c for g in GROUP_NAMES for c in GROUPS[g])
N_UNIQUE_FEATURES = len(ALL_FEATURES)

# ---- integrity of the partition, checked at import ----------------------
_seen: dict[str, str] = {}
for _g, _cols in GROUPS.items():
    for _c in _cols:
        if _c in _seen:
            raise AssertionError(
                f"feature {_c!r} appears in both {_seen[_c]!r} and {_g!r}; "
                "the partition must be disjoint")
        _seen[_c] = _g
if N_UNIQUE_FEATURES != 77:
    raise AssertionError(
        f"partition covers {N_UNIQUE_FEATURES} features, expected 77 "
        "(78 released columns minus the duplicated 'Fwd Header Length.1')")
del _seen, _g, _cols, _c

FEATURE_TO_GROUP: dict[str, str] = {
    c: g for g, cols in GROUPS.items() for c in cols
}


def group_index_map(feature_order: list[str]) -> dict[str, list[int]]:
    """Map group name -> positional indices into `feature_order`.

    `feature_order` is the *actual* column order of the matrix handed to the
    model, after preprocessing has dropped whatever the audit found
    degenerate. Groups that lost all their members come back as empty lists;
    callers must handle that (sigma drops the group and records it).
    """
    norm = [normalise_col(c) for c in feature_order]
    pos: dict[str, list[int]] = {g: [] for g in GROUP_NAMES}
    unknown: list[str] = []
    for i, c in enumerate(norm):
        g = FEATURE_TO_GROUP.get(c)
        if g is None:
            unknown.append(c)
        else:
            pos[g].append(i)
    if unknown:
        raise KeyError(
            "columns not present in the semantic partition: "
            f"{unknown}\nEither the archive differs from MachineLearningCVE "
            "or feature_groups.py needs updating. Do not silently ignore.")
    return pos


def describe_partition() -> str:
    """Human-readable table for the method section."""
    lines = [f"{'group':<12} {'n':>3}  features", "-" * 72]
    for g in GROUP_NAMES:
        cols = GROUPS[g]
        lines.append(f"{g:<12} {len(cols):>3}  {', '.join(cols[:3])}"
                     + (" ..." if len(cols) > 3 else ""))
    lines.append("-" * 72)
    lines.append(f"{'TOTAL':<12} {N_UNIQUE_FEATURES:>3}  "
                 f"(+1 duplicate column dropped: {DUPLICATE_COLUMN})")
    return "\n".join(lines)


if __name__ == "__main__":
    print(describe_partition())
