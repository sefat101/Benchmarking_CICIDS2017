"""Split protocols: the saturated random reference, and the claim surface.

THE PROBLEM THIS MODULE SOLVES
------------------------------
CICIDS2017 attacks are scripted bursts. A DoS Hulk run emits tens of
thousands of flows in minutes, and consecutive flows inside one burst are
near-identical in feature space. Under a stratified random split those
near-duplicates are dealt into train and test simultaneously. The model is
then evaluated on rows it has effectively already seen, and the score
saturates near 0.99 macro-F1. That number is a memorisation check, not a
generalisation estimate. It is the reference protocol, and no claim lives
there.

THE GROUPED PROTOCOL
--------------------
Group key = EPISODE. An episode is a maximal run of flows that share
(label, src_ip, dst_ip) and are separated by no more than EPISODE_GAP_SECONDS,
capped at EPISODE_MAX_SECONDS so a single long DoS run does not become one
indivisible group. Benign flows are grouped into contiguous
BENIGN_BLOCK_MINUTES time blocks per capture day. Episodes are atomic: every
flow in an episode lands in exactly one of train/val/test.

Assignment is TEMPORAL within each class: the earliest episodes of a class go
to train, the next to val, the latest to test. This kills two birds --
no burst straddles a split, and the model is never trained on traffic that
postdates its test traffic.

WHY NOT THE OBVIOUS ALTERNATIVES
--------------------------------
Day holdout (train Mon-Wed, test Thu-Fri): PortScan, DDoS and Bot occur only
on Friday and the DoS family only on Wednesday. Most of the 10 classes would
have zero training flows. Rejected -- it does not produce a 10-class problem.

Attacker-host holdout: CICIDS2017 uses a very small number of attacker hosts.
Holding one out typically removes an entire class from training. Implemented
below as `host_holdout` for use as a SECONDARY diagnostic only; it is not the
headline protocol because it silently changes the class set, and comparing
macro-F1 across different class sets is forbidden.

REQUIREMENT
-----------
The grouped protocol needs Timestamp and IP columns. The MachineLearningCVE
distribution has them stripped. get_data.py therefore fetches
GeneratedLabelledFlows as well and preprocessing.py joins the keys back on.
If you only have MachineLearningCVE, build_grouped_split raises -- it does
not silently fall back to random. A silent fallback would put the claim on
the saturated protocol, which is the exact failure this file exists to
prevent.

PROVENANCE: this module computes splits, not results. The 0.99 figure quoted
above is CITED from the user's own stated reference value, not measured here.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import pandas as pd

from core import config


class ProtocolError(RuntimeError):
    """Raised when a split cannot be built honestly."""


@dataclass
class SplitManifest:
    """Auditable record of how a split was produced."""
    protocol: str
    seed: int
    n_total: int
    n_train: int
    n_val: int
    n_test: int
    n_groups: int | None
    group_key: str | None
    class_counts: dict[str, dict[str, int]]
    is_claim_surface: bool
    warnings: list[str]
    data_fingerprint: str

    def save(self, path: Path) -> None:
        path = config.assert_artefact_path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")


def _fingerprint(y: np.ndarray) -> str:
    h = hashlib.sha256()
    h.update(np.asarray(y, dtype=np.int64).tobytes())
    return h.hexdigest()[:16]


def _class_counts(y: np.ndarray, idx: dict[str, np.ndarray]) -> dict:
    out: dict[str, dict[str, int]] = {}
    for split, ids in idx.items():
        counts = np.bincount(y[ids], minlength=config.N_CLASSES)
        out[split] = {config.CLASSES[i]: int(counts[i])
                      for i in range(config.N_CLASSES)}
    return out


def _check_all_classes_present(y: np.ndarray, idx: dict[str, np.ndarray],
                               warnings: list[str]) -> None:
    """Rule: all 10 classes reported. A split that empties a class in train
    or test makes per-class recall undefined and must be surfaced loudly."""
    for split, ids in idx.items():
        present = np.bincount(y[ids], minlength=config.N_CLASSES)
        missing = [config.CLASSES[i] for i in range(config.N_CLASSES)
                   if present[i] == 0]
        if missing:
            warnings.append(
                f"CLASS ABSENT from {split}: {missing}. Per-class recall is "
                "undefined for these. This split is NOT reportable as a "
                "10-class result.")


# --------------------------------------------------------------------------
# Protocol 1: stratified random. Saturated reference. NOT a claim surface.
# --------------------------------------------------------------------------
def build_random_split(y: np.ndarray, seed: int,
                       fractions: dict[str, float] | None = None
                       ) -> tuple[dict[str, np.ndarray], SplitManifest]:
    """Stratified random split over individual flows.

    Reported side by side with the grouped split (rule 1). The aggregator
    refuses to compute an improvement delta on this protocol.
    """
    fr = fractions or config.SPLIT_FRACTIONS
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    tr, va, te = [], [], []
    for c in range(config.N_CLASSES):
        ids = np.flatnonzero(y == c)
        rng.shuffle(ids)
        n = len(ids)
        n_tr = int(round(fr["train"] * n))
        n_va = int(round(fr["val"] * n))
        tr.append(ids[:n_tr])
        va.append(ids[n_tr:n_tr + n_va])
        te.append(ids[n_tr + n_va:])
    idx = {"train": np.sort(np.concatenate(tr)),
           "val": np.sort(np.concatenate(va)),
           "test": np.sort(np.concatenate(te))}

    warnings = ["Stratified random split over individual flows. Burst-level "
                "near-duplicates are expected to appear in train and test "
                "simultaneously. This protocol is a SATURATED REFERENCE. "
                "No improvement claim may be made on it."]
    _check_all_classes_present(y, idx, warnings)
    man = SplitManifest(
        protocol="random", seed=seed, n_total=len(y),
        n_train=len(idx["train"]), n_val=len(idx["val"]), n_test=len(idx["test"]),
        n_groups=None, group_key=None, class_counts=_class_counts(y, idx),
        is_claim_surface=False, warnings=warnings,
        data_fingerprint=_fingerprint(y))
    return idx, man


# --------------------------------------------------------------------------
# Episode construction
# --------------------------------------------------------------------------
def build_episodes(meta: pd.DataFrame,
                   gap_seconds: int | None = None,
                   max_seconds: int | None = None,
                   benign_block_minutes: int | None = None) -> np.ndarray:
    """Assign every flow an integer episode id.

    `meta` must have columns: timestamp (datetime64), src_ip, dst_ip, label_idx.

    Attack flows: grouped by (label, src_ip, dst_ip), cut whenever the gap to
    the previous flow exceeds `gap_seconds` or the episode has run longer than
    `max_seconds`.
    Benign flows: grouped by calendar time block of `benign_block_minutes`,
    because benign traffic has no attacker identity to key on and the
    correlation we need to break is temporal.
    """
    gap = gap_seconds if gap_seconds is not None else config.EPISODE_GAP_SECONDS
    cap = max_seconds if max_seconds is not None else config.EPISODE_MAX_SECONDS
    blk = (benign_block_minutes if benign_block_minutes is not None
           else config.BENIGN_BLOCK_MINUTES)

    required = {"timestamp", "src_ip", "dst_ip", "label_idx"}
    missing = required - set(meta.columns)
    if missing:
        raise ProtocolError(
            f"cannot build episodes, missing columns: {sorted(missing)}.\n"
            "The grouped protocol requires Timestamp and IP fields, which the "
            "MachineLearningCVE CSVs do not carry. Run "
            "`python -m core.tools.get_data --which both` and rebuild.")
    if meta["timestamp"].isna().any():
        raise ProtocolError(
            "NaT in timestamp column; cannot order episodes. Inspect the "
            "timestamp parsing in preprocessing.py before continuing.")

    ep = np.full(len(meta), -1, dtype=np.int64)
    next_id = 0

    benign_mask = (meta["label_idx"] == config.BENIGN_IDX).to_numpy()

    # --- benign: contiguous wall-clock blocks ---------------------------
    if benign_mask.any():
        ts = meta.loc[benign_mask, "timestamp"]
        block = ts.dt.floor(f"{blk}min")
        codes, _ = pd.factorize(block, sort=True)
        ep[benign_mask] = codes + next_id
        next_id += int(codes.max()) + 1 if len(codes) else 0

    # --- attacks: per (label, src, dst), cut on gap or duration ---------
    atk_pos = np.flatnonzero(~benign_mask)
    if len(atk_pos):
        sub = meta.iloc[atk_pos][["timestamp", "src_ip", "dst_ip", "label_idx"]]
        order = np.lexsort((sub["timestamp"].to_numpy(),
                            sub["dst_ip"].to_numpy(),
                            sub["src_ip"].to_numpy(),
                            sub["label_idx"].to_numpy()))
        sorted_pos = atk_pos[order]
        s = sub.iloc[order]
        t = s["timestamp"].astype("int64").to_numpy() / 1e9  # seconds
        key = list(zip(s["label_idx"].to_numpy(),
                       s["src_ip"].to_numpy(), s["dst_ip"].to_numpy()))

        cur = next_id
        start_t = t[0] if len(t) else 0.0
        ep[sorted_pos[0]] = cur
        for i in range(1, len(sorted_pos)):
            new_key = key[i] != key[i - 1]
            gapped = (t[i] - t[i - 1]) > gap
            too_long = (t[i] - start_t) > cap
            if new_key or gapped or too_long:
                cur += 1
                start_t = t[i]
            ep[sorted_pos[i]] = cur
        next_id = cur + 1

    if (ep < 0).any():
        raise ProtocolError("internal error: some flows were not assigned an "
                            "episode id")
    return ep


# --------------------------------------------------------------------------
# Protocol 2: grouped. THE CLAIM SURFACE.
# --------------------------------------------------------------------------
def build_grouped_split(y: np.ndarray, meta: pd.DataFrame, seed: int,
                        fractions: dict[str, float] | None = None,
                        assign: str = "temporal"
                        ) -> tuple[dict[str, np.ndarray], SplitManifest]:
    """Leakage-free split on episode groups.

    assign='temporal' : earliest episodes -> train, latest -> test (default,
                        and what should be reported).
    assign='random'   : episodes shuffled with `seed`. Use only to check how
                        much of the grouped-vs-random gap is due to grouping
                        itself rather than to the temporal ordering.

    Note on seeds: under assign='temporal' the split is DETERMINISTIC and does
    not depend on `seed`. That is correct and intended -- across the 5 seeds
    the data split is held fixed and only model initialisation and batch order
    vary, so the reported std is model variance, not split variance. The seed
    is recorded in the manifest regardless.
    """
    fr = fractions or config.SPLIT_FRACTIONS
    y = np.asarray(y)
    warnings: list[str] = []

    episodes = build_episodes(meta)
    n_groups = int(len(np.unique(episodes)))

    # Episode -> (its class, its start time). Episodes are single-class by
    # construction for attacks; for benign blocks they are all BENIGN.
    df = pd.DataFrame({"ep": episodes, "y": y,
                       "t": meta["timestamp"].astype("int64").to_numpy()})
    agg = df.groupby("ep").agg(y=("y", "first"), t=("t", "min"),
                               n=("y", "size"),
                               nuniq=("y", "nunique"))
    if (agg["nuniq"] > 1).any():
        bad = int((agg["nuniq"] > 1).sum())
        warnings.append(
            f"{bad} episodes contain more than one class. Episode class is "
            "taken as the first flow's label. Inspect if this count is large.")

    idx_parts: dict[str, list[np.ndarray]] = {"train": [], "val": [], "test": []}
    rng = np.random.default_rng(seed)

    for c in range(config.N_CLASSES):
        eps_c = agg[agg["y"] == c]
        if len(eps_c) == 0:
            warnings.append(f"class {config.CLASSES[c]} has no episodes at all")
            continue
        if len(eps_c) < 3:
            warnings.append(
                f"class {config.CLASSES[c]} has only {len(eps_c)} episode(s); "
                "it cannot be represented in all three splits. This class is "
                "not reportable under the grouped protocol -- report it as "
                "such rather than deleting it.")
        if assign == "temporal":
            ordered = eps_c.sort_values("t").index.to_numpy()
        elif assign == "random":
            ordered = eps_c.index.to_numpy().copy()
            rng.shuffle(ordered)
        else:
            raise ValueError(f"unknown assign={assign!r}")

        # Split on cumulative FLOW count, not episode count, so the flow-level
        # proportions land near the requested fractions even though episode
        # sizes are wildly unequal.
        sizes = eps_c.loc[ordered, "n"].to_numpy()
        cum = np.cumsum(sizes) / sizes.sum()
        i_tr = int(np.searchsorted(cum, fr["train"]) + 1)
        i_va = int(np.searchsorted(cum, fr["train"] + fr["val"]) + 1)
        i_tr = min(i_tr, len(ordered))
        i_va = min(max(i_va, i_tr), len(ordered))
        # Guarantee test is non-empty when there are >=2 episodes.
        if i_va >= len(ordered) and len(ordered) >= 2:
            i_va = len(ordered) - 1
            i_tr = min(i_tr, i_va)

        chosen = {"train": ordered[:i_tr],
                  "val": ordered[i_tr:i_va],
                  "test": ordered[i_va:]}
        for split, eps in chosen.items():
            if len(eps):
                idx_parts[split].append(np.flatnonzero(np.isin(episodes, eps)))

    idx = {k: (np.sort(np.concatenate(v)) if v else np.array([], dtype=np.int64))
           for k, v in idx_parts.items()}

    # --- leakage assertion: no episode may span two splits ---------------
    for a in ("train", "val", "test"):
        for b in ("train", "val", "test"):
            if a >= b:
                continue
            overlap = np.intersect1d(np.unique(episodes[idx[a]]),
                                     np.unique(episodes[idx[b]]))
            if len(overlap):
                raise ProtocolError(
                    f"LEAKAGE: {len(overlap)} episode(s) appear in both {a} "
                    f"and {b}. The grouped split is invalid. Do not report.")

    _check_all_classes_present(y, idx, warnings)
    man = SplitManifest(
        protocol="grouped", seed=seed, n_total=len(y),
        n_train=len(idx["train"]), n_val=len(idx["val"]), n_test=len(idx["test"]),
        n_groups=n_groups, group_key="episode(label,src,dst,gap,cap)/benign-block",
        class_counts=_class_counts(y, idx), is_claim_surface=True,
        warnings=warnings, data_fingerprint=_fingerprint(y))
    return idx, man


# --------------------------------------------------------------------------
# Secondary diagnostic: host holdout. NOT a headline protocol.
# --------------------------------------------------------------------------
def build_host_holdout_split(y: np.ndarray, meta: pd.DataFrame, seed: int
                             ) -> tuple[dict[str, np.ndarray], SplitManifest]:
    """Hold out whole attacker hosts. Diagnostic only.

    This routinely empties entire classes from train. That is a real finding
    about the dataset (too few attacker hosts to test host generalisation),
    not a protocol to report macro-F1 on -- doing so would compare macro-F1
    across different class sets, which is forbidden.
    """
    rng = np.random.default_rng(seed)
    hosts = meta["src_ip"].to_numpy()
    uniq = np.unique(hosts)
    rng.shuffle(uniq)
    n = len(uniq)
    tr_h = set(uniq[:int(0.6 * n)])
    va_h = set(uniq[int(0.6 * n):int(0.8 * n)])
    idx = {
        "train": np.flatnonzero([h in tr_h for h in hosts]),
        "val": np.flatnonzero([h in va_h for h in hosts]),
        "test": np.flatnonzero([h not in tr_h and h not in va_h for h in hosts]),
    }
    warnings = ["HOST HOLDOUT IS A DIAGNOSTIC, NOT A HEADLINE PROTOCOL. "
                "It changes the effective class set between folds. Do not "
                "report macro-F1 from this split alongside the others."]
    _check_all_classes_present(y, idx, warnings)
    man = SplitManifest(
        protocol="host_holdout", seed=seed, n_total=len(y),
        n_train=len(idx["train"]), n_val=len(idx["val"]), n_test=len(idx["test"]),
        n_groups=int(n), group_key="src_ip", class_counts=_class_counts(y, idx),
        is_claim_surface=False, warnings=warnings,
        data_fingerprint=_fingerprint(y))
    return idx, man


# --------------------------------------------------------------------------
# Near-duplicate signature grouping (for metadata-free datasets)
# --------------------------------------------------------------------------
_Q_OFFSET = np.uint64(1 << 20)
_HASH_MULT = np.uint64(0x100000001B3)   # FNV-1a 64-bit prime
_HASH_SEED = np.uint64(0xCBF29CE484222325)


def quantise_block(block: np.ndarray, bin_width: float) -> np.ndarray:
    """Data-independent log-scale binning. Returns int64, offset-free."""
    if bin_width <= 0:
        raise ValueError(f"bin_width must be positive, got {bin_width}")
    a = np.asarray(block, dtype=np.float64)
    mag = np.log1p(np.abs(a)) / float(bin_width)
    return (np.sign(a) * np.floor(mag)).astype(np.int64)


def _fold(h: np.ndarray, col: np.ndarray) -> np.ndarray:
    """One step of the rolling hash. Both operands kept uint64 throughout."""
    shifted = (np.asarray(col, dtype=np.int64) + np.int64(_Q_OFFSET))
    if (shifted < 0).any():
        raise RuntimeError("quantised value below hash offset")
    return (h * _HASH_MULT) ^ shifted.astype(np.uint64)


def feature_signature_hash(
    X: np.ndarray,
    y: np.ndarray,
    feature_order: list[str],
    *,
    bin_width: float | None = None,
    exclude: tuple[str, ...] | None = None,
    chunk: int = 200_000,
) -> tuple[np.ndarray, list[str]]:
    """Per-row 64-bit signature over quantised features and the label."""
    bw = float(bin_width if bin_width is not None else config.SIGNATURE_LOG_BIN_WIDTH)
    ex = tuple(exclude if exclude is not None else config.SIGNATURE_EXCLUDE_FEATURES)

    X = np.asarray(X)
    y = np.asarray(y)
    ex_set = {str(e).strip().lower() for e in ex}
    keep = [j for j, name in enumerate(feature_order)
            if str(name).strip().lower() not in ex_set]
    used = [feature_order[j] for j in keep]
    if not keep:
        raise ValueError("every feature was excluded from the signature")

    n = X.shape[0]
    out = np.empty(n, dtype=np.uint64)
    for i in range(0, n, chunk):
        sl = slice(i, min(i + chunk, n))
        block = np.asarray(X[sl])[:, keep]
        q = quantise_block(block, bw)
        h = np.full(q.shape[0], _HASH_SEED, dtype=np.uint64)
        for j in range(q.shape[1]):
            h = _fold(h, q[:, j])
        h = _fold(h, y[sl].astype(np.int64))
        out[sl] = h
    return out, used


def cap_group_sizes(group_ids: np.ndarray, row_index: np.ndarray,
                    max_flows: int | None = None) -> tuple[np.ndarray, int]:
    """Subdivide oversized groups into contiguous row-order chunks."""
    cap = int(max_flows if max_flows is not None else config.SIGNATURE_CAP_FLOWS)
    if cap <= 0:
        return group_ids, 0
    groups = np.asarray(group_ids, dtype=np.int64)
    row_index = np.asarray(row_index, dtype=np.int64)
    order = np.argsort(row_index)
    sorted_groups = groups[order]

    df = pd.DataFrame({"orig_idx": order, "g": sorted_groups})
    sub_count = (df.groupby("g").cumcount() // cap).to_numpy()
    new_group_codes, _ = pd.factorize(
        df["g"].astype(str) + "_" + pd.Series(sub_count).astype(str), sort=False)

    out = np.empty(len(groups), dtype=np.int64)
    out[order] = new_group_codes
    n_sub = int((pd.Series(groups).value_counts() > cap).sum())
    return out, n_sub


def mean_label_run_length(y: np.ndarray) -> float:
    """Average length of consecutive identical labels in row order."""
    y = np.asarray(y)
    if len(y) == 0:
        return float("nan")
    diff = np.flatnonzero(y[1:] != y[:-1])
    n_runs = len(diff) + 1
    return float(len(y) / n_runs)


def build_nearduplicate_split(
    y: np.ndarray,
    seed: int,
    *,
    X: np.ndarray | None = None,
    feature_order: list[str] | None = None,
    row_index: np.ndarray | None = None,
    assign: str = "ordered",
    bin_width: float | None = None,
    max_flows: int | None = None,
    fractions: dict[str, float] | None = None,
) -> tuple[dict[str, np.ndarray], SplitManifest]:
    """Near-duplicate group split using quantised feature signatures."""
    if assign not in ("ordered", "random"):
        raise ValueError(f"unknown assign={assign!r}; expected 'ordered' or 'random'")

    fr = fractions or config.SPLIT_FRACTIONS
    y = np.asarray(y)
    n_total = len(y)
    if row_index is None:
        row_index = np.arange(n_total, dtype=np.int64)

    warnings: list[str] = []
    if X is None or feature_order is None:
        raise ProtocolError("build_nearduplicate_split needs X and feature_order")

    raw_hashes, used_cols = feature_signature_hash(X, y, feature_order, bin_width=bin_width)
    dense_groups, _ = pd.factorize(pd.Series(raw_hashes), sort=False)
    capped_groups, n_sub = cap_group_sizes(dense_groups, row_index, max_flows=max_flows)

    n_groups = int(len(np.unique(capped_groups)))

    run_len = mean_label_run_length(y)
    is_claim = (assign == "ordered")
    if is_claim:
        if not np.isfinite(run_len) or run_len < config.MIN_MEAN_LABEL_RUN:
            warnings.append(
                f"Mean label run length {run_len:.2f} is low; verify CSV row ordering.")
    else:
        warnings.append(
            "nearduplicate_random shuffles groups. It exists to isolate the "
            "grouping effect and is NOT a claim surface.")

    df = pd.DataFrame({"g": capped_groups, "y": y, "r": row_index})
    agg = df.groupby("g").agg(y=("y", "first"), r=("r", "min"), n=("y", "size"))

    idx_parts: dict[str, list[np.ndarray]] = {"train": [], "val": [], "test": []}
    rng = np.random.default_rng(seed)

    for c in range(config.N_CLASSES):
        g_c = agg[agg["y"] == c]
        if len(g_c) == 0:
            warnings.append(f"class {config.CLASSES[c]} has no groups")
            continue
        if assign == "ordered":
            g_sorted = g_c.sort_values("r")
        else:
            g_sorted = g_c.sample(frac=1.0, random_state=rng.integers(0, 1 << 30))

        flow_counts = g_sorted["n"].to_numpy()
        group_ids = g_sorted.index.to_numpy()
        cum = np.cumsum(flow_counts)
        tot = cum[-1]

        target_tr = fr["train"] * tot
        target_va = (fr["train"] + fr["val"]) * tot

        cut_tr = int(np.searchsorted(cum, target_tr, side="right"))
        cut_va = int(np.searchsorted(cum, target_va, side="right"))

        tr_g = set(group_ids[:max(1, cut_tr)])
        va_g = set(group_ids[max(1, cut_tr):max(cut_tr + 1, cut_va)])
        te_g = set(group_ids[max(cut_tr + 1, cut_va):])
        if not te_g and len(group_ids) >= 3:
            te_g = {group_ids[-1]}
            va_g.discard(group_ids[-1])

        c_rows = np.flatnonzero(y == c)
        c_groups = capped_groups[c_rows]

        idx_parts["train"].append(c_rows[np.isin(c_groups, list(tr_g))])
        idx_parts["val"].append(c_rows[np.isin(c_groups, list(va_g))])
        idx_parts["test"].append(c_rows[np.isin(c_groups, list(te_g))])

    idx = {k: np.sort(np.concatenate(v)) if v else np.empty(0, dtype=int)
           for k, v in idx_parts.items()}
    _check_all_classes_present(y, idx, warnings)

    proto_name = "nearduplicate_temporal" if assign == "ordered" else "nearduplicate_random"
    man = SplitManifest(
        protocol=proto_name,
        seed=seed,
        n_total=n_total,
        n_train=len(idx["train"]),
        n_val=len(idx["val"]),
        n_test=len(idx["test"]),
        n_groups=n_groups,
        group_key="quantised_feature_signature",
        class_counts=_class_counts(y, idx),
        is_claim_surface=is_claim,
        warnings=warnings,
        data_fingerprint=_fingerprint(y),
    )
    return idx, man


def build_split(protocol: str, y: np.ndarray, meta: pd.DataFrame | None,
                seed: int, X: np.ndarray | None = None,
                feature_order: list[str] | None = None, **kw):
    """Dispatch. Raises rather than falling back."""
    if protocol == "random":
        return build_random_split(y, seed, **kw)
    if protocol == "grouped":
        if meta is None:
            raise ProtocolError(
                "grouped protocol requested but no metadata (timestamp/IP) is "
                "available. For metadata-free flow features, use the "
                "'nearduplicate_temporal' protocol as the leakage-free claim surface.")
        return build_grouped_split(y, meta, seed, **kw)
    if protocol == "nearduplicate_temporal":
        return build_nearduplicate_split(y, seed, X=X, feature_order=feature_order,
                                         assign="ordered", **kw)
    if protocol == "nearduplicate_random":
        return build_nearduplicate_split(y, seed, X=X, feature_order=feature_order,
                                         assign="random", **kw)
    if protocol == "host_holdout":
        if meta is None:
            raise ProtocolError("host_holdout requires metadata")
        return build_host_holdout_split(y, meta, seed)
    raise ValueError(f"unknown protocol {protocol!r}")
