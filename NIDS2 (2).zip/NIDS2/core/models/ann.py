"""Plain feed-forward multilayer perceptron (MLP) baseline.

ARCHITECTURE
------------
Three fully-connected hidden layers, each Linear -> BatchNorm1d -> ReLU ->
Dropout, followed by a linear classification head. Input is the flat
(B, F) standardised feature vector; no reshaping, no locality structure,
no recurrence.

INDUCTIVE BIAS ASSUMPTION ABOUT THE INPUT
-----------------------------------------
The assumption is that every input feature may interact with every other
one, and that no particular structure over the feature columns is worth
hard-coding. A dense layer connects all F inputs to all H units, so the
architecture imposes no notion of adjacency, ordering or grouping over the
columns. For CICFlowMeter output -- where the column order is an artefact
of the tool's output code rather than a property of network traffic -- this
is the weakest and least committal assumption of the ten models compared
here. Stated as the architecture's premise, not as a finding about it.

ON CLAIMS_PERMUTATION_INVARIANCE
--------------------------------
Set True, and the claim is specifically about the architecture's inductive
bias, not about a fixed set of trained weights. Permuting the input columns
by P maps any first-layer weight matrix W to W @ P^T, which is another point
in the same hypothesis space reached by the same optimiser -- so the family
of functions this architecture can express is closed under column
permutation. It does NOT mean an already-trained model can be handed
permuted columns and still work: the model must still be *trained* on the
permuted data for the equivalence to show up. The permutation test reads
this flag to form its expectation; it does not read it as a result.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

from typing import Any, Sequence

import torch
import torch.nn as nn

from core.common.model_utils import NIDSModel, register_model


@register_model("ann")
class ANN(NIDSModel):
    """Dense MLP over the flat feature vector.

    Shape kwargs (defaults here, never in config.py -- rule 5 keeps the
    *training* recipe shared, while per-architecture shape lives with the
    architecture):
        hidden   : Sequence[int] = (256, 128, 64)  widths of the hidden layers
        dropout  : float         = 0.2
    """

    INPUT_KIND = "flat"
    AUX_LOSS_WEIGHT = 0.0
    CLAIMS_PERMUTATION_INVARIANCE = True

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 **shape: Any):
        super().__init__(n_features, n_classes, group_idx, **shape)

        hidden: Sequence[int] = tuple(shape.get("hidden", (256, 128, 64)))
        dropout: float = float(shape.get("dropout", 0.2))
        # Record the resolved shape, not just what the caller happened to
        # pass, so the run log says what was actually built.
        self.shape_cfg.update(hidden=tuple(hidden), dropout=dropout)

        layers: list[nn.Module] = []
        in_dim = self.n_features
        for h in hidden:
            layers += [
                nn.Linear(in_dim, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
            ]
            in_dim = h
        self.body = nn.Sequential(*layers)
        self.head = nn.Linear(in_dim, self.n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """(B, F) -> (B, n_classes)."""
        return self.head(self.body(x))
