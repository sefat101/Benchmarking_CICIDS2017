"""Encoder-plus-classifier baseline: the autoencoder without reconstruction.

ARCHITECTURE
------------
A stack of dense compression layers (Linear -> BatchNorm1d -> ReLU ->
Dropout) narrowing the input to a low-dimensional latent code, then a linear
classification head on that code. There is no decoder and no reconstruction
term; the latent is shaped by the classification objective alone.

WHY THIS MODEL EXISTS -- IT IS AN ABLATION PARTNER
--------------------------------------------------
This module is deliberately the *exact* encoder half of autoencoder.py: same
hidden widths, same latent size, same normalisation, same activation, same
dropout placement, same single-Linear head on the latent. The only
difference between the two models is that autoencoder.py additionally
decodes the latent back to the input and returns a reconstruction term
(weighted by its declared AUX_LOSS_WEIGHT), while this model does not.

Holding everything else identical is the point: it is what lets the pair
isolate the contribution of the reconstruction objective rather than
confounding it with a width or depth change. If you edit the encoder shape
in one file, edit it identically in the other, or the ablation stops
measuring what it claims to measure.

INDUCTIVE BIAS ASSUMPTION ABOUT THE INPUT
-----------------------------------------
Two assumptions. First, as in the plain MLP, dense layers impose no
adjacency, ordering or grouping over the feature columns -- every input may
interact with every other. Second, and specific to this shape: that the
class-relevant information in the 77 flow features survives compression
into a much smaller latent, i.e. that the useful signal is low-dimensional.
That bottleneck is an architectural constraint being imposed on the problem,
and whether it costs anything is exactly what the comparison is for. Stated
as an assumption under test, not as a finding.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

from typing import Any, Sequence

import torch
import torch.nn as nn

from core.common.model_utils import NIDSModel, register_model


@register_model("encoder")
class Encoder(NIDSModel):
    """Dense compression to a latent code, then a linear classifier.

    Shape kwargs:
        hidden   : Sequence[int] = (128, 64)  encoder widths before the latent
        latent   : int           = 32         bottleneck width
        dropout  : float         = 0.2

    These defaults are kept identical to autoencoder.py on purpose (see the
    module docstring).
    """

    INPUT_KIND = "flat"
    AUX_LOSS_WEIGHT = 0.0
    CLAIMS_PERMUTATION_INVARIANCE = True

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 **shape: Any):
        super().__init__(n_features, n_classes, group_idx, **shape)

        hidden: Sequence[int] = tuple(shape.get("hidden", (128, 64)))
        latent: int = int(shape.get("latent", 32))
        dropout: float = float(shape.get("dropout", 0.2))
        self.shape_cfg.update(hidden=tuple(hidden), latent=latent,
                              dropout=dropout)
        self.latent_dim = latent

        # --- encoder stack: MUST match autoencoder.py layer for layer ------
        enc: list[nn.Module] = []
        in_dim = self.n_features
        for h in hidden:
            enc += [
                nn.Linear(in_dim, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
            ]
            in_dim = h
        enc += [
            nn.Linear(in_dim, latent),
            nn.BatchNorm1d(latent),
            nn.ReLU(inplace=True),
        ]
        self.encoder = nn.Sequential(*enc)

        self.head = nn.Linear(latent, self.n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """(B, F) -> (B, n_classes)."""
        return self.head(self.encoder(x))
