"""Autoencoder with a classifier head on the bottleneck.

ARCHITECTURE
------------
An encoder compresses the flat (B, F) input to a low-dimensional latent
code; a decoder reconstructs the input from that code; and a linear
classification head sits on the same code. forward() returns both the
logits and the reconstruction term:

    (logits, {"recon": mse(decoder(encoder(x)), x)})

The shared training loop in common/model_utils.py adds
AUX_LOSS_WEIGHT * sum(aux.values()) to the cross-entropy. That weight is
declared here, in the open, as part of this architecture's definition as a
baseline -- it is not a training advantage handed to this model. Every
other model in the comparison declares AUX_LOSS_WEIGHT = 0.0 and gets the
byte-identical optimiser, schedule, balancing and stopping rule.

The reconstruction loss is computed inside forward(), against the forward
pass's own input x, because the model is the only thing that knows what it
was asked to reconstruct. No loss function for the *task* is defined here:
the cross-entropy, the class weighting and the thresholding all live in the
shared loop.

RELATION TO encoder.py
----------------------
encoder.py is this model minus the decoder and minus the reconstruction
term, with a byte-identical encoder stack and head. The pair is an
ablation: keep every other layer the same so the only thing that varies is
the reconstruction objective. If you change the encoder widths, the latent
size or the dropout here, change them identically in encoder.py.

INDUCTIVE BIAS ASSUMPTION ABOUT THE INPUT
-----------------------------------------
Three assumptions. First, as in the plain MLP, dense layers impose no
adjacency, ordering or grouping over the feature columns. Second, that the
class-relevant signal survives compression into a small latent. Third --
the one that distinguishes this model from encoder.py -- that a latent
which can *reconstruct* the flow features is also a good latent for
*separating the classes*. That is a real assumption and not an obviously
safe one: reconstruction spends capacity in proportion to a feature's
variance, which need not track its usefulness for identifying an attack
class. Stated as the architecture's premise under test, not as a finding.

ON CLAIMS_PERMUTATION_INVARIANCE
--------------------------------
Set True on the same grounds as the MLP: the encoder's first layer and the
decoder's last layer are dense, so permuting the input columns yields
another point in the same hypothesis space (the reconstruction target is
permuted along with the input, consistently, since it *is* the input). This
is a statement about the architecture's inductive bias; the model still has
to be trained on the permuted data.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

from typing import Any, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from core.common.model_utils import NIDSModel, register_model


@register_model("autoencoder")
class AutoEncoder(NIDSModel):
    """Encoder + decoder + classifier head on the bottleneck.

    Shape kwargs (encoder defaults kept identical to encoder.py on purpose):
        hidden   : Sequence[int] = (128, 64)  encoder widths before the latent
        latent   : int           = 32         bottleneck width
        dropout  : float         = 0.2
    The decoder mirrors `hidden` in reverse.
    """

    INPUT_KIND = "flat"
    #: Part of this architecture's definition, declared openly. Only this
    #: model sets a nonzero value.
    AUX_LOSS_WEIGHT = 0.1
    CLAIMS_PERMUTATION_INVARIANCE = True

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 **shape: Any):
        super().__init__(n_features, n_classes, group_idx, **shape)

        hidden: Sequence[int] = tuple(shape.get("hidden", (128, 64)))
        latent: int = int(shape.get("latent", 32))
        dropout: float = float(shape.get("dropout", 0.2))
        self.shape_cfg.update(hidden=tuple(hidden), latent=latent,
                              dropout=dropout)
        self.latent_dim = latent

        # --- encoder stack: MUST match encoder.py layer for layer ----------
        enc: list[nn.Module] = []
        in_dim = self.n_features
        for h in hidden:
            enc += [
                nn.Linear(in_dim, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
            ]
            in_dim = h
        enc += [
            nn.Linear(in_dim, latent),
            nn.BatchNorm1d(latent),
            nn.ReLU(inplace=True),
        ]
        self.encoder = nn.Sequential(*enc)

        # --- decoder: mirrors the encoder widths in reverse ----------------
        dec: list[nn.Module] = []
        in_dim = latent
        for h in reversed(hidden):
            dec += [
                nn.Linear(in_dim, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
            ]
            in_dim = h
        # Final layer is linear with no activation: the inputs are
        # standardised real values, so the reconstruction is unbounded and
        # must not be squashed.
        dec += [nn.Linear(in_dim, self.n_features)]
        self.decoder = nn.Sequential(*dec)

        self.head = nn.Linear(latent, self.n_classes)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """(B, F) -> (logits (B, n_classes), {"recon": scalar mse}).

        The reconstruction target is the forward pass's own input x.
        """
        z = self.encoder(x)
        recon = self.decoder(z)
        logits = self.head(z)
        recon_loss = F.mse_loss(recon, x)
        return logits, {"recon": recon_loss}
