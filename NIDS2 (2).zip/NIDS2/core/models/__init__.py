"""Model package: importing it populates MODEL_REGISTRY with all ten models.

common/model_utils.py calls `import core.models` inside build_model() and
available_models(), so every model module must be imported here or the
registry will be missing entries and build_model() will raise KeyError on a
name that does in fact exist on disk.

The ten models, in the order the thesis presents them:
    eight baselines -- ann, cnn1d, autoencoder, encoder, transformer,
                       cnn_rnn, cnn_lstm, cnn_gru
    two proposals   -- sigma, gated_mlp

Each module registers itself via the @register_model decorator at import
time. register_model raises KeyError on a duplicate name, so importing this
package twice is safe (Python caches the module) but registering the same
name from two files is not -- which is the intended guard.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

# Imported for the registration side effect only; order is presentation
# order, not a dependency order.
from . import ann          # noqa: F401
from . import cnn1d        # noqa: F401
from . import autoencoder  # noqa: F401
from . import encoder      # noqa: F401
from . import transformer  # noqa: F401
from . import cnn_rnn      # noqa: F401
from . import cnn_lstm     # noqa: F401
from . import cnn_gru      # noqa: F401
from . import sigma        # noqa: F401
from . import gated_mlp    # noqa: F401

__all__ = [
    "ann",
    "cnn1d",
    "autoencoder",
    "encoder",
    "transformer",
    "cnn_rnn",
    "cnn_lstm",
    "cnn_gru",
    "sigma",
    "gated_mlp",
]
