"""SIGMA -- Semantically-Indexed Group-Modulated Architecture. THE PROPOSAL.

STATUS: this file is an ARCHITECTURE and a HYPOTHESIS. It contains no
results. Every performance statement below is labelled CONJECTURE and must
stay out of any results table until the runner has produced 5 seeds on the
grouped protocol.

THE PROBLEM IT TARGETS
----------------------
Under the leakage-free grouped protocol, at a fixed 95% pooled attack recall,
the false-positive rate is the operational cost: at 80.4% BENIGN prevalence,
every 1% of FPR is roughly 22,700 false alarms per 2.83M flows -- against a
Bot class of 1,966 flows total. Pooled recall is dominated by DoS Hulk,
PortScan and DDoS (~92% of all attack flows, CITED arithmetic from
config.EXPECTED_CLASS_COUNTS), so a model can sit at 95% pooled recall while
detecting almost no Bot. The target is therefore: reduce FPR at fixed pooled
recall WITHOUT collapsing minority-class recall.

THE ARCHITECTURAL CLAIM (CONJECTURE, PRE-REGISTERED)
----------------------------------------------------
CICFlowMeter emits 78 columns in an order fixed by its output code. Adjacent
columns are routinely unrelated. Baselines that apply 1-D convolution or
recurrence along that axis (cnn1d, cnn_rnn, cnn_lstm, cnn_gru) therefore
impose a locality prior the data does not satisfy.

H1: those four models are sensitive to a random permutation of the column
    order; ann/encoder/sigma are not (beyond retraining noise).
H2: attack classes are localised in FEATURE-GROUP space -- e.g. the slow-rate
    DoS classes in timing/idle features, PortScan in flag/volume features --
    so a model that reasons over semantic groups can suppress irrelevant
    groups per sample and cut false positives.

H1 is falsifiable by the permutation test in tools/run_experiment.py
(--permute-columns). If cnn1d does NOT degrade, the motivation for SIGMA is
weaker and the paper must say so.
H2 is falsifiable by the gated_mlp control: identical machinery with the
semantic partition replaced by an ARBITRARY partition of identical group
sizes. If gated_mlp matches SIGMA, the gain is from gating, not from
semantics, and the contribution must be reframed as such.

HOW IT WORKS
------------
1. Partition the 77 features into 11 semantic groups (common/feature_groups).
2. Encode each group independently with its own small MLP -> d_emb.
   Groups differ in size and meaning, so weights are NOT shared.
3. A gate reads a cheap summary of all groups and emits per-sample weights
   over the 11 groups.
4. Group embeddings are modulated by those weights, concatenated, and read
   out by a classifier head.

Because group membership is resolved from COLUMN NAMES, not positions, the
model is invariant to column order by construction.

INTERPRETABILITY
----------------
The gate weights are a per-sample, per-group relevance vector. Averaged per
class they give a 10x11 matrix that is a genuine explanation artefact, not a
saliency heuristic. tools/build_journal_outputs.py renders it. This is a
property of the architecture; whether it is USEFUL is an empirical question.

FAIRNESS NOTE (evaluation rule 5)
---------------------------------
SIGMA trains through the same loop, optimiser, schedule, loss, balancing and
calibration as all nine other models. The only thing that differs is the
forward pass. The gate-entropy regulariser is DEFAULT OFF; if it is turned
on it is part of the architecture definition and must be reported as such,
and the same switch exists on gated_mlp so the control stays matched.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from core.common.model_utils import NIDSModel, register_model


class GroupEncoder(nn.Module):
    """One small MLP per feature group. No weight sharing across groups."""

    def __init__(self, in_dim: int, d_emb: int, hidden: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.BatchNorm1d(hidden),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden, d_emb),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GroupGate(nn.Module):
    """Per-sample relevance over groups.

    mode='softmax'  competitive; groups compete for a fixed budget.
    mode='sigmoid'  independent; groups may all be on or all off.
    mode='uniform'  ABLATION. Gate disabled, weights frozen at 1/G. Isolates
                    "does the gating do anything" from "does the grouping do
                    anything".
    """

    def __init__(self, n_groups: int, d_emb: int, hidden: int,
                 mode: str = "softmax", temperature: float = 1.0):
        super().__init__()
        self.n_groups = n_groups
        self.mode = mode
        self.temperature = temperature
        if mode != "uniform":
            self.net = nn.Sequential(
                nn.Linear(n_groups * d_emb, hidden),
                nn.ReLU(inplace=True),
                nn.Linear(hidden, n_groups),
            )

    def forward(self, emb: torch.Tensor) -> torch.Tensor:
        # emb: (B, G, d_emb) -> weights (B, G)
        B, G, _ = emb.shape
        if self.mode == "uniform":
            return emb.new_full((B, G), 1.0 / G)
        logits = self.net(emb.reshape(B, -1)) / self.temperature
        if self.mode == "softmax":
            return torch.softmax(logits, dim=1)
        if self.mode == "sigmoid":
            return torch.sigmoid(logits)
        raise ValueError(f"unknown gate mode {self.mode!r}")


class _GroupModulatedNet(NIDSModel):
    """Shared implementation for SIGMA and its arbitrary-partition control.

    Subclasses supply `resolve_groups()`, which returns the list of column
    index lists. That single method is the ONLY difference between the
    proposal and the control -- which is what makes the control a clean test
    of the semantic partition rather than of the machinery.
    """

    INPUT_KIND = "flat"
    CLAIMS_PERMUTATION_INVARIANCE = True

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 d_emb: int = 32, group_hidden: int = 64, gate_hidden: int = 64,
                 head_hidden: int = 128, dropout: float = 0.2,
                 gate_mode: str = "softmax", gate_temperature: float = 1.0,
                 gate_entropy_weight: float = 0.0, **shape):
        super().__init__(n_features, n_classes, group_idx,
                         d_emb=d_emb, group_hidden=group_hidden,
                         gate_hidden=gate_hidden, head_hidden=head_hidden,
                         dropout=dropout, gate_mode=gate_mode,
                         gate_temperature=gate_temperature,
                         gate_entropy_weight=gate_entropy_weight, **shape)

        members, names = self.resolve_groups(n_features, group_idx)
        if not members:
            raise ValueError("no non-empty feature groups; cannot build")
        self.group_names = names
        self.n_groups = len(members)
        covered = sum(len(m) for m in members)
        if covered != n_features:
            # Not fatal -- preprocessing may have dropped columns -- but it
            # must be visible, because a silently shrunken input is a
            # different experiment.
            self.shape_cfg["coverage_warning"] = (
                f"groups cover {covered} of {n_features} features")

        for i, m in enumerate(members):
            self.register_buffer(f"gidx_{i}",
                                 torch.tensor(m, dtype=torch.long),
                                 persistent=True)

        self.encoders = nn.ModuleList(
            [GroupEncoder(len(m), d_emb, group_hidden, dropout) for m in members])
        self.gate = GroupGate(self.n_groups, d_emb, gate_hidden,
                              mode=gate_mode, temperature=gate_temperature)
        self.head = nn.Sequential(
            nn.Linear(self.n_groups * d_emb, head_hidden),
            nn.BatchNorm1d(head_hidden),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(head_hidden, n_classes),
        )
        # Instance-level override of the class default. The training loop
        # reads model.AUX_LOSS_WEIGHT, so setting it here is what makes the
        # regulariser active; default 0.0 means SIGMA adds no extra loss term
        # and is trained exactly like every baseline.
        self.AUX_LOSS_WEIGHT = float(gate_entropy_weight)
        self._last_gate: torch.Tensor | None = None

    # -- the one method that differs between proposal and control ---------
    def resolve_groups(self, n_features: int,
                       group_idx: dict[str, list[int]] | None
                       ) -> tuple[list[list[int]], list[str]]:
        raise NotImplementedError

    def forward(self, x: torch.Tensor):
        embs = []
        for i, enc in enumerate(self.encoders):
            idx = getattr(self, f"gidx_{i}")
            embs.append(enc(x.index_select(1, idx)))
        emb = torch.stack(embs, dim=1)                  # (B, G, d_emb)
        w = self.gate(emb)                              # (B, G)
        self._last_gate = w.detach()
        modulated = emb * w.unsqueeze(-1)
        logits = self.head(modulated.reshape(x.size(0), -1))

        if self.AUX_LOSS_WEIGHT:
            p = w.clamp_min(1e-8)
            p = p / p.sum(dim=1, keepdim=True)
            entropy = -(p * p.log()).sum(dim=1).mean()
            return logits, {"gate_entropy": entropy}
        return logits

    @torch.no_grad()
    def gate_weights(self, x: torch.Tensor) -> torch.Tensor:
        """Per-sample group relevance, (B, G). For the explanation figure."""
        self.eval()
        self.forward(x)
        assert self._last_gate is not None
        return self._last_gate


@register_model("sigma")
class Sigma(_GroupModulatedNet):
    """THE PROPOSAL. Groups are the semantic partition from feature_groups."""

    def resolve_groups(self, n_features, group_idx):
        if group_idx is None:
            raise ValueError(
                "sigma requires group_idx (semantic partition). Build it with "
                "core.common.feature_groups.group_index_map(feature_order) and "
                "pass it to build_model. Refusing to fall back to an arbitrary "
                "partition -- that would silently turn the proposal into its "
                "own control.")
        members, names = [], []
        for g, idxs in group_idx.items():
            if idxs:
                members.append(list(idxs))
                names.append(g)
        return members, names

# The control, GatedMLP, lives in gated_mlp.py and imports
# _GroupModulatedNet from this module. It is deliberately in a separate file
# so that neither can be edited without the diff making the asymmetry obvious.
