"""1-D convolutional baseline over the feature-column axis.

ARCHITECTURE
------------
The (B, 1, F) input is treated as a length-F signal with one channel.
Three blocks of Conv1d -> BatchNorm1d -> ReLU -> MaxPool1d reduce the length
while widening the channels; adaptive average pooling then collapses the
remaining length to one value per channel, and a linear head produces the
logits.

INDUCTIVE BIAS ASSUMPTION ABOUT THE INPUT -- READ THIS
------------------------------------------------------
A 1-D convolution slides a small kernel along an axis and shares weights
across positions. Doing that along the *feature-column* axis assumes two
things: that adjacency between neighbouring columns is meaningful (columns
i and i+1 are related, so a kernel spanning them computes something
sensible), and that a pattern is worth detecting regardless of which
columns it lands on (weight sharing).

In CICFlowMeter output the column order is arbitrary. It reflects the order
in which the tool's output code emits fields, not any property of network
traffic -- as common/feature_groups.py documents, 'Bwd IAT Min' sits next
to 'Fwd PSH Flags'. So the locality this architecture is built to exploit
is not known to exist in this input, and the weight sharing pools together
columns measured in unrelated units.

That is a STATED ASSUMPTION BEING TESTED, not a finding, and not a
prediction about how this model will score. The repo ships a pre-registered
column-permutation test precisely so the assumption is checked rather than
argued about; CLAIMS_PERMUTATION_INVARIANCE is False here because this
architecture is, by construction, sensitive to column order.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

from typing import Any, Sequence

import torch
import torch.nn as nn

from core.common.model_utils import NIDSModel, register_model


@register_model("cnn1d")
class CNN1D(NIDSModel):
    """Conv1d stack over the feature axis, global pooling, linear head.

    Shape kwargs:
        channels    : Sequence[int] = (32, 64, 128)  one conv block each
        kernel_size : int           = 3
        dropout     : float         = 0.2

    Length arithmetic, checked for the F = 77 case this repo runs:
    each MaxPool1d(2) maps L -> floor(L / 2), so 77 -> 38 -> 19 -> 9. The
    length stays >= 1 at every stage. For defensiveness with other feature
    counts, a block skips its pool when the running length is already < 2,
    so the stack can never reduce the length to zero.
    """

    INPUT_KIND = "seq"
    AUX_LOSS_WEIGHT = 0.0
    #: A convolution along the column axis is order-sensitive by
    #: construction. The permutation test expects sensitivity here.
    CLAIMS_PERMUTATION_INVARIANCE = False

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 **shape: Any):
        super().__init__(n_features, n_classes, group_idx, **shape)

        channels: Sequence[int] = tuple(shape.get("channels", (32, 64, 128)))
        kernel_size: int = int(shape.get("kernel_size", 3))
        dropout: float = float(shape.get("dropout", 0.2))
        self.shape_cfg.update(channels=tuple(channels),
                              kernel_size=kernel_size, dropout=dropout)

        # 'same'-style padding keeps the conv itself length-preserving, so
        # all length reduction is done by the pools and is easy to audit.
        padding = kernel_size // 2

        blocks: list[nn.Module] = []
        in_ch = 1                       # (B, 1, F): one channel, length F
        length = self.n_features
        for out_ch in channels:
            blocks += [
                nn.Conv1d(in_ch, out_ch, kernel_size=kernel_size,
                          padding=padding),
                nn.BatchNorm1d(out_ch),
                nn.ReLU(inplace=True),
            ]
            if length >= 2:             # guard: never pool a length-1 signal
                blocks.append(nn.MaxPool1d(2))
                length //= 2
            in_ch = out_ch
        self.features = nn.Sequential(*blocks)
        self.final_length = length

        # Global pooling over whatever length survives -> (B, C, 1).
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(in_ch, self.n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """(B, 1, F) -> (B, n_classes)."""
        h = self.features(x)            # (B, C_last, L)
        h = self.pool(h).squeeze(-1)    # (B, C_last)
        return self.head(self.drop(h))
