"""gated_mlp -- THE CONTROL for SIGMA. Not a baseline, an ablation.

WHAT THIS ISOLATES
------------------
gated_mlp is SIGMA with exactly one thing changed: the assignment of columns
to groups is ARBITRARY (a fixed-seed permutation) instead of semantic. Group
SIZES are copied from the semantic partition, so parameter count, depth,
capacity, and the gating machinery are matched.

Read the three-way comparison as:

    sigma - gated_mlp  = the value of the SEMANTIC PARTITION
    gated_mlp - ann    = the value of the GATING MACHINERY
    sigma - ann        = the value of the proposal as a whole

If sigma does not separate from gated_mlp by more than one standard
deviation across the 5 seeds on the grouped protocol, then the semantic
partition is not doing the work, and the paper must say that in those words.
The contribution would then be "group-gated MLPs help on flow features",
which is a smaller and different claim than the one SIGMA is written to make.

This file deliberately lives apart from sigma.py so that any edit which
breaks the symmetry between proposal and control shows up as a diff in one
of two files rather than as a quiet change inside a shared class.

STATUS: architecture only. No results, no performance claims.
"""
from __future__ import annotations

import torch

from core.common.model_utils import register_model
from core.models.sigma import _GroupModulatedNet


@register_model("gated_mlp")
class GatedMLP(_GroupModulatedNet):
    """SIGMA's machinery over an arbitrary partition of identical shape."""

    #: Fixed so the control is reproducible across seeds and machines. The
    #: model seed varies per run; this partition does not, because the
    #: partition is part of the architecture definition, not of the run.
    PARTITION_SEED = 1234

    def resolve_groups(self, n_features, group_idx):
        if group_idx is not None:
            # Match SIGMA's group sizes exactly.
            sizes = [len(v) for v in group_idx.values() if v]
        else:
            # No semantic partition available: 11 near-equal groups, matching
            # the group COUNT of the semantic partition.
            base, rem = divmod(n_features, 11)
            sizes = [base + (1 if i < rem else 0) for i in range(11)]
        if sum(sizes) != n_features:
            raise ValueError(
                f"arbitrary partition sizes sum to {sum(sizes)} but there are "
                f"{n_features} features; the control would not be capacity-"
                "matched to sigma. Refusing to build a mismatched control.")

        g = torch.Generator().manual_seed(self.PARTITION_SEED)
        perm = torch.randperm(n_features, generator=g).tolist()
        members, names, start = [], [], 0
        for i, s in enumerate(sizes):
            if s:
                members.append(perm[start:start + s])
                names.append(f"arbitrary_{i}")
                start += s
        return members, names
