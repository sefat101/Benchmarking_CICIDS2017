"""Convolutional front end followed by an LSTM.

ARCHITECTURE
------------
A two-block Conv1d stem runs over the (B, 1, F) input, the result is
permuted to (B, L, C) so the surviving length becomes the "time" axis, and
a single-layer nn.LSTM consumes that sequence. The last hidden state feeds
a linear head.

THE CONV STEM IS SHARED WITH cnn_rnn.py AND cnn_gru.py
-------------------------------------------------------
cnn_rnn / cnn_lstm / cnn_gru exist as a three-way comparison in which the
ONLY difference is the recurrent cell: nn.LSTM here, a vanilla nn.RNN in
cnn_rnn.py, nn.GRU in cnn_gru.py. The _ConvStem class below is duplicated
byte-for-byte in all three files (duplicated deliberately, so each model
file reads standalone). Its layer spec -- channels, kernel size, padding,
normalisation, activation, pool count -- MUST stay identical across the
three. If you change it in one file, change it identically in the other
two, or the comparison stops isolating the recurrent cell and starts
measuring the stem.

INDUCTIVE BIAS ASSUMPTION ABOUT THE INPUT -- READ THIS
------------------------------------------------------
This model applies both convolution and recurrence along the
*feature-column* axis. Convolution there assumes adjacency between
neighbouring columns is meaningful. Recurrence there assumes something
stronger still: that the columns form an ordered sequence in which position
t genuinely follows position t-1, so that carrying a hidden state left to
right accumulates something coherent. An LSTM additionally adds gated
long-range memory along that axis, which only means something if the axis
has an order worth remembering.

In CICFlowMeter output the column order is arbitrary -- it reflects the
order the tool's code emits fields, not a property of network traffic (see
common/feature_groups.py, where 'Bwd IAT Min' sits beside 'Fwd PSH Flags').
There is no time axis here at all: one row is one already-summarised flow,
not a sequence of packets. So the ordering that the recurrence is built to
exploit is not known to exist in this input.

That is a STATED ASSUMPTION BEING TESTED, not a finding, and not a
prediction about how this model will score. The pre-registered
column-permutation test is what decides it. CLAIMS_PERMUTATION_INVARIANCE
is False because this architecture is order-sensitive by construction.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

from typing import Any, Sequence

import torch
import torch.nn as nn

from core.common.model_utils import NIDSModel, register_model


# --------------------------------------------------------------------------
# Shared conv stem. DUPLICATED VERBATIM in cnn_rnn.py, cnn_lstm.py and
# cnn_gru.py so that the three models differ only in the recurrent cell.
# Keep the three copies identical.
# --------------------------------------------------------------------------
class _ConvStem(nn.Module):
    """Conv1d blocks over the feature axis, emitting (B, L, C).

    Two blocks of Conv1d -> BatchNorm1d -> ReLU -> MaxPool1d(2). With
    'same'-style padding the convs preserve length, so only the pools
    shorten it: each maps L -> floor(L / 2). For the F = 77 case this repo
    runs, 77 -> 38 -> 19, leaving 19 timesteps for the recurrent layer.
    A block skips its pool if the running length is already < 2, so the
    stem can never reduce the length to zero for smaller feature counts.
    """

    def __init__(self, n_features: int, channels: Sequence[int],
                 kernel_size: int):
        super().__init__()
        padding = kernel_size // 2
        blocks: list[nn.Module] = []
        in_ch = 1                       # (B, 1, F): one channel, length F
        length = n_features
        for out_ch in channels:
            blocks += [
                nn.Conv1d(in_ch, out_ch, kernel_size=kernel_size,
                          padding=padding),
                nn.BatchNorm1d(out_ch),
                nn.ReLU(inplace=True),
            ]
            if length >= 2:             # guard: never pool a length-1 signal
                blocks.append(nn.MaxPool1d(2))
                length //= 2
            in_ch = out_ch
        self.net = nn.Sequential(*blocks)
        self.out_channels = in_ch
        self.out_length = length

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """(B, 1, F) -> (B, L, C), ready for a batch_first recurrent layer."""
        h = self.net(x)                 # (B, C, L)
        return h.permute(0, 2, 1)       # (B, L, C)


@register_model("cnn_lstm")
class CNNLSTM(NIDSModel):
    """Conv stem -> nn.LSTM -> linear head.

    Shape kwargs (the stem defaults are shared with cnn_rnn / cnn_gru):
        channels    : Sequence[int] = (32, 64)  conv stem, one block each
        kernel_size : int           = 3
        hidden      : int           = 64        recurrent hidden width
        num_layers  : int           = 1
        dropout     : float         = 0.2
    """

    INPUT_KIND = "seq"
    AUX_LOSS_WEIGHT = 0.0
    #: Convolution and recurrence along the column axis are order-sensitive
    #: by construction. The permutation test expects sensitivity here.
    CLAIMS_PERMUTATION_INVARIANCE = False

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 **shape: Any):
        super().__init__(n_features, n_classes, group_idx, **shape)

        channels: Sequence[int] = tuple(shape.get("channels", (32, 64)))
        kernel_size: int = int(shape.get("kernel_size", 3))
        hidden: int = int(shape.get("hidden", 64))
        num_layers: int = int(shape.get("num_layers", 1))
        dropout: float = float(shape.get("dropout", 0.2))
        self.shape_cfg.update(channels=tuple(channels),
                              kernel_size=kernel_size, hidden=hidden,
                              num_layers=num_layers, dropout=dropout)

        self.stem = _ConvStem(self.n_features, channels, kernel_size)

        # THE ONLY LINE THAT DIFFERS FROM cnn_rnn.py / cnn_gru.py.
        # nn.LSTM's own `dropout` argument applies only between stacked
        # layers, so it is left at its default for the single-layer case and
        # dropout is applied explicitly on the pooled state below -- the
        # same placement is used in all three models.
        self.rnn = nn.LSTM(
            input_size=self.stem.out_channels,
            hidden_size=hidden,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(hidden, self.n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """(B, 1, F) -> (B, n_classes)."""
        seq = self.stem(x)              # (B, L, C)
        # nn.LSTM returns (output, (h_n, c_n)) -- the cell state is the only
        # structural difference from cnn_rnn.py / cnn_gru.py, which return
        # (output, h_n). The hidden state used downstream is the same.
        _, (h_n, _c_n) = self.rnn(seq)  # h_n: (num_layers, B, hidden)
        last = h_n[-1]                  # last layer's final hidden state
        return self.head(self.drop(last))
