"""Transformer encoder treating each feature column as a token.

ARCHITECTURE
------------
The (B, 1, F) input is reshaped to (B, F, 1) so that each of the F scalar
features becomes one token. A Linear(1, d_model) projects each scalar to
the model width, a learned positional embedding of shape (F, d_model) is
added, an nn.TransformerEncoder (batch_first) mixes the tokens, the token
axis is mean-pooled, and a linear head produces the logits.

MEMORY -- THIS IS THE CONSTRAINT THAT SETS THE DEFAULTS
--------------------------------------------------------
The attention matrix has shape (B, heads, F, F). With F = 77 tokens and the
shared batch size of 1024 from config.SHARED_TRAIN, that is
1024 x 4 x 77 x 77 fp32 values per attention, i.e. roughly 97 MB, and it is
materialised once per layer with more held for the backward pass. The
target device is a single 8 GB card (config.GPU_EXPECTED), so d_model,
head count, depth and especially dim_feedforward are all kept deliberately
small: d_model 64, 4 heads, 2 layers, dim_feedforward 128 rather than
nn.TransformerEncoderLayer's own 2048 default. Raising any of these raises
activation memory quickly -- check the (B, heads, F, F) arithmetic before
you do. Note that the batch size itself is NOT a knob available here: it is
shared across all ten models by rule 5 and lives in config.py.

INDUCTIVE BIAS ASSUMPTION ABOUT THE INPUT
-----------------------------------------
Tokenising per feature assumes the useful structure is in *pairwise
interactions between individual columns*, which attention computes
explicitly for every pair, and that a single scalar carries enough to be
worth its own token. Unlike the conv and recurrent models, nothing here
assumes neighbouring columns are adjacent in any meaningful sense:
attention reaches every pair at equal cost regardless of distance, so
arbitrary column order is not an obstacle to the attention mechanism
itself.

ON CLAIMS_PERMUTATION_INVARIANCE -- WHY True HERE
--------------------------------------------------
At FIXED parameters this stack is not invariant to column order: swap two
columns and the wrong rows of the positional embedding are added. That is
true, and it is also true of the plain MLP, whose first weight matrix would
equally need permuting -- so it cannot be the definition the flag uses,
because a flag that is False for every model in the registry tells a reader
nothing and gives the falsification test no contrast to measure.

What the test in run_experiment.py actually does is RETRAIN FROM SCRATCH on
column-permuted input (it permutes X and feature_order before the split).
Under that definition the question is whether the hypothesis space is closed
under permutation, i.e. whether some other parameter setting f_theta' exists
with f_theta'(pi x) = f_theta*(x) for the optimal theta*. Here it does:
permute the ROWS of pos_embedding to match, leave token_proj (shared across
tokens) alone, and the token sequence is merely reordered. Attention is
permutation-equivariant, so the encoder output is reordered the same way,
and the mean-pool over the token axis is permutation-INVARIANT. The pooled
vector is therefore bit-identical and the loss is unchanged.

So the learned positional embedding makes column ORDER meaningful without
making the model's reachable performance depend on it. True is the correct
declaration under the retraining definition; False would be correct only for
a fixed-parameter invariance claim, which is not what is measured. Compare
sigma, whose groups resolve by column NAME and so is invariant even more
directly, and cnn1d, which is genuinely sensitive because a width-k kernel
cannot span an arbitrary permutation of the column axis.

Stated as a property of the hypothesis space, not as a measured finding.

PROVENANCE: this module computes no results. Nothing here is measured.
"""
from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from core.common.model_utils import NIDSModel, register_model


@register_model("transformer")
class FeatureTransformer(NIDSModel):
    """Per-feature tokens, learned positions, transformer encoder, mean pool.

    Shape kwargs:
        d_model         : int   = 64   token width
        nhead           : int   = 4    attention heads
        num_layers      : int   = 2    encoder layers
        dim_feedforward : int   = 128  FFN width inside each layer
        dropout         : float = 0.2
    """

    INPUT_KIND = "seq"
    AUX_LOSS_WEIGHT = 0.0
    #: True under the retraining definition the permutation test implements:
    #: pos_embedding's rows permute with the columns and the mean-pool is
    #: order-invariant, so column order cannot change reachable performance.
    #: See the module docstring -- this is NOT a fixed-parameter invariance.
    CLAIMS_PERMUTATION_INVARIANCE = True

    def __init__(self, n_features: int, n_classes: int,
                 group_idx: dict[str, list[int]] | None = None,
                 **shape: Any):
        super().__init__(n_features, n_classes, group_idx, **shape)

        d_model: int = int(shape.get("d_model", 64))
        nhead: int = int(shape.get("nhead", 4))
        num_layers: int = int(shape.get("num_layers", 2))
        dim_feedforward: int = int(shape.get("dim_feedforward", 128))
        dropout: float = float(shape.get("dropout", 0.2))
        self.shape_cfg.update(d_model=d_model, nhead=nhead,
                              num_layers=num_layers,
                              dim_feedforward=dim_feedforward,
                              dropout=dropout)

        if d_model % nhead != 0:
            raise ValueError(
                f"d_model ({d_model}) must be divisible by nhead ({nhead})")

        # Scalar -> token vector, applied to the last dim of (B, F, 1).
        self.token_proj = nn.Linear(1, d_model)

        # Learned positional embedding, one vector per feature column.
        # Shape (1, F, d_model) so it broadcasts over the batch.
        self.pos_embedding = nn.Parameter(
            torch.zeros(1, self.n_features, d_model))
        nn.init.normal_(self.pos_embedding, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,           # (B, F, d_model)
        )
        # enable_nested_tensor=False: the nested-tensor fast path is skipped
        # deliberately. There is no padding here (every sequence is exactly
        # F tokens) so it would buy nothing, and set_seed() in model_utils
        # asks for deterministic algorithms -- keeping the plain path keeps
        # runs reproducible. It also silences the fast-path warning.
        self.encoder = nn.TransformerEncoder(
            layer, num_layers=num_layers, enable_nested_tensor=False)

        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(d_model, self.n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """(B, 1, F) -> (B, n_classes)."""
        # (B, 1, F) -> (B, F, 1): one token per feature column.
        tokens = x.transpose(1, 2)
        h = self.token_proj(tokens)         # (B, F, d_model)
        h = h + self.pos_embedding          # broadcast over the batch
        # Attention inside is (B, nhead, F, F) -- see the memory note above.
        h = self.encoder(h)                 # (B, F, d_model)
        pooled = h.mean(dim=1)              # mean-pool over the token axis
        return self.head(self.drop(pooled))
