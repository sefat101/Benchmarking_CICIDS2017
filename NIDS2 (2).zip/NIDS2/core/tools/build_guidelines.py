"""Render the three guideline markdown sources to PDF.

WHY A SCRIPT AND NOT A COMMITTED PDF
------------------------------------
The markdown source is the single source of truth. A PDF committed alongside
it drifts the moment someone edits the markdown, and a stale guideline is
worse than none -- it documents a protocol the code no longer implements.
So the PDFs are generated artefacts, rebuilt from source on demand.

Dependencies: the standard library only, via core/common/pdfwriter.py. No
reportlab, no pandoc, no network. This runs anywhere the rest of the code runs.

USAGE
-----
    python -m core.tools.build_guidelines            # all three
    python -m core.tools.build_guidelines --check    # verify, do not write
    python -m core.tools.build_guidelines --only testing

PROVENANCE: this tool computes no results. It typesets documents. Every number
that appears in the output PDFs came from the markdown source, and the
markdown sources contain only CITED constants and empty result templates.
"""
from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

from core import config
from core.common import pdfwriter
from core.common.pdfwriter import md_file_to_pdf


@dataclass(frozen=True)
class Doc:
    key: str
    src: Path
    out: Path
    title: str
    footer: str


def documents() -> list[Doc]:
    root = config.REPO_ROOT
    return [
        Doc("repo",
            root / "docs" / "GUIDELINE.md",
            root / "docs" / "guideline.pdf",
            "NIDS2 - Repository Guideline",
            "NIDS2 repository guideline - what the code does and what to run"),
        Doc("testing",
            root / "testing" / "GUIDELINE.md",
            root / "testing" / "guideline.pdf",
            "NIDS2 - Testing Guideline",
            "NIDS2 testing guideline - verification before trusting a number"),
        Doc("proposal",
            root / "proposal_sigma" / "GUIDELINE.md",
            root / "proposal_sigma" / "guideline.pdf",
            "SIGMA - Proposal Guideline",
            "SIGMA proposal guideline - plan, hypotheses, decision rules"),
    ]


# --------------------------------------------------------------------------
# Post-render checks.  A PDF that opens is not the same as a PDF that is
# correct, and a guideline is exactly the kind of file nobody opens until it
# matters.  These are cheap structural checks on the bytes we just wrote.
# --------------------------------------------------------------------------
def verify_pdf(path: Path) -> list[str]:
    """Structural sanity checks. Returns a list of problems (empty == good)."""
    problems: list[str] = []
    if not path.exists():
        return [f"{path.name}: not written"]
    raw = path.read_bytes()

    if not raw.startswith(b"%PDF-"):
        problems.append(f"{path.name}: missing %PDF header")
    if not raw.rstrip().endswith(b"%%EOF"):
        problems.append(f"{path.name}: missing %%EOF trailer")
    if b"/Type /Catalog" not in raw:
        problems.append(f"{path.name}: no document catalog")

    # startxref must point at the literal bytes 'xref'. This is the failure
    # mode of any hand-rolled PDF writer: offsets computed rather than
    # recorded. Readers that rebuild the xref table silently mask it, so
    # check it here rather than trusting that the file "opened fine".
    tail = raw[-2048:]
    if b"startxref" not in tail:
        problems.append(f"{path.name}: no startxref")
    else:
        try:
            after = tail.split(b"startxref")[-1].strip().split()[0]
            at = int(after)
            if raw[at:at + 4] != b"xref":
                problems.append(
                    f"{path.name}: startxref points to {raw[at:at+8]!r}, "
                    "not 'xref' -- cross-reference offsets are wrong")
        except (ValueError, IndexError):
            problems.append(f"{path.name}: unparseable startxref")

    n_pages = raw.count(b"/Type /Page ")
    if n_pages == 0:
        problems.append(f"{path.name}: zero pages")
    if len(raw) < 4096:
        problems.append(f"{path.name}: {len(raw)} bytes -- implausibly small")
    return problems


def source_checks(src: Path) -> list[str]:
    """Warn about markdown this renderer cannot represent.

    It does not fail the build -- a lost bold marker is cosmetic. But an
    unclosed code fence swallows the rest of the document, which is not.
    """
    warn: list[str] = []
    text = src.read_text(encoding="utf-8")
    if text.count("```") % 2:
        warn.append(f"{src.name}: odd number of ``` fences -- a code block is "
                    "unclosed and everything after it will render as code")
    for i, ln in enumerate(text.split("\n"), start=1):
        if len(ln) > 200 and not ln.lstrip().startswith("|"):
            warn.append(f"{src.name}:{i}: very long line ({len(ln)} chars)")
    return warn


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--only", choices=[d.key for d in documents()],
                    help="build a single document")
    ap.add_argument("--check", action="store_true",
                    help="verify sources and existing PDFs; write nothing")
    args = ap.parse_args(argv)

    docs = [d for d in documents() if args.only in (None, d.key)]

    missing = [d for d in docs if not d.src.exists()]
    if missing:
        print("ERROR: missing markdown source(s):", file=sys.stderr)
        for d in missing:
            print(f"  {d.src}", file=sys.stderr)
        print("\nThe PDFs are generated from the markdown. Without the "
              "source there is nothing to typeset.", file=sys.stderr)
        return 1

    all_warnings: list[str] = []
    for d in docs:
        all_warnings += source_checks(d.src)

    if args.check:
        problems: list[str] = []
        for d in docs:
            problems += verify_pdf(d.out)
        for w in all_warnings:
            print(f"WARNING  {w}")
        for p in problems:
            print(f"FAIL     {p}")
        if problems:
            print("\nRun without --check to rebuild.")
            return 1
        print(f"OK       {len(docs)} pdf(s) present and structurally valid")
        return 0

    print("Rendering guideline PDFs (stdlib only, no external "
          "dependencies)\n")
    failures: list[str] = []
    for d in docs:
        # Guard: the PDFs are generated artefacts. docs/, testing/ and
        # proposal_sigma/ all sit outside core/, so this passes -- it is here
        # so that a future relocation into core/ fails loudly.
        config.assert_artefact_path(d.out)

        out = md_file_to_pdf(d.src, d.out, title=d.title, footer=d.footer)
        size_kb = out.stat().st_size / 1024
        problems = verify_pdf(out)
        status = "ok" if not problems else "PROBLEM"
        rel_src = d.src.relative_to(config.REPO_ROOT).as_posix()
        rel_out = out.relative_to(config.REPO_ROOT).as_posix()
        print(f"  {status:<8} {rel_src}  ->  {rel_out}  ({size_kb:.0f} kB)")
        for p in problems:
            print(f"           {p}")
        failures += problems

    for w in all_warnings:
        print(f"\nWARNING  {w}")

    # Characters the Latin-1 encoder could not represent and for which no
    # transliteration exists. They became '?' in the PDF. Reported rather
    # than swallowed: silent character substitution in a document whose job
    # is to be precise is a defect, not a cosmetic issue.
    if pdfwriter.UNMAPPED:
        print("\nWARNING  characters lost to Latin-1 (rendered as '?'):")
        for ch, count in sorted(pdfwriter.UNMAPPED.items(),
                                key=lambda kv: -kv[1]):
            print(f"           U+{ord(ch):04X} {ch!r} x{count}")
        print("           Add a mapping to pdfwriter._TRANSLIT, or use "
              "ASCII in the source.")

    if failures:
        print("\nAt least one PDF failed structural verification. Do not "
              "circulate it.", file=sys.stderr)
        return 1

    print("\nAll guideline PDFs written. The markdown sources remain the "
          "single source of truth --\nedit those, then rerun this tool. Do "
          "not edit a PDF.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
