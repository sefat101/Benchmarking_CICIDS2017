"""The 5-seed experiment runner. Every number in the thesis comes from here.

    python -m core.tools.run_experiment --smoke          # fast plumbing check
    python -m core.tools.run_experiment                  # the real sweep
    python -m core.tools.run_experiment --permute-columns   # the H1 test

WHAT IT DOES
------------
For every (protocol, seed) cell it builds the split ONCE, fits the scaler on
the training indices of that split ONCE, and then trains every requested
model inside that cell. Loop order is deliberate and load-bearing:

    for protocol:
        for seed:
            split   = protocol.build_split(...)       <-- once per cell
            scaler  = preprocessing.fit_scaler_on_train(X, split['train'])
            for model:
                train / predict / evaluate / save

Inverting it -- models outside, splits inside -- would give each model its
own split object. Even with identical seeds that is a promise rather than a
guarantee, and the moment anything about split construction becomes
stateful the comparison quietly becomes between-splits instead of
between-architectures. This way every model in a cell provably sees the
same rows, scaled by the same statistics, weighted by the same balancing.

WHICH EVALUATION RULES THIS FILE STRUCTURALLY ENFORCES
------------------------------------------------------
1. Thresholds are calibrated on validation, never test. This file never
   touches a threshold; it hands (y_val, proba_val, y_test, proba_test) to
   metrics.evaluate, which calibrates on val, freezes, and applies to test.
   metrics.calibrate_threshold raises if handed anything but val.
2. Five seeds, mean +/- std always. The runner writes one result per seed
   and never averages anything; aggregate.py does the averaging and refuses
   to print a bare mean.
3. No improvement claim on the random split. is_claim_surface comes from the
   SplitManifest and is written into every result, and metrics.evaluate
   attaches a non-claim warning to every random-protocol result.
4. No ordering claim within one standard deviation. Not this file's job --
   this file makes no ordering statement at all.
5. Any change applied to one model is applied to all. One split, one scaler,
   one balancing strategy, one training loop, one train_cfg per sweep. The
   balancing strategy is a single sweep-wide argument and is printed at the
   top of every run so it cannot be varied per model without it showing.

WHAT IT REFUSES TO DO
---------------------
* It refuses to let a crashed run vanish. A model that raises gets a
  FAILED.txt containing the traceback, the sweep continues, and the process
  exits nonzero with a loud list of every failure. A missing row in the
  results table must never be indistinguishable from a row that was never
  requested.
* It refuses to write permutation-test runs into the same directories as the
  main sweep. --permute-columns is a FALSIFICATION TEST, not a headline
  result; mixing the two would overwrite the main table with the diagnostic.
  Permuted runs go to '{protocol}__permuted' (see --tag).
* It refuses to make --smoke results look reportable. Smoke runs subsample
  the data and truncate training; they check plumbing and nothing else.
* It refuses to fall back from the grouped protocol to the random one.
  protocol.build_split raises when metadata is absent, and that exception is
  not caught here.

PROVENANCE: this module measures model performance and writes it verbatim.
It computes no summary statistic and makes no claim. Every statement in the
printed output about what a number means is labelled.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from core import config
from core.common import balancing, metrics, model_utils, preprocessing, protocol
from core.common.feature_groups import group_index_map
from core.tools.build_dataset import (
    DATASET_MANIFEST_FILE, FEATURE_ORDER_FILE, META_CSV_FILE,
    META_PARQUET_FILE, X_FILE, Y_FILE,
)

# --------------------------------------------------------------------------
# Per-run artefact names. aggregate.py and build_journal_outputs.py import
# these from here so a rename cannot desynchronise writer from readers.
# --------------------------------------------------------------------------
RESULT_FILE = "result.json"
TRAIN_LOG_FILE = "train_log.json"
SPLIT_MANIFEST_FILE = "split_manifest.json"
RUN_MANIFEST_FILE = "run_manifest.json"
FAILED_FILE = "FAILED.txt"
PROBA_VAL_FILE = "proba_val.npy"
PROBA_TEST_FILE = "proba_test.npy"
Y_VAL_FILE = "y_val.npy"
Y_TEST_FILE = "y_test.npy"
GATE_MATRIX_FILE = "gate_matrix.npy"
GATE_GROUPS_FILE = "gate_groups.json"

#: Fixed, and deliberately NOT the run seed. The whole point of the H1 test
#: is that every model faces the SAME column permutation, so that any
#: degradation is attributable to the architecture's locality assumption and
#: not to one model having drawn an unlucky ordering. Recorded in every run
#: manifest alongside the permutation itself.
PERMUTATION_SEED = 20240617

#: Smoke-mode constants. Also fixed rather than seed-derived, so that a smoke
#: sweep is comparable with itself across models.
SMOKE_SEED = 12345
SMOKE_ROWS = 50_000
SMOKE_EPOCHS = 2
SMOKE_MIN_PER_CLASS = 50

BANNER = "!" * 74


# --------------------------------------------------------------------------
# Environment provenance
# --------------------------------------------------------------------------
def git_state() -> dict[str, Any]:
    """Commit hash and dirty flag. Tolerates git being absent entirely."""
    out: dict[str, Any] = {"commit": None, "dirty": None, "error": None}
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"],
                           cwd=str(config.REPO_ROOT), capture_output=True,
                           text=True, timeout=15)
        if r.returncode == 0:
            out["commit"] = r.stdout.strip()
        else:
            out["error"] = r.stderr.strip()[:300]
        s = subprocess.run(["git", "status", "--porcelain"],
                           cwd=str(config.REPO_ROOT), capture_output=True,
                           text=True, timeout=15)
        if s.returncode == 0:
            out["dirty"] = bool(s.stdout.strip())
    except Exception as exc:               # git missing, not a repo, timeout
        out["error"] = f"{type(exc).__name__}: {exc}"
    return out


def library_versions() -> dict[str, str | None]:
    vers: dict[str, str | None] = {
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "numpy": np.__version__,
        "pandas": pd.__version__,
    }
    try:
        import sklearn
        vers["sklearn"] = sklearn.__version__
    except Exception:
        vers["sklearn"] = None
    return vers


def device_description(device: torch.device) -> dict[str, Any]:
    d: dict[str, Any] = {"device": str(device), "cuda_available":
                         bool(torch.cuda.is_available())}
    if device.type == "cuda" and torch.cuda.is_available():
        i = device.index if device.index is not None else torch.cuda.current_device()
        try:
            d["name"] = torch.cuda.get_device_name(i)
            cap = torch.cuda.get_device_capability(i)
            d["compute_capability"] = f"sm_{cap[0]}{cap[1]}"
            d["total_vram_bytes"] = int(
                torch.cuda.get_device_properties(i).total_memory)
        except Exception as exc:
            d["probe_error"] = f"{type(exc).__name__}: {exc}"
    return d


def jsonable(obj: Any) -> Any:
    """Make shape configs and similar JSON-writable without losing content."""
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return jsonable(obj.tolist())
    if isinstance(obj, Path):
        return str(obj)
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    return repr(obj)


# --------------------------------------------------------------------------
# Dataset loading
# --------------------------------------------------------------------------
def load_dataset(data_dir: Path, mmap: bool = False
                 ) -> tuple[np.ndarray, np.ndarray, pd.DataFrame | None,
                            list[str], dict[str, Any]]:
    """Load X, y, the feature order, and the metadata table if it exists."""
    data_dir = Path(data_dir)
    x_path, y_path = data_dir / X_FILE, data_dir / Y_FILE
    order_path = data_dir / FEATURE_ORDER_FILE
    for p in (x_path, y_path, order_path):
        if not p.exists():
            raise FileNotFoundError(
                f"{p} not found. Build the dataset first:\n"
                "  python -m core.tools.build_dataset")

    X = np.load(x_path, mmap_mode="r" if mmap else None)
    y = np.load(y_path).astype(np.int64)
    feature_order: list[str] = json.loads(order_path.read_text(encoding="utf-8"))

    if X.shape[0] != y.shape[0]:
        raise RuntimeError(f"X has {X.shape[0]} rows, y has {y.shape[0]}")
    if X.shape[1] != len(feature_order):
        raise RuntimeError(
            f"X has {X.shape[1]} columns but {FEATURE_ORDER_FILE} lists "
            f"{len(feature_order)} names. These MUST match -- sigma resolves "
            "its feature groups by name against this list, so a mismatch "
            "would hand it the wrong columns while still training happily.")

    man_path = data_dir / DATASET_MANIFEST_FILE
    manifest: dict[str, Any] = (
        json.loads(man_path.read_text(encoding="utf-8"))
        if man_path.exists() else {})

    meta = load_metadata(data_dir, manifest)
    return X, y, meta, feature_order, manifest


def load_metadata(data_dir: Path, manifest: dict[str, Any]
                  ) -> pd.DataFrame | None:
    """Read meta.parquet, or meta.csv if that is what was written."""
    parquet = data_dir / META_PARQUET_FILE
    csv = data_dir / META_CSV_FILE
    if parquet.exists():
        meta = pd.read_parquet(parquet)
    elif csv.exists():
        meta = pd.read_csv(csv)
    else:
        if manifest.get("has_metadata"):
            raise FileNotFoundError(
                f"{DATASET_MANIFEST_FILE} says metadata exists but neither "
                f"{META_PARQUET_FILE} nor {META_CSV_FILE} is present in "
                f"{data_dir}.")
        return None
    meta = meta.reset_index(drop=True)
    if "timestamp" in meta.columns:
        meta["timestamp"] = pd.to_datetime(meta["timestamp"], errors="coerce")
    return meta


# --------------------------------------------------------------------------
# Smoke subsampling
# --------------------------------------------------------------------------
def smoke_indices(y: np.ndarray, n_target: int = SMOKE_ROWS,
                  seed: int = SMOKE_SEED,
                  min_per_class: int = SMOKE_MIN_PER_CLASS) -> np.ndarray:
    """Stratified subsample for --smoke. Fixed seed, identical for all models.

    Proportional per class, with a floor so the rare classes do not vanish
    and leave the grouped split with empty folds. The floor DISTORTS the
    class prevalence, which is exactly why a smoke run is not reportable:
    benign prevalence, and therefore FPR, mean something different here.
    """
    rng = np.random.default_rng(seed)
    n_total = len(y)
    keep: list[np.ndarray] = []
    for c in range(config.N_CLASSES):
        ids = np.flatnonzero(y == c)
        if len(ids) == 0:
            continue
        share = int(round(n_target * len(ids) / max(n_total, 1)))
        k = max(share, min(min_per_class, len(ids)))
        k = min(k, len(ids))
        keep.append(rng.choice(ids, size=k, replace=False))
    return np.sort(np.concatenate(keep)) if keep else np.array([], dtype=np.int64)


# --------------------------------------------------------------------------
# Scaling
# --------------------------------------------------------------------------
def transform_chunked(scaler: preprocessing.Standardiser, X: np.ndarray,
                      idx: np.ndarray, chunk: int = 200_000) -> np.ndarray:
    """Apply a fitted scaler to X[idx] in row blocks.

    Standardiser.transform promotes to float64 internally and copies once for
    the log1p, so transforming ~1.7M rows in one call allocates roughly 2 GB
    of temporaries. Chunking bounds that to `chunk` rows at a time. The
    arithmetic is unchanged -- the scaler is per-column and stateless at
    transform time, so block-wise and whole-array application give the same
    result.
    """
    idx = np.asarray(idx)
    out = np.empty((len(idx), X.shape[1]), dtype=np.float32)
    for i in range(0, len(idx), chunk):
        sl = idx[i:i + chunk]
        out[i:i + chunk] = scaler.transform(np.asarray(X[sl]))
    return out


# --------------------------------------------------------------------------
# Gate matrix (SIGMA / gated_mlp interpretability artefact)
# --------------------------------------------------------------------------
@torch.no_grad()
def compute_gate_matrix(model: model_utils.NIDSModel, X_val: np.ndarray,
                        y_val: np.ndarray, device: torch.device,
                        batch_size: int = 4096) -> np.ndarray:
    """Mean gate weight per (class, group), computed on VALIDATION.

    Validation, not test, on purpose: this is an explanation artefact that
    gets looked at and iterated on, and anything looked at repeatedly on test
    stops being a held-out set. It does not enter any metric.

    Returns (N_CLASSES, n_groups) with NaN rows for classes absent from val.
    """
    n_groups = int(getattr(model, "n_groups"))
    acc = np.zeros((config.N_CLASSES, n_groups), dtype=np.float64)
    cnt = np.zeros(config.N_CLASSES, dtype=np.int64)
    for i in range(0, len(X_val), batch_size):
        xb = torch.from_numpy(
            np.ascontiguousarray(X_val[i:i + batch_size])).float().to(device)
        w = model.gate_weights(xb).detach().cpu().numpy()
        yb = y_val[i:i + batch_size]
        for c in range(config.N_CLASSES):
            m = yb == c
            if m.any():
                acc[c] += w[m].sum(axis=0)
                cnt[c] += int(m.sum())
    out = np.full((config.N_CLASSES, n_groups), np.nan, dtype=np.float64)
    nz = cnt > 0
    out[nz] = acc[nz] / cnt[nz][:, None]
    return out.astype(np.float32)


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    all_models = model_utils.available_models()
    ap = argparse.ArgumentParser(
        prog="python -m core.tools.run_experiment",
        description=(
            "Train every requested model on every requested (protocol, seed) "
            "cell, evaluate with a validation-calibrated frozen threshold, "
            "and write one auditable result directory per run."),
        epilog=(
            "Results land in RUNS/{protocol}/{model}/seed{seed}/. Aggregate "
            "them with:  python -m core.tools.aggregate"),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument(
        "--models", nargs="+", default=all_models, metavar="NAME",
        help=f"models to run. Registered: {', '.join(all_models)}")
    ap.add_argument(
        "--protocols", nargs="+", default=["random", "nearduplicate_temporal"], metavar="P",
        help="split protocols. 'nearduplicate_temporal' or 'grouped' is the claim surface; "
             "'random' is a saturated reference that cannot host an improvement claim "
             f"(config.NON_CLAIM_PROTOCOLS={list(config.NON_CLAIM_PROTOCOLS)})")
    ap.add_argument(
        "--seeds", nargs="+", type=int, default=list(config.SEEDS), metavar="S",
        help="random seeds. The evaluation rules require all 5; running fewer "
             "makes every affected row INCOMPLETE in the aggregated table")
    ap.add_argument(
        "--balancing", default="effective",
        choices=["none", "inverse", "effective", "sampler"],
        help="class-imbalance strategy. ONE choice applies to every model in "
             "the sweep -- it is a property of the experiment, not of a model")
    ap.add_argument(
        "--data-dir", type=Path, default=config.DATA_INTERIM,
        help="directory containing X.npy, y.npy and feature_order.json")
    ap.add_argument(
        "--out", type=Path, default=config.RUNS,
        help="root directory for run artefacts")
    ap.add_argument(
        "--device", default=None,
        help="torch device string, e.g. 'cuda', 'cuda:0', 'cpu'. Default: "
             "cuda when available, else cpu")
    ap.add_argument(
        "--epochs", type=int, default=None,
        help="override number of training epochs (default from config.SHARED_TRAIN or 2 if smoke)")
    ap.add_argument(
        "--max-rows", type=int, default=None,
        help="subsample stratified rows for faster execution while preserving class ratios")
    ap.add_argument(
        "--smoke", action="store_true",
        help=f"fast end-to-end plumbing check: stratified subsample to about "
             f"{SMOKE_ROWS:,} rows and {SMOKE_EPOCHS} epochs. NOT REPORTABLE "
             "-- it changes class prevalence and truncates training")
    ap.add_argument(
        "--permute-columns", action="store_true",
        help="apply one FIXED random permutation to the column order before "
             "group_idx is built. This is the pre-registered H1 falsification "
             "test: models that assume column adjacency (cnn1d, cnn_rnn, "
             "cnn_lstm, cnn_gru) are expected to degrade, name-resolved "
             "models (sigma) are not. Runs are written under a separate tag "
             "so they cannot overwrite the main table")
    ap.add_argument(
        "--tag", default=None, metavar="SUFFIX",
        help="append '__SUFFIX' to the protocol directory name, keeping a "
             "variant sweep separate from the main one. --permute-columns "
             "implies --tag permuted unless a tag is given")
    ap.add_argument(
        "--save-proba", action="store_true",
        help="also save proba_val/proba_test and their labels as .npy. "
             "Required by build_journal_outputs.py to recompute the "
             "FPR-vs-recall curve. Costs roughly n_rows * 10 * 4 bytes per "
             "run, so it is off by default")
    ap.add_argument(
        "--mmap", action="store_true",
        help="memory-map X.npy instead of reading it into RAM. Ignored in "
             "effect when --smoke or --permute-columns is set, since both "
             "materialise a modified copy of the matrix")
    ap.add_argument(
        "--force", action="store_true",
        help="re-run and overwrite runs whose result.json already exists")
    ap.add_argument(
        "--quiet", action="store_true",
        help="suppress the per-epoch training print from the shared loop")
    return ap


# --------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    started = time.time()
    config.ensure_dirs()

    registered = model_utils.available_models()
    unknown = [m for m in args.models if m not in registered]
    if unknown:
        raise SystemExit(
            f"unknown model(s): {unknown}\nRegistered: {registered}")

    device = (torch.device(args.device) if args.device
              else torch.device("cuda" if torch.cuda.is_available() else "cpu"))

    tag = args.tag or ("permuted" if args.permute_columns else None)
    out_root = config.assert_artefact_path(Path(args.out))

    train_cfg: dict[str, Any] | None = None
    if args.epochs is not None:
        train_cfg = {"epochs": args.epochs}
    elif args.smoke:
        train_cfg = {"epochs": SMOKE_EPOCHS}

    # ---- header --------------------------------------------------------
    print("=" * 74)
    print("RUN EXPERIMENT")
    print("=" * 74)
    print(f"models      : {', '.join(args.models)}")
    print(f"protocols   : {', '.join(args.protocols)}")
    print(f"seeds       : {args.seeds}")
    print(f"device      : {device}")
    print(f"out         : {out_root}")
    if tag:
        print(f"tag         : __{tag}  (variant sweep, separate directories)")
    print()
    print("-" * 74)
    print(f"BALANCING STRATEGY FOR THIS ENTIRE SWEEP: {args.balancing!r}")
    print("Evaluation rule 5: one strategy applies to ALL models here. It is")
    print("resolved by common/balancing.resolve_balancing and handed to the")
    print("single shared training loop, so no model can choose its own. A")
    print("table that mixes balancing strategies measures the balancing.")
    print("-" * 74)

    if len(args.seeds) < len(config.SEEDS):
        print()
        print(BANNER)
        print(f"!! {len(args.seeds)} seed(s) requested, but the evaluation rules")
        print(f"   require {len(config.SEEDS)} (config.SEEDS = {list(config.SEEDS)}).")
        print("   Every affected row will be marked INCOMPLETE by aggregate.py")
        print("   and may not be described as best.")
        print(BANNER)

    if args.smoke:
        print()
        print(BANNER)
        print("!! SMOKE MODE -- NOT REPORTABLE")
        print(BANNER)
        print(f"Subsampling to about {SMOKE_ROWS:,} rows (stratified, fixed seed")
        print(f"{SMOKE_SEED}, floor of {SMOKE_MIN_PER_CLASS} per class) and "
              f"training for {SMOKE_EPOCHS} epochs.")
        print("The per-class floor changes class prevalence, so FPR and")
        print("accuracy mean something different here than in a full run. The")
        print("grouped split is also built over fragmented episodes. This mode")
        print("checks that the pipeline runs end to end. Nothing else.")
        print(BANNER)

    # ---- data ----------------------------------------------------------
    print()
    print(f"loading dataset from {args.data_dir} ...")
    X, y, meta, feature_order, ds_manifest = load_dataset(
        Path(args.data_dir), mmap=args.mmap)
    print(f"  X {X.shape} {X.dtype}   y {y.shape}   "
          f"metadata: {'yes' if meta is not None else 'NO'}")

    if meta is not None and len(meta) != len(y):
        raise RuntimeError(
            f"metadata has {len(meta)} rows but y has {len(y)}. They must be "
            "positionally aligned -- protocol.build_episodes indexes the "
            "metadata by position.")

    # ---- subsample (before the split, before the permutation) ----------
    smoke_info: dict[str, Any] | None = None
    if args.smoke or args.max_rows:
        n_target = args.max_rows if args.max_rows else SMOKE_ROWS
        sel = smoke_indices(y, n_target=n_target)
        X = np.asarray(X[sel])
        y = y[sel]
        if meta is not None:
            meta = meta.iloc[sel].reset_index(drop=True)
        is_reportable = bool(not args.smoke and (args.max_rows is None or args.max_rows >= 2_000_000))
        smoke_info = {"n_rows": int(len(y)), "seed": SMOKE_SEED,
                      "epochs": args.epochs if args.epochs else SMOKE_EPOCHS,
                      "min_per_class": SMOKE_MIN_PER_CLASS,
                      "reportable": is_reportable}
        print(f"  subsample -> {len(y):,} rows")

    # ---- column permutation (the H1 falsification test) -----------------
    permutation: list[int] | None = None
    if args.permute_columns:
        rng = np.random.default_rng(PERMUTATION_SEED)
        perm = rng.permutation(X.shape[1])
        permutation = [int(i) for i in perm]
        # X and feature_order are permuted TOGETHER so that column j of the
        # matrix still holds the feature named feature_order[j]. group_idx is
        # then rebuilt from the permuted names, which is what makes this a
        # test of the architectures rather than a corruption of the data.
        X = np.asarray(X)[:, perm]
        feature_order = [feature_order[i] for i in perm]
        print()
        print("-" * 74)
        print("COLUMN PERMUTATION APPLIED (H1 falsification test)")
        print(f"  fixed permutation seed: {PERMUTATION_SEED} (NOT the run seed,")
        print("  so every model in every cell faces the SAME ordering)")
        # Derived from the registry, not hardcoded: a model added later would
        # otherwise be silently absent from the expectation below, and an
        # expectation written after seeing which models moved is not a test.
        _claims, _no_claim = model_utils.partition_by_permutation_claim(
            list(args.models))
        print("  Expected behaviour, stated as an expectation and not a result:")
        if _no_claim:
            print(f"    {' / '.join(_no_claim)} do not declare")
            print("      CLAIMS_PERMUTATION_INVARIANCE and are expected to")
            print("      degrade if their inductive bias depends on column")
            print("      adjacency;")
        if _claims:
            print(f"    {' / '.join(_claims)} declare")
            print("      CLAIMS_PERMUTATION_INVARIANCE and are expected not to,")
            print("      beyond retraining noise.")
        print("  If the adjacency-dependent models do NOT degrade, H1 is")
        print("  falsified and the motivation for SIGMA weakens. Report that")
        print("  outcome.")
        print("-" * 74)

    # ---- feature groups -------------------------------------------------
    group_idx = group_index_map(feature_order)
    n_features = int(X.shape[1])
    nonempty = {g: len(v) for g, v in group_idx.items() if v}
    print(f"  feature groups: {len(nonempty)} non-empty, covering "
          f"{sum(nonempty.values())} of {n_features} columns")
    empty = [g for g, v in group_idx.items() if not v]
    if empty:
        print(f"  NOTE: empty group(s) {empty} -- sigma drops these and "
              "records it.")

    if meta is not None:
        meta = meta.copy()
        meta["label_idx"] = y          # from y.npy, so the two cannot disagree

    git = git_state()
    libs = library_versions()
    dev_desc = device_description(device)
    print(f"  git commit: {git['commit']}"
          + ("  (WORKING TREE DIRTY)" if git.get("dirty") else ""))

    # ---- sweep ----------------------------------------------------------
    failures: list[dict[str, Any]] = []
    skipped: list[str] = []
    completed = 0

    for proto in args.protocols:
        proto_dir_name = f"{proto}__{tag}" if tag else proto
        for seed in args.seeds:
            print()
            print("=" * 74)
            print(f"CELL  protocol={proto}  seed={seed}")
            print("=" * 74)

            # --- one split for the whole cell -------------------------
            t_split = time.time()
            idx, split_man = protocol.build_split(
                proto, y, meta, seed, X=X, feature_order=feature_order)
            print(f"  split built in {time.time() - t_split:.1f}s   "
                  f"train {len(idx['train']):,}  val {len(idx['val']):,}  "
                  f"test {len(idx['test']):,}")
            if split_man.n_groups is not None:
                print(f"  groups: {split_man.n_groups:,} "
                      f"({split_man.group_key})")
            print(f"  claim surface: {split_man.is_claim_surface}")
            for w in split_man.warnings:
                print(f"  SPLIT WARNING: {w}")

            is_claim = bool(split_man.is_claim_surface)
            if is_claim and proto in config.NON_CLAIM_PROTOCOLS:
                # Guard against the two sources of truth drifting apart.
                print(BANNER)
                print(f"!! INCONSISTENCY: SplitManifest says protocol {proto!r}")
                print("   is a claim surface, but config.NON_CLAIM_PROTOCOLS")
                print("   lists it as non-claim. Taking the RESTRICTIVE view.")
                print(BANNER)
                is_claim = False
            if tag and is_claim:
                print(f"  NOTE: this is a tagged variant sweep ('__{tag}'). Its "
                      "numbers belong in the diagnostic section, not the "
                      "headline table, whatever the protocol says.")

            # --- one scaler for the whole cell, fit on TRAIN ONLY -------
            # Fit strictly after the split and strictly on train indices.
            # Fitting before the split, or on the full matrix, leaks val/test
            # statistics into the training input. It is a small leak and it is
            # still a leak.
            t_sc = time.time()
            scaler = preprocessing.fit_scaler_on_train(X, idx["train"])
            X_train = transform_chunked(scaler, X, idx["train"])
            X_val = transform_chunked(scaler, X, idx["val"])
            X_test = transform_chunked(scaler, X, idx["test"])
            y_train = y[idx["train"]]
            y_val = y[idx["val"]]
            y_test = y[idx["test"]]
            print(f"  scaler fit on {len(idx['train']):,} train rows and "
                  f"applied to all three splits in {time.time() - t_sc:.1f}s")

            # Resolved once here purely so the cell header can report it; the
            # object actually handed to each model is re-resolved per model
            # below (see the comment there).
            cell_weights, cell_sampler = balancing.resolve_balancing(
                args.balancing, y_train, seed)
            if cell_weights is not None:
                print("  class weights (identical for every model in this "
                      "cell):")
                print("    " + "  ".join(
                    f"{config.CLASSES[i]}={cell_weights[i]:.3g}"
                    for i in range(config.N_CLASSES)))
            elif cell_sampler is not None:
                print("  weighted sampler in force for every model in this cell")
            else:
                print("  no balancing (raw class distribution)")

            # --- models ------------------------------------------------
            for model_name in args.models:
                run_dir = config.assert_artefact_path(
                    out_root / proto_dir_name / model_name / f"seed{seed}")
                result_path = run_dir / RESULT_FILE

                if result_path.exists() and not args.force:
                    msg = (f"{proto_dir_name}/{model_name}/seed{seed}: "
                           "SKIPPED (result.json exists; --force to re-run)")
                    print(f"  {msg}")
                    skipped.append(msg)
                    continue

                print()
                print(f"  --- {model_name}  ({proto_dir_name}, seed {seed}) ---")
                run_dir.mkdir(parents=True, exist_ok=True)
                failed_path = run_dir / FAILED_FILE
                t_run = time.time()

                try:
                    # set_seed BEFORE construction: the shared training loop
                    # also seeds, but it does so after the model has already
                    # been built, so weight initialisation would otherwise
                    # depend on whatever ran before it in this process.
                    model_utils.set_seed(seed)
                    model = model_utils.build_model(
                        model_name, n_features, config.N_CLASSES, group_idx)
                    print(f"      parameters: {model.n_params():,}   "
                          f"input kind: {model.INPUT_KIND}   "
                          f"aux weight: {model.AUX_LOSS_WEIGHT}")

                    # Re-resolved per model so that a WeightedRandomSampler
                    # gets a FRESH generator seeded identically. A sampler is
                    # stateful: reusing one object across models would give
                    # the second model a different draw order from the first,
                    # which is precisely the kind of silent asymmetry rule 5
                    # exists to prevent.
                    class_weights, sampler = balancing.resolve_balancing(
                        args.balancing, y_train, seed)

                    log = model_utils.TrainLog(
                        model=model_name, protocol=proto, seed=seed,
                        n_params=model.n_params())
                    model, log = model_utils.train_model(
                        model, X_train, y_train, X_val, y_val,
                        seed=seed, protocol=proto,
                        class_weights=class_weights, sampler=sampler,
                        device=device, train_cfg=train_cfg, log=log,
                        verbose=not args.quiet)

                    proba_val = model_utils.predict_proba(model, X_val, device)
                    proba_test = model_utils.predict_proba(model, X_test, device)

                    # Calibrate on val, freeze, apply to test -- all inside
                    # metrics.evaluate, which raises if handed anything but
                    # validation for calibration.
                    res = metrics.evaluate(
                        model_name, proto, seed, is_claim,
                        y_val, proba_val, y_test, proba_test)

                    # ---- write artefacts ---------------------------
                    config.assert_artefact_path(result_path).write_text(
                        json.dumps(res.to_dict(), indent=2), encoding="utf-8")
                    log.to_json(run_dir / TRAIN_LOG_FILE)
                    split_man.save(run_dir / SPLIT_MANIFEST_FILE)

                    gate_saved = False
                    if hasattr(model, "gate_weights") and hasattr(model, "n_groups"):
                        try:
                            gm = compute_gate_matrix(model, X_val, y_val, device)
                            np.save(config.assert_artefact_path(
                                run_dir / GATE_MATRIX_FILE), gm)
                            config.assert_artefact_path(
                                run_dir / GATE_GROUPS_FILE).write_text(
                                json.dumps(jsonable(
                                    getattr(model, "group_names", [])), indent=2),
                                encoding="utf-8")
                            gate_saved = True
                        except Exception as exc:
                            log.notes.append(
                                f"gate matrix not saved: {type(exc).__name__}: {exc}")
                            log.to_json(run_dir / TRAIN_LOG_FILE)
                            print(f"      gate matrix FAILED (non-fatal): {exc}")

                    if args.save_proba:
                        np.save(config.assert_artefact_path(
                            run_dir / PROBA_VAL_FILE), proba_val)
                        np.save(config.assert_artefact_path(
                            run_dir / PROBA_TEST_FILE), proba_test)
                        np.save(config.assert_artefact_path(
                            run_dir / Y_VAL_FILE), y_val)
                        np.save(config.assert_artefact_path(
                            run_dir / Y_TEST_FILE), y_test)

                    run_manifest: dict[str, Any] = {
                        "model": model_name,
                        "protocol": proto,
                        "protocol_dir": proto_dir_name,
                        "tag": tag,
                        "seed": seed,
                        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                        "argv": list(sys.argv),
                        "git": git,
                        "versions": libs,
                        "device": dev_desc,
                        "balancing_strategy": args.balancing,
                        "balancing_applies_to": "every model in this sweep",
                        "permute_columns": bool(args.permute_columns),
                        "permutation_seed": (
                            PERMUTATION_SEED if args.permute_columns else None),
                        "permutation": permutation,
                        "smoke": smoke_info,
                        "reportable": bool(not args.smoke),
                        "is_claim_surface": is_claim,
                        "n_features": n_features,
                        "n_classes": int(config.N_CLASSES),
                        "feature_order": list(feature_order),
                        "group_sizes": {g: len(v) for g, v in group_idx.items()},
                        "model_shape_cfg": jsonable(
                            getattr(model, "shape_cfg", {})),
                        "n_params": int(model.n_params()),
                        "shared_train": jsonable(dict(config.SHARED_TRAIN)),
                        "train_cfg_override": jsonable(train_cfg),
                        "data_dir": str(Path(args.data_dir).resolve()),
                        "data_fingerprint": {
                            "split_manifest_y_fingerprint":
                                split_man.data_fingerprint,
                            "dataset_x_sha256": ds_manifest.get("x_sha256"),
                            "dataset_y_sha256": ds_manifest.get("y_sha256"),
                            "dataset_n_rows": ds_manifest.get("n_rows"),
                            "drop_exact_duplicates":
                                ds_manifest.get("drop_exact_duplicates"),
                            "join_agreement": ds_manifest.get("join_agreement"),
                        },
                        "split_sizes": {
                            "train": int(len(idx["train"])),
                            "val": int(len(idx["val"])),
                            "test": int(len(idx["test"])),
                        },
                        "saved_probabilities": bool(args.save_proba),
                        "saved_gate_matrix": gate_saved,
                        "wall_seconds": float(time.time() - t_run),
                    }
                    config.assert_artefact_path(
                        run_dir / RUN_MANIFEST_FILE).write_text(
                        json.dumps(run_manifest, indent=2), encoding="utf-8")

                    # A previous failure for this exact run is now stale.
                    if failed_path.exists():
                        failed_path.unlink()

                    completed += 1
                    print(f"      macro-F1 {res.macro_f1:.4f}   "
                          f"FPR@{config.TARGET_ATTACK_RECALL:.0%} recall "
                          f"{res.fpr_at_target_recall:.4f}   "
                          f"realised recall {res.attack_recall_realised:.4f}")
                    if not res.operating_point_transferred:
                        print("      NOTE: operating point did not transfer to "
                              "test; this FPR is not directly comparable "
                              "across models without stating the realised "
                              "recall alongside it.")
                    print(f"      -> {run_dir}  ({time.time() - t_run:.1f}s)")

                except Exception:
                    tb = traceback.format_exc()
                    rec = {
                        "model": model_name, "protocol": proto,
                        "protocol_dir": proto_dir_name, "seed": seed,
                        "run_dir": str(run_dir),
                        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                        "traceback": tb,
                    }
                    failures.append(rec)
                    run_dir.mkdir(parents=True, exist_ok=True)
                    config.assert_artefact_path(failed_path).write_text(
                        "THIS RUN FAILED. It has no result.json and therefore "
                        "no row in the results table.\n"
                        "A missing row must never be mistaken for a row that "
                        "was never requested.\n\n"
                        f"model    : {model_name}\n"
                        f"protocol : {proto} (dir {proto_dir_name})\n"
                        f"seed     : {seed}\n"
                        f"time     : {rec['timestamp_utc']}\n"
                        f"argv     : {sys.argv}\n\n" + tb,
                        encoding="utf-8")
                    print(f"      FAILED -- traceback written to {failed_path}")
                    print("      continuing with the next model.")

            # free the cell's scaled copies before building the next cell
            del X_train, X_val, X_test

    # ---- summary --------------------------------------------------------
    print()
    print("=" * 74)
    print("SWEEP SUMMARY")
    print("=" * 74)
    print(f"completed : {completed}")
    print(f"skipped   : {len(skipped)}")
    print(f"failed    : {len(failures)}")
    print(f"wall time : {time.time() - started:.1f}s")

    if skipped:
        print()
        print("Skipped (result.json already present; --force to re-run):")
        for s in skipped:
            print(f"  {s}")

    if failures:
        print()
        print(BANNER)
        print("!! FAILED RUNS -- THESE HAVE NO ROW IN THE RESULTS TABLE")
        print(BANNER)
        for f in failures:
            first = [ln for ln in f["traceback"].strip().splitlines() if ln.strip()]
            print(f"  {f['protocol_dir']}/{f['model']}/seed{f['seed']}")
            print(f"      {first[-1] if first else 'unknown error'}")
            print(f"      full traceback: {Path(f['run_dir']) / FAILED_FILE}")
        print()
        print("Do not aggregate and report as if these had not been requested.")
        print("Either fix and re-run them, or state in the paper that the cell")
        print("is missing and why. aggregate.py will mark the affected rows")
        print("INCOMPLETE and refuse to call them best.")
        print(BANNER)

    if args.smoke:
        print()
        print(BANNER)
        print("!! These are SMOKE results. Not reportable. Subsampled data,")
        print(f"   {SMOKE_EPOCHS} epochs, distorted class prevalence.")
        print(BANNER)

    print()
    print("next:  python -m core.tools.aggregate")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
