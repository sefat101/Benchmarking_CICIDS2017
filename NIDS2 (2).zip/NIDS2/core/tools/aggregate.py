"""Aggregate RUNS/ into the results tables. The only place a mean is printed.

    python -m core.tools.aggregate
    python -m core.tools.aggregate --latex
    python -m core.tools.aggregate --claim-protocol grouped --baseline ann

WHAT IT EMITS  (into config.RESULTS)
------------------------------------
    results.md    markdown tables, one section per protocol
    results.csv   LONG format: one row per (protocol, model, seed, metric)
    results.tex   booktabs tables, only with --latex
and the same tables on stdout.

WHICH EVALUATION RULES THIS FILE STRUCTURALLY ENFORCES
------------------------------------------------------
2. Five seeds, mean +/- std, always. Every cell goes through
   metrics.format_mean_std, which refuses to render a bare mean and which
   annotates any cell built from fewer than len(config.SEEDS) seeds. A row
   missing seeds is marked INCOMPLETE (n/5) and is excluded from being
   described as best.
3. No improvement claim on the random split. Every table whose protocol is
   in config.NON_CLAIM_PROTOCOLS carries a banner saying so, and
   --claim-protocol REFUSES, by raising, to compute a delta on such a
   protocol.
4. No ordering claim inside one standard deviation. Every ordering statement
   is gated on metrics.separated_by_more_than_one_std. When two models are
   not separated the aggregator prints 'tied within 1 std' and no arrow. It
   has no code path that emits an arrow without that check passing.

WHAT IT REFUSES TO DO
---------------------
* It refuses to hide a crashed run. FAILED.txt markers found under RUNS/ are
  listed in their own section, in the tables' own output, so a cell that
  blew up cannot be mistaken for a cell nobody asked for.
* It refuses to render an absent class as zero. metrics.per_class_recall
  returns NaN for a class with no support in the test fold; this renders it
  as 'absent'. Absent is not the same as failed, and a table that prints 0.0
  for both is lying about which one happened.
* It refuses to average a tagged variant sweep into the main protocol.
  Directories like 'grouped__permuted' are reported as their own,
  clearly-labelled diagnostic sections.

PROVENANCE: every number here is a mean or a standard deviation of values
measured by core/common/metrics.py and written by run_experiment.py. This
module measures nothing itself and adds no constant.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any, Iterable, Sequence

from core import config
from core.common import metrics
from core.tools.run_experiment import FAILED_FILE, RESULT_FILE

ABSENT = "absent"
BANNER = "!" * 74

#: Headline metrics for the main table: (json key, column heading, format,
#: higher_is_better).
MAIN_METRICS: tuple[tuple[str, str, str, bool], ...] = (
    ("fpr_at_target_recall",
     f"FPR @ {config.TARGET_ATTACK_RECALL:.0%} recall", ".4f", False),
    ("macro_f1", "macro-F1", ".4f", True),
    ("accuracy", "accuracy", ".4f", True),
    # Not in the minimal spec, included because metrics.py is explicit that an
    # FPR without the recall it was measured at is meaningless: the threshold
    # is frozen from validation, so the realised test recall drifts and the
    # amount of drift decides whether two FPRs are even comparable.
    ("attack_recall_realised", "realised attack recall", ".4f", True),
)

#: Scalar metrics exported to the long-format CSV.
CSV_SCALARS: tuple[str, ...] = (
    "fpr_at_target_recall", "attack_recall_realised", "macro_f1", "accuracy",
    "benign_prevalence", "threshold", "n_test",
)


class ClaimRefusal(RuntimeError):
    """Raised when asked to compute a claim on a non-claim protocol."""


# --------------------------------------------------------------------------
# Collection
# --------------------------------------------------------------------------
def base_protocol(protocol_key: str) -> str:
    """'grouped__permuted' -> 'grouped'."""
    return protocol_key.split("__", 1)[0]


def tag_of(protocol_key: str) -> str | None:
    return protocol_key.split("__", 1)[1] if "__" in protocol_key else None


def is_non_claim(protocol_key: str) -> bool:
    return base_protocol(protocol_key) in config.NON_CLAIM_PROTOCOLS


def collect(runs_root: Path) -> tuple[dict[str, dict[str, dict[int, dict]]],
                                      list[Path]]:
    """Read every result.json under RUNS/, plus every FAILED.txt marker.

    Layout: RUNS/{protocol_dir}/{model}/seed{N}/result.json
    The protocol DIRECTORY is the grouping key, so a tagged variant sweep
    ('grouped__permuted') never merges into the protocol it was derived from.
    """
    runs_root = Path(runs_root)
    out: dict[str, dict[str, dict[int, dict]]] = {}
    if not runs_root.exists():
        return out, []

    for path in sorted(runs_root.glob(f"*/*/seed*/{RESULT_FILE}")):
        seed_dir = path.parent
        model_dir = seed_dir.parent
        proto_dir = model_dir.parent
        try:
            seed = int(seed_dir.name[len("seed"):])
        except ValueError:
            print(f"  ignoring {seed_dir}: directory name is not 'seed<N>'")
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"  ignoring {path}: unreadable ({type(exc).__name__}: {exc})")
            continue
        # The JSON is authoritative for model/seed; the path is authoritative
        # for the protocol KEY, because the tag lives only in the path.
        model = str(data.get("model", model_dir.name))
        if int(data.get("seed", seed)) != seed:
            print(f"  WARNING: {path} says seed={data.get('seed')} but sits in "
                  f"{seed_dir.name}. Using the directory.")
        out.setdefault(proto_dir.name, {}).setdefault(model, {})[seed] = data

    failed = sorted(runs_root.glob(f"*/*/seed*/{FAILED_FILE}"))
    return out, failed


def order_protocols(keys: Iterable[str]) -> list[str]:
    """Claim surface first, then the saturated reference, then variants."""
    keys = list(keys)

    def rank(k: str) -> tuple[int, str]:
        b = base_protocol(k)
        if tag_of(k):
            return (3, k)
        if b == config.CLAIM_SURFACE:
            return (0, k)
        if b in config.NON_CLAIM_PROTOCOLS:
            return (1, k)
        return (2, k)

    return sorted(keys, key=rank)


# --------------------------------------------------------------------------
# Value extraction
# --------------------------------------------------------------------------
def _f(v: Any) -> float:
    """JSON value -> float, mapping null to NaN."""
    if v is None:
        return float("nan")
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def seeds_of(by_seed: dict[int, dict]) -> list[int]:
    return sorted(by_seed)


def scalar_values(by_seed: dict[int, dict], key: str) -> list[float]:
    return [_f(by_seed[s].get(key)) for s in seeds_of(by_seed)]


def per_class_values(by_seed: dict[int, dict], block: str,
                     class_name: str) -> list[float]:
    return [_f((by_seed[s].get(block) or {}).get(class_name))
            for s in seeds_of(by_seed)]


def all_nan(values: Sequence[float]) -> bool:
    return len(values) > 0 and all(math.isnan(v) for v in values)


def cell(values: Sequence[float], fmt: str = ".4f") -> str:
    """Render one table cell. Never a bare mean; NaN-only renders 'absent'."""
    if len(values) == 0:
        return "n/a (0 seeds)"
    if all_nan(values):
        # Every seed reported NaN: the class had no support in the test fold.
        # metrics.per_class_recall is explicit that this is 'absent', not 0.
        return ABSENT
    return metrics.format_mean_std(list(values), fmt=fmt)


def status_of(by_seed: dict[int, dict]) -> str:
    n = len(by_seed)
    exp = len(config.SEEDS)
    return "complete" if n >= exp else f"INCOMPLETE ({n}/{exp})"


def is_complete(by_seed: dict[int, dict]) -> bool:
    return len(by_seed) >= len(config.SEEDS)


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------
def render_text_table(headers: Sequence[str],
                      rows: Sequence[Sequence[str]]) -> str:
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            widths[i] = max(widths[i], len(c))
    line = "  ".join("-" * w for w in widths)
    out = ["  ".join(h.ljust(widths[i]) for i, h in enumerate(headers)), line]
    for r in rows:
        out.append("  ".join(str(c).ljust(widths[i]) for i, c in enumerate(r)))
    return "\n".join(out)


def render_md_table(headers: Sequence[str],
                    rows: Sequence[Sequence[str]]) -> str:
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def escape_latex(s: str) -> str:
    for a, b in (("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
                 ("$", r"\$"), ("#", r"\#"), ("_", r"\_"), ("{", r"\{"),
                 ("}", r"\}"), ("~", r"\textasciitilde{}"),
                 ("^", r"\textasciicircum{}")):
        s = s.replace(a, b)
    return s.replace("+/-", r"$\pm$")


def render_latex_table(headers: Sequence[str], rows: Sequence[Sequence[str]],
                       caption: str, label: str) -> str:
    cols = "l" + "r" * (len(headers) - 1)
    out = [r"\begin{table}[htbp]", r"\centering",
           f"\\caption{{{escape_latex(caption)}}}",
           f"\\label{{{label}}}",
           f"\\begin{{tabular}}{{{cols}}}", r"\toprule",
           " & ".join(escape_latex(h) for h in headers) + r" \\",
           r"\midrule"]
    for r in rows:
        out.append(" & ".join(escape_latex(str(c)) for c in r) + r" \\")
    out += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    return "\n".join(out)


# --------------------------------------------------------------------------
# Banners
# --------------------------------------------------------------------------
def protocol_banner(protocol_key: str) -> list[str]:
    """The header block printed above every protocol's tables."""
    b = base_protocol(protocol_key)
    tag = tag_of(protocol_key)
    lines = ["=" * 74, f"PROTOCOL: {protocol_key}", "=" * 74]

    if is_non_claim(protocol_key):
        lines += [
            BANNER,
            "!! SATURATED REFERENCE -- NO IMPROVEMENT CLAIM MAY BE MADE HERE",
            BANNER,
            f"'{b}' is listed in config.NON_CLAIM_PROTOCOLS.",
            "It is a stratified random split over individual flows. CICIDS2017",
            "attacks are scripted bursts whose consecutive flows are near-",
            "identical, so this protocol deals near-duplicates into train and",
            "test simultaneously. Scores here measure memorisation, not",
            "generalisation. They are reported for comparison with the",
            "published literature, which overwhelmingly uses this protocol,",
            "and for nothing else. Any sentence of the form 'X improves on Y'",
            "built on these numbers is invalid.",
            BANNER,
        ]
    elif b == config.CLAIM_SURFACE:
        lines += [
            f"CLAIM SURFACE (config.CLAIM_SURFACE = {config.CLAIM_SURFACE!r}).",
            "Episode-grouped, temporally assigned: no burst straddles a split",
            "and no model is trained on traffic postdating its test traffic.",
            "This is the only protocol on which an improvement claim is valid.",
        ]

    if tag:
        lines += [
            "-" * 74,
            f"TAGGED VARIANT SWEEP: '__{tag}'.",
            "This is a diagnostic, not a headline result. It is kept in its",
            "own section precisely so it cannot be averaged into the protocol",
            "it was derived from. If the tag is 'permuted', these runs come",
            "from run_experiment.py --permute-columns, the pre-registered H1",
            "falsification test; compare them against the untagged rows of the",
            "same protocol and report the comparison as a falsification test,",
            "not as a performance result.",
            "-" * 74,
        ]
    return lines


# --------------------------------------------------------------------------
# Tables
# --------------------------------------------------------------------------
def main_table(by_model: dict[str, dict[int, dict]]
               ) -> tuple[list[str], list[list[str]]]:
    headers = ["model"] + [h for _, h, _, _ in MAIN_METRICS] + ["seeds", "status"]
    rows: list[list[str]] = []
    for model in sorted(by_model):
        by_seed = by_model[model]
        row = [model]
        for key, _, fmt, _ in MAIN_METRICS:
            row.append(cell(scalar_values(by_seed, key), fmt))
        row.append(str(len(by_seed)))
        row.append(status_of(by_seed))
        rows.append(row)
    return headers, rows


def per_class_table(by_model: dict[str, dict[int, dict]], block: str
                    ) -> tuple[list[str], list[list[str]]]:
    headers = ["model"] + list(config.CLASSES) + ["status"]
    rows: list[list[str]] = []
    for model in sorted(by_model):
        by_seed = by_model[model]
        row = [model]
        for cname in config.CLASSES:
            row.append(cell(per_class_values(by_seed, block, cname), ".3f"))
        row.append(status_of(by_seed))
        rows.append(row)
    return headers, rows


def transfer_notes(by_model: dict[str, dict[int, dict]]) -> list[str]:
    """Flag runs whose frozen operating point did not transfer to test."""
    notes: list[str] = []
    for model in sorted(by_model):
        bad = [s for s, r in sorted(by_model[model].items())
               if r.get("operating_point_transferred") is False]
        if bad:
            notes.append(
                f"{model}: operating point did NOT transfer on seed(s) {bad}. "
                "The threshold was frozen from validation, so the realised "
                "test recall drifted from the "
                f"{config.TARGET_ATTACK_RECALL:.0%} target. Those FPRs sit at "
                "a different point on the model's own curve and are not "
                "directly comparable with the others without saying so.")
    return notes


# --------------------------------------------------------------------------
# Ordering, gated on the one-std rule
# --------------------------------------------------------------------------
def ranking_lines(by_model: dict[str, dict[int, dict]], metric_key: str,
                  metric_label: str, higher_is_better: bool) -> list[str]:
    """Pairwise ordering statements, each gated on the one-std separation.

    There is no code path here that prints an ordering without
    metrics.separated_by_more_than_one_std returning True first.
    """
    entries: list[tuple[str, float, list[float], bool]] = []
    for model, by_seed in by_model.items():
        vals = scalar_values(by_seed, metric_key)
        m, _, n = metrics.mean_std(vals)
        if n == 0:
            continue
        entries.append((model, m, vals, is_complete(by_seed)))
    if len(entries) < 2:
        return [f"{metric_label}: fewer than two models with results; "
                "nothing to order."]

    entries.sort(key=lambda e: (-e[1] if higher_is_better else e[1]))
    direction = "higher is better" if higher_is_better else "lower is better"
    out = [f"{metric_label} ({direction}), best-first by mean:"]

    for i in range(len(entries) - 1):
        a_name, a_mean, a_vals, _ = entries[i]
        b_name, b_mean, b_vals, _ = entries[i + 1]
        if metrics.separated_by_more_than_one_std(a_vals, b_vals):
            arrow = ">" if higher_is_better else "<"
            out.append(f"  {a_name} {arrow} {b_name}  "
                       f"(separated by more than 1 std)")
        else:
            out.append(f"  {a_name} / {b_name}: tied within 1 std "
                       "-- no ordering claimed")

    top_name, _, top_vals, top_complete = entries[0]
    second_name, _, second_vals, _ = entries[1]
    if not top_complete:
        out.append(
            f"  NO BEST DECLARED: {top_name} has the leading mean but its row "
            f"is INCOMPLETE ({len(by_model[top_name])}/{len(config.SEEDS)} "
            "seeds). An incomplete row may not be described as best.")
    elif metrics.separated_by_more_than_one_std(top_vals, second_vals):
        out.append(f"  BEST on {metric_label}: {top_name} (separated from "
                   f"{second_name} by more than 1 std).")
    else:
        out.append(
            f"  NO BEST DECLARED: {top_name} and {second_name} are tied "
            "within 1 std on this metric. Rule 4 forbids claiming an order "
            "here.")
    return out


# --------------------------------------------------------------------------
# Deltas (only on a claim surface)
# --------------------------------------------------------------------------
def claim_deltas(by_model: dict[str, dict[int, dict]], protocol_key: str,
                 baseline: str) -> list[str]:
    if is_non_claim(protocol_key):
        raise ClaimRefusal(
            f"REFUSING to compute an improvement delta on protocol "
            f"{protocol_key!r}.\n"
            f"Its base protocol {base_protocol(protocol_key)!r} is listed in "
            f"config.NON_CLAIM_PROTOCOLS = {list(config.NON_CLAIM_PROTOCOLS)}."
            "\n\nThat protocol is a stratified random split whose scores are "
            "saturated by burst-level near-duplicates shared between train and "
            "test. A delta computed there measures memorisation, not "
            "generalisation, and no improvement claim may be built on it.\n"
            f"The claim surface is {config.CLAIM_SURFACE!r}. Re-run with "
            f"--claim-protocol {config.CLAIM_SURFACE}.")
    if baseline not in by_model:
        raise ClaimRefusal(
            f"baseline model {baseline!r} has no results under protocol "
            f"{protocol_key!r}. Present: {sorted(by_model)}")

    out = [f"DELTAS vs baseline {baseline!r} on claim surface {protocol_key!r}",
           "Each delta is a difference of means. It is reported as MEANINGFUL "
           "only when",
           "metrics.separated_by_more_than_one_std passes; otherwise the two "
           "rows are tied",
           "within 1 std and rule 4 forbids reading a direction into the sign.",
           ""]
    base_seeds = by_model[baseline]
    if not is_complete(base_seeds):
        out.append(f"  WARNING: the baseline row itself is "
                   f"{status_of(base_seeds)}. Every delta below inherits that.")

    for key, label, fmt, higher in MAIN_METRICS:
        out.append(f"  {label} ({'higher' if higher else 'lower'} is better):")
        b_vals = scalar_values(base_seeds, key)
        b_mean, _, b_n = metrics.mean_std(b_vals)
        if b_n == 0:
            out.append("    baseline has no usable values for this metric.")
            continue
        for model in sorted(by_model):
            if model == baseline:
                continue
            m_vals = scalar_values(by_model[model], key)
            m_mean, _, m_n = metrics.mean_std(m_vals)
            if m_n == 0:
                out.append(f"    {model:<12} no usable values")
                continue
            delta = m_mean - b_mean
            sep = metrics.separated_by_more_than_one_std(m_vals, b_vals)
            flag = ("separated by >1 std" if sep
                    else "TIED WITHIN 1 STD -- not a difference")
            incomplete = ("  [INCOMPLETE: "
                          f"{len(by_model[model])}/{len(config.SEEDS)} seeds]"
                          if not is_complete(by_model[model]) else "")
            out.append(f"    {model:<12} delta {delta:+{fmt}}   {flag}{incomplete}")
        out.append("")
    return out


# --------------------------------------------------------------------------
# CSV
# --------------------------------------------------------------------------
def write_long_csv(all_runs: dict[str, dict[str, dict[int, dict]]],
                   path: Path) -> int:
    path = config.assert_artefact_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["protocol_dir", "base_protocol", "tag", "model", "seed",
                    "is_claim_surface", "operating_point_transferred",
                    "metric", "value"])
        for pkey in order_protocols(all_runs):
            for model in sorted(all_runs[pkey]):
                for seed in seeds_of(all_runs[pkey][model]):
                    r = all_runs[pkey][model][seed]
                    common = [pkey, base_protocol(pkey), tag_of(pkey) or "",
                              model, seed,
                              bool(r.get("is_claim_surface")),
                              r.get("operating_point_transferred")]
                    for key in CSV_SCALARS:
                        w.writerow(common + [key, _f(r.get(key))])
                        n += 1
                    for block in ("per_class_recall_argmax",
                                  "per_class_recall_threshold"):
                        for cname in config.CLASSES:
                            w.writerow(common
                                       + [f"{block}::{cname}",
                                          _f((r.get(block) or {}).get(cname))])
                            n += 1
    return n


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="python -m core.tools.aggregate",
        description=(
            "Read every result.json under RUNS/, group by (protocol, model), "
            "and emit the results tables as markdown, long-format CSV and "
            "stdout. Every cell is mean +/- std over seeds; no bare mean is "
            "ever printed."),
        epilog=(
            "Ordering statements are gated on "
            "metrics.separated_by_more_than_one_std. Models that are not "
            "separated are reported as 'tied within 1 std'."),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--runs", type=Path, default=config.RUNS,
                    help="root directory of run artefacts")
    ap.add_argument("--out", type=Path, default=config.RESULTS,
                    help="where results.md / results.csv / results.tex go")
    ap.add_argument("--latex", action="store_true",
                    help="also emit results.tex with booktabs tables")
    ap.add_argument(
        "--claim-protocol", default=None, metavar="PROTOCOL",
        help="compute improvement deltas against --baseline on this protocol. "
             "REFUSES, by raising, for any protocol in "
             f"config.NON_CLAIM_PROTOCOLS ({list(config.NON_CLAIM_PROTOCOLS)})")
    ap.add_argument("--baseline", default="ann", metavar="MODEL",
                    help="baseline model for --claim-protocol deltas")
    ap.add_argument(
        "--per-class-block", default="argmax",
        choices=["argmax", "threshold", "both"],
        help="which per-class recall to table: closed-set argmax recall, "
             "detection recall at the frozen threshold, or both")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    config.ensure_dirs()

    print(f"scanning {args.runs} ...")
    all_runs, failed_markers = collect(Path(args.runs))
    if not all_runs:
        print(f"no result.json found under {args.runs}.")
        print("Run:  python -m core.tools.run_experiment")
        return 1

    n_runs = sum(len(s) for m in all_runs.values() for s in m.values())
    print(f"found {n_runs} run(s) across {len(all_runs)} protocol "
          f"directory/-ies\n")

    md: list[str] = ["# Results", "",
                     "Every cell is `mean +/- std` over seeds "
                     f"(config.SEEDS = {list(config.SEEDS)}). "
                     "A bare mean is never printed: "
                     "`metrics.format_mean_std` refuses to produce one.",
                     "",
                     "`absent` means the class had no support in the test "
                     "fold, so recall is undefined. It is **not** the same as "
                     "a recall of 0.0, and is deliberately not rendered as "
                     "one.", ""]
    tex: list[str] = []
    stdout: list[str] = []

    blocks = ({"argmax": ["per_class_recall_argmax"],
               "threshold": ["per_class_recall_threshold"],
               "both": ["per_class_recall_argmax",
                        "per_class_recall_threshold"]}[args.per_class_block])
    block_titles = {
        "per_class_recall_argmax":
            "Per-class recall, closed-set argmax rule",
        "per_class_recall_threshold":
            "Per-class DETECTION recall at the frozen threshold",
    }
    block_notes = {
        "per_class_recall_argmax":
            "A flow counts only if the 10-way argmax picked its own class.",
        "per_class_recall_threshold":
            "A flow counts as detected if its attack score cleared the "
            "validation-calibrated frozen threshold, whichever attack class "
            "it was assigned. BENIGN's entry is the fraction correctly NOT "
            "alerted.",
    }

    # ---- one section per protocol directory -----------------------------
    for pkey in order_protocols(all_runs):
        by_model = all_runs[pkey]
        banner = protocol_banner(pkey)
        stdout += [""] + banner + [""]
        md += ["", f"## Protocol: `{pkey}`", ""]
        if is_non_claim(pkey):
            md += ["> **SATURATED REFERENCE -- NO IMPROVEMENT CLAIM MAY BE "
                   "MADE FROM THIS TABLE.**",
                   f"> `{base_protocol(pkey)}` is in "
                   "`config.NON_CLAIM_PROTOCOLS`. It is a stratified random "
                   "split over individual flows, so burst-level near-"
                   "duplicates appear in train and test simultaneously and "
                   "the scores measure memorisation rather than "
                   "generalisation. Reported only for comparability with the "
                   "published literature.", ""]
        elif base_protocol(pkey) == config.CLAIM_SURFACE:
            md += [f"> Claim surface (`config.CLAIM_SURFACE = "
                   f"{config.CLAIM_SURFACE!r}`). Episode-grouped, temporally "
                   "assigned. This is the only protocol on which an "
                   "improvement claim is valid.", ""]
        if tag_of(pkey):
            md += [f"> **Tagged variant sweep `__{tag_of(pkey)}` -- "
                   "diagnostic, not a headline result.** Kept separate so it "
                   "cannot be averaged into the protocol it derives from.", ""]

        headers, rows = main_table(by_model)
        stdout += ["Main table", "", render_text_table(headers, rows), ""]
        md += ["### Main table", "", render_md_table(headers, rows), ""]
        if args.latex:
            tex.append(render_latex_table(
                headers, rows,
                caption=(f"Headline metrics under the {pkey} protocol, "
                         f"mean $\\pm$ std over {len(config.SEEDS)} seeds."
                         + (" Saturated reference; no improvement claim is "
                            "made from this table." if is_non_claim(pkey) else "")),
                label=f"tab:main-{pkey.replace('_', '-')}"))

        notes = transfer_notes(by_model)
        if notes:
            stdout += ["Operating-point transfer notes:"] \
                + [f"  {n}" for n in notes] + [""]
            md += ["**Operating-point transfer notes**", ""] \
                + [f"- {n}" for n in notes] + [""]

        for block in blocks:
            headers, rows = per_class_table(by_model, block)
            title = block_titles[block]
            stdout += [title, block_notes[block], "",
                       render_text_table(headers, rows), ""]
            md += [f"### {title}", "", block_notes[block], "",
                   render_md_table(headers, rows), ""]
            if args.latex:
                tex.append(render_latex_table(
                    headers, rows,
                    caption=f"{title} under the {pkey} protocol, mean "
                            f"$\\pm$ std over {len(config.SEEDS)} seeds. "
                            "'absent' marks a class with no support in the "
                            "test fold.",
                    label=f"tab:{block}-{pkey.replace('_', '-')}"))

        stdout += ["Ordering (rule 4: nothing claimed inside 1 std)", ""]
        md += ["### Ordering", "",
               "Rule 4: no ordering is claimed inside one standard deviation. "
               "Every statement below passed "
               "`metrics.separated_by_more_than_one_std` first.", "", "```"]
        for key, label, _, higher in MAIN_METRICS:
            lines = ranking_lines(by_model, key, label, higher)
            stdout += lines + [""]
            md += lines + [""]
        md += ["```", ""]

        incomplete = [m for m in sorted(by_model) if not is_complete(by_model[m])]
        if incomplete:
            msg = (f"INCOMPLETE rows under {pkey}: {incomplete}. "
                   f"Fewer than {len(config.SEEDS)} seeds. These may not be "
                   "described as best, and their spread is not the spread the "
                   "evaluation rules ask for.")
            stdout += [msg, ""]
            md += [f"> {msg}", ""]

    # ---- deltas ---------------------------------------------------------
    if args.claim_protocol:
        pkey = args.claim_protocol
        if pkey not in all_runs:
            raise ClaimRefusal(
                f"no runs found for protocol directory {pkey!r}. "
                f"Present: {sorted(all_runs)}")
        lines = claim_deltas(all_runs[pkey], pkey, args.baseline)
        stdout += ["", "=" * 74] + lines
        md += ["## Deltas", "", "```"] + lines + ["```", ""]

    # ---- failures -------------------------------------------------------
    if failed_markers:
        lines = [BANNER, "!! FAILED RUNS FOUND UNDER RUNS/", BANNER,
                 "These cells produced no result.json and therefore have no "
                 "row above.",
                 "A missing row is NOT the same as a run nobody asked for. "
                 "Fix and re-run",
                 "them, or state in the paper which cells are missing and "
                 "why.", ""]
        for p in failed_markers:
            rel = p.relative_to(Path(args.runs))
            lines.append(f"  {rel}")
        lines.append(BANNER)
        stdout += [""] + lines
        md += ["## Failed runs", "", "```"] + lines + ["```", ""]

    # ---- write ----------------------------------------------------------
    out_dir = config.assert_artefact_path(Path(args.out))
    out_dir.mkdir(parents=True, exist_ok=True)

    md_path = config.assert_artefact_path(out_dir / "results.md")
    md_path.write_text("\n".join(md) + "\n", encoding="utf-8")

    csv_path = out_dir / "results.csv"
    n_csv = write_long_csv(all_runs, csv_path)

    print("\n".join(stdout))
    print()
    print(f"wrote {md_path}")
    print(f"wrote {csv_path}  ({n_csv} rows, long format)")

    if args.latex:
        tex_path = config.assert_artefact_path(out_dir / "results.tex")
        header = ["% Generated by core/tools/aggregate.py.",
                  "% Requires \\usepackage{booktabs}.",
                  "% Every cell is mean $\\pm$ std over "
                  f"{len(config.SEEDS)} seeds.",
                  "% 'absent' marks a class with no support in the test fold;",
                  "% it is not a recall of zero.", ""]
        tex_path.write_text("\n".join(header + tex) + "\n", encoding="utf-8")
        print(f"wrote {tex_path}")

    print()
    print("next:  python -m core.tools.build_journal_outputs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
