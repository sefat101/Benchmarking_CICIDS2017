"""Download CICIDS2017 from the network. No manual browser step.

    python -m core.tools.get_data --which both

WHY TWO ARCHIVES
----------------
MachineLearningCSV/MachineLearningCVE  : 78 numeric features + Label. This is
    the distribution almost every published paper uses, so using it keeps the
    feature set comparable with the literature. But it has Flow ID, Source IP,
    Source Port, Destination IP, Destination Port*, Timestamp STRIPPED.
    (*Destination Port survives as a feature; the rest do not.)

GeneratedLabelledFlows/TrafficLabelling_ : the same flows with Flow ID, both
    IPs, both ports, Protocol and Timestamp retained.

The grouped (leakage-free) protocol needs a group key. With MachineLearningCVE
alone there is no key, so the only buildable protocol is the stratified random
split -- which is the saturated reference and cannot host a claim. That is why
the default is --which both: features from the ML distribution, group keys
joined back on from the labelled-flow distribution.

URL STATUS -- READ THIS
-----------------------
The candidate URLs below are UNVERIFIED. They were not reachable from the
environment where this file was written, so no claim is made that any of them
currently resolve. The downloader tries each in order and, if all fail, prints
explicit manual instructions instead of failing silently or inventing a
fallback. If you find the working URL, add it to the top of the list and
record the SHA-256 it produced in artefacts/data/raw/checksums.json.

INTEGRITY
---------
Every download is size-checked, zip-integrity-checked, and SHA-256'd. The
hash is written to checksums.json so a later run can prove it used the same
bytes. If you re-run on a different machine and the hash differs, the results
are not comparable and the run manifest will say so.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

from core import config

USER_AGENT = "Mozilla/5.0 (research; CICIDS2017 fetch; +local)"

# UNVERIFIED candidate URLs, tried in order.
SOURCES: dict[str, list[str]] = {
    "ml": [
        "http://cicresearch.ca/CICDataset/CIC-IDS-2017/Dataset/CIC-IDS-2017/CSVs/MachineLearningCSV.zip",
        "https://www.unb.ca/cic/datasets/ids-2017.html#MachineLearningCSV",
        "http://205.174.165.80/CICDataset/CIC-IDS-2017/Dataset/CIC-IDS-2017/CSVs/MachineLearningCSV.zip",
        "http://205.174.165.80/CICDataset/CIC-IDS-2017/Dataset/MachineLearningCSV.zip",
    ],
    "flows": [
        "http://cicresearch.ca/CICDataset/CIC-IDS-2017/Dataset/CIC-IDS-2017/GeneratedLabelledFlows.zip",
        "http://205.174.165.80/CICDataset/CIC-IDS-2017/Dataset/CIC-IDS-2017/GeneratedLabelledFlows.zip",
        "http://205.174.165.80/CICDataset/CIC-IDS-2017/Dataset/GeneratedLabelledFlows.zip",
    ],
}

MANUAL_INSTRUCTIONS = """
=============================================================================
AUTOMATED DOWNLOAD FAILED -- MANUAL FALLBACK
=============================================================================
None of the candidate URLs resolved. This is expected to happen eventually:
the CIC has moved this dataset's hosting more than once.

Do this:

 1. Open  https://www.unb.ca/cic/datasets/ids-2017.html
 2. Fill the short download form. You will be redirected to a file listing.
 3. Download BOTH:
        MachineLearningCSV.zip          (~220 MB)
        GeneratedLabelledFlows.zip      (~1.1 GB)
    Sizes are approximate and CITED from the dataset page, not verified here.
 4. Put both .zip files, unextracted, in:
        {raw}
 5. Re-run:
        python -m core.tools.get_data --which both --local-only

The --local-only flag skips the network entirely and just verifies, extracts
and hashes whatever zips are already sitting in that folder.

Alternative mirrors that have historically carried the same archives:
  - Kaggle: search "CICIDS2017"; confirm the file listing matches the 8
    MachineLearningCVE CSVs before trusting it.
  - The CIC's own AWS/Azure open-data mirrors.
CAUTION: third-party re-uploads are frequently modified (deduplicated,
re-labelled, or column-renamed) without saying so. preprocessing.py asserts
the class counts against config.EXPECTED_CLASS_COUNTS precisely so that a
silently altered copy fails loudly instead of producing a plausible table.
=============================================================================
"""


def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _progress(done: int, total: int, t0: float) -> None:
    if total <= 0:
        sys.stdout.write(f"\r    {done/1e6:8.1f} MB")
    else:
        pct = 100.0 * done / total
        rate = done / max(time.time() - t0, 1e-6) / 1e6
        sys.stdout.write(f"\r    {pct:5.1f}%  {done/1e6:8.1f}/{total/1e6:.1f} MB"
                         f"  {rate:5.1f} MB/s")
    sys.stdout.flush()


def download(url: str, dest: Path, timeout: int = 60) -> bool:
    """Stream one URL to dest. Returns False on any failure, never raises."""
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ctype = r.headers.get("Content-Type", "")
            if "text/html" in ctype:
                print(f"    -> served HTML, not a zip (Content-Type: {ctype}). "
                      "This URL is probably a landing page, not a file.")
                return False
            total = int(r.headers.get("Content-Length", 0))
            t0 = time.time()
            done = 0
            with open(tmp, "wb") as f:
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
                    done += len(b)
                    _progress(done, total, t0)
            print()
        if tmp.stat().st_size < 1_000_000:
            print(f"    -> only {tmp.stat().st_size} bytes; not a dataset archive")
            tmp.unlink(missing_ok=True)
            return False
        tmp.replace(dest)
        return True
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as e:
        print(f"    -> {type(e).__name__}: {e}")
        tmp.unlink(missing_ok=True)
        return False


def fetch(which: str, raw: Path, local_only: bool = False) -> Path | None:
    """Get one archive, from cache / disk / network in that order."""
    name = {"ml": "MachineLearningCSV.zip",
            "flows": "GeneratedLabelledFlows.zip"}[which]
    dest = raw / name

    if dest.exists() and zipfile.is_zipfile(dest):
        print(f"  [cached] {name}  ({dest.stat().st_size/1e6:.1f} MB)")
        return dest
    if local_only:
        print(f"  [missing] {name} not found in {raw} and --local-only is set")
        return None

    for url in SOURCES[which]:
        print(f"  trying {url}")
        if download(url, dest):
            if zipfile.is_zipfile(dest):
                print(f"  [ok] {name}")
                return dest
            print("    -> downloaded but not a valid zip; discarding")
            dest.unlink(missing_ok=True)
    return None


def extract(zpath: Path, out: Path) -> list[Path]:
    """Extract, guarding against path traversal in the archive."""
    out.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    with zipfile.ZipFile(zpath) as z:
        bad = z.testzip()
        if bad is not None:
            raise RuntimeError(f"corrupt member {bad} in {zpath.name}; "
                               "delete the zip and re-download")
        for m in z.infolist():
            if m.is_dir():
                continue
            target = (out / m.filename).resolve()
            if out.resolve() not in target.parents:
                raise RuntimeError(f"unsafe path in archive: {m.filename}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(m) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            written.append(target)
    return written


def main() -> int:
    ap = argparse.ArgumentParser(description="Fetch CICIDS2017.")
    ap.add_argument("--which", choices=["ml", "flows", "both"], default="both",
                    help="'ml' alone CANNOT support the grouped protocol")
    ap.add_argument("--local-only", action="store_true",
                    help="skip network; verify/extract zips already present")
    ap.add_argument("--no-extract", action="store_true")
    args = ap.parse_args()

    config.ensure_dirs()
    raw = config.DATA_RAW
    print(f"raw data dir: {raw}\n")

    targets = ["ml", "flows"] if args.which == "both" else [args.which]
    got: dict[str, Path] = {}
    for t in targets:
        print(f"[{t}]")
        p = fetch(t, raw, args.local_only)
        if p:
            got[t] = p
        print()

    if not got:
        print(MANUAL_INSTRUCTIONS.format(raw=raw))
        return 1

    checks_path = raw / "checksums.json"
    checks = json.loads(checks_path.read_text()) if checks_path.exists() else {}
    for t, p in got.items():
        print(f"hashing {p.name} ...")
        digest = sha256_file(p)
        prev = checks.get(p.name, {}).get("sha256")
        if prev and prev != digest:
            print(f"  !! SHA-256 CHANGED for {p.name}\n"
                  f"     was {prev}\n     now {digest}\n"
                  "     Results produced from the old bytes are NOT comparable.")
        checks[p.name] = {"sha256": digest, "bytes": p.stat().st_size,
                          "fetched": time.strftime("%Y-%m-%d %H:%M:%S")}
        print(f"  {digest}")
    checks_path.write_text(json.dumps(checks, indent=2), encoding="utf-8")

    if not args.no_extract:
        for t, p in got.items():
            print(f"\nextracting {p.name} ...")
            files = extract(p, raw / t)
            print(f"  {len(files)} file(s) -> {raw / t}")
            for f in sorted(files)[:12]:
                print(f"    {f.name}")

    if "flows" not in got:
        print("\n" + "=" * 74)
        print("WARNING: GeneratedLabelledFlows was not obtained.")
        print("Without it there is no Timestamp or IP column, so no group key,")
        print("so the leakage-free grouped protocol CANNOT be built. The only")
        print("runnable protocol would be the stratified random split, which")
        print("is a saturated reference and cannot host any claim.")
        print("=" * 74)
        return 2

    print("\nnext:  python -m core.tools.build_dataset")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
