"""Command-line tools. Generated artefacts never land inside core/."""
