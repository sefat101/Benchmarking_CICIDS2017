"""Turn the raw CICIDS2017 CSVs into a cached, audited dataset.

    python -m core.tools.build_dataset
    python -m core.tools.build_dataset --no-join          # random protocol only
    python -m core.tools.build_dataset --drop-exact-duplicates

WHAT IT PRODUCES  (all under --out, default config.DATA_INTERIM)
---------------------------------------------------------------
    X.npy                 float32 (N, 77)   feature matrix, UNSCALED
    y.npy                 int64   (N,)      class index into config.CLASSES
    feature_order.json    list[str]         the column order of X.npy
    meta.parquet          timestamp, src_ip, dst_ip   (only if the join ran)
      (meta.csv if pyarrow is unavailable -- the tool says so when it falls back)
    data_audit.json       the full DataAudit from common/preprocessing.py
    dataset_manifest.json shapes, fingerprints, flags, and what is buildable

WHY THE FEATURE ORDER IS SAVED SEPARATELY, AND WHY IT IS CRITICAL
-----------------------------------------------------------------
core/models/sigma.py resolves its semantic groups by COLUMN NAME, via
common/feature_groups.group_index_map(feature_order). A .npy carries no
column names. If the order of X.npy and the order recorded in
feature_order.json ever disagree, sigma silently receives the wrong columns
in each group: it would still train, still produce a plausible number, and
the semantic partition -- the entire content of the proposal -- would be
noise. The order is therefore written once, here, from the same list object
used to slice the matrix, and every downstream tool reads it rather than
reconstructing it.

WHAT THIS TOOL REFUSES TO DO
----------------------------
* It does not scale, centre or otherwise fit anything to the data. The
  scaler is fit on TRAIN INDICES ONLY, inside the split, in run_experiment.py
  (evaluation rule: no statistic of val/test may reach the training input).
* It does not silently accept a metadata join it cannot verify.
  preprocessing.join_metadata rejects a join below --join-min-agreement,
  because a misaligned join attaches the wrong timestamps to flows and turns
  the grouped protocol into something that only LOOKS leakage-free.
* It does not drop rows or columns to make anything look better. The only
  optional row removal is --drop-exact-duplicates, which is off by default
  and shouts about itself when on.
* With --no-join it does not pretend the grouped protocol is available. It
  writes no metadata and records grouped_protocol_buildable=false, and
  protocol.build_split raises rather than falling back to the random split.

PROVENANCE: every number this tool prints is measured from the files on
disk at run time, or is a CITED expectation from config.py being asserted
against. It makes no claim about any model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from core import config
from core.common import preprocessing
from core.common.feature_groups import ALL_FEATURES

# --------------------------------------------------------------------------
# Artefact file names. run_experiment.py and build_journal_outputs.py import
# these constants from here rather than re-typing the strings, so a rename
# cannot silently desynchronise the writer from the readers.
# --------------------------------------------------------------------------
X_FILE = "X.npy"
Y_FILE = "y.npy"
FEATURE_ORDER_FILE = "feature_order.json"
META_PARQUET_FILE = "meta.parquet"
META_CSV_FILE = "meta.csv"
AUDIT_FILE = "data_audit.json"
DATASET_MANIFEST_FILE = "dataset_manifest.json"

#: The only metadata columns the grouped protocol needs. label_idx is NOT
#: stored here -- run_experiment attaches it from y.npy, so the two can never
#: disagree about which row has which label.
META_COLUMNS: tuple[str, ...] = ("timestamp", "src_ip", "dst_ip")

BANNER = "!" * 74


# --------------------------------------------------------------------------
# Fingerprinting
# --------------------------------------------------------------------------
def array_sha256(a: np.ndarray, chunk_rows: int = 200_000) -> str:
    """SHA-256 of an array's bytes, hashed in row blocks.

    Chunked so that a ~900 MB float32 matrix does not need a second full copy
    in memory just to be hashed. dtype and shape are folded into the digest so
    that a reshape or a dtype change cannot collide with the original.
    """
    h = hashlib.sha256()
    h.update(f"{a.dtype.str}|{tuple(a.shape)}".encode("utf-8"))
    if a.size == 0:
        return h.hexdigest()
    flat = a.reshape(a.shape[0], -1)
    for i in range(0, flat.shape[0], chunk_rows):
        h.update(np.ascontiguousarray(flat[i:i + chunk_rows]).tobytes())
    return h.hexdigest()


# --------------------------------------------------------------------------
# Metadata writing, with the pyarrow fallback
# --------------------------------------------------------------------------
def save_metadata(meta: pd.DataFrame, out_dir: Path) -> tuple[Path, str]:
    """Write the metadata table, preferring parquet, falling back to CSV.

    Parquet keeps the datetime64 dtype; CSV does not, so the CSV branch writes
    ISO-8601 timestamps and the loader in run_experiment re-parses them. The
    chosen format is recorded in the dataset manifest so no reader has to
    guess.
    """
    try:
        import pyarrow  # noqa: F401
    except Exception as exc:  # ImportError, or a broken install
        path = config.assert_artefact_path(out_dir / META_CSV_FILE)
        print(f"  pyarrow unavailable ({type(exc).__name__}: {exc}).")
        print("  FALLING BACK TO CSV for the metadata table. This is slower to")
        print("  read and loses the datetime64 dtype, so timestamps are written")
        print("  as ISO-8601 strings and re-parsed on load. Install pyarrow to")
        print("  use parquet:  pip install pyarrow")
        out = meta.copy()
        if "timestamp" in out.columns:
            out["timestamp"] = pd.to_datetime(
                out["timestamp"], errors="coerce").dt.strftime(
                    "%Y-%m-%dT%H:%M:%S.%f")
        out.to_csv(path, index=False)
        return path, "csv"

    path = config.assert_artefact_path(out_dir / META_PARQUET_FILE)
    meta.to_parquet(path, index=False)
    return path, "parquet"


# --------------------------------------------------------------------------
# Duplicate removal (opt-in)
# --------------------------------------------------------------------------
def drop_exact_duplicates(frame: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Remove rows identical in all 77 features AND the label.

    keep='first' -- the earliest occurrence in file order survives. Note this
    is computed on the cleaned, numerically-coerced feature columns, so the
    count may differ slightly from DataAudit.n_exact_duplicate_rows, which
    preprocessing.clean_features measures on the pre-coercion frame. Both
    numbers are reported rather than reconciled silently.
    """
    subset = list(ALL_FEATURES) + ["label_idx"]
    mask = frame.duplicated(subset=subset, keep="first")
    n = int(mask.sum())
    return frame.loc[~mask].reset_index(drop=True), n


def print_duplicate_variant_warning() -> None:
    """The loud notice required whenever --drop-exact-duplicates is used."""
    print()
    print(BANNER)
    print("!! DEDUPLICATED DATASET VARIANT")
    print(BANNER)
    print("--drop-exact-duplicates is ON. Rows identical in all 77 features")
    print("and the label are removed, keeping the first occurrence.")
    print()
    print("THIS IS A DIFFERENT DATASET. Evaluation rule 5 applies to it:")
    print("  apply this variant to EVERY model in the comparison, or to NONE.")
    print("A table mixing deduplicated and non-deduplicated runs measures the")
    print("deduplication, not the architectures, and is not reportable.")
    print()
    print("It also changes the class counts away from the cited composition in")
    print("config.EXPECTED_CLASS_COUNTS, so numbers from this variant are not")
    print("directly comparable with the published literature on CICIDS2017.")
    print("Say so explicitly wherever they appear.")
    print(BANNER)
    print()


# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="python -m core.tools.build_dataset",
        description=(
            "Load the raw CICIDS2017 CSVs, clean and audit them, optionally "
            "join the timestamp/IP metadata that the grouped protocol needs, "
            "and cache the result as .npy + a feature-order JSON."),
        epilog=(
            "The feature-order JSON is load-bearing: sigma resolves its "
            "semantic feature groups by column NAME against it. Do not "
            "reorder X.npy without rewriting it."),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument(
        "--ml-dir", type=Path, default=config.DATA_RAW / "ml",
        help="directory holding the extracted MachineLearningCVE CSVs "
             "(searched recursively for *.csv)")
    ap.add_argument(
        "--flows-dir", type=Path, default=config.DATA_RAW / "flows",
        help="directory holding the extracted GeneratedLabelledFlows / "
             "TrafficLabelling_ CSVs, which carry Timestamp and the IPs")
    ap.add_argument(
        "--out", type=Path, default=config.DATA_INTERIM,
        help="where to write X.npy, y.npy, feature_order.json and the metadata")
    ap.add_argument(
        "--no-join", action="store_true",
        help="skip the metadata join entirely. No timestamps or IPs are "
             "written, so the GROUPED protocol becomes UNBUILDABLE and only "
             "the saturated random reference can be run. No claim can be made "
             "from a dataset built with this flag.")
    ap.add_argument(
        "--join-min-agreement", type=float, default=0.98,
        help="minimum fraction of rows that must agree on the 'flow duration' "
             "probe column between the two distributions before the "
             "positional join is accepted. Below this the join is REJECTED "
             "rather than used.")
    ap.add_argument(
        "--drop-exact-duplicates", action="store_true",
        help="remove rows identical in all 77 features and the label "
             "(keep='first'). OFF by default. This produces a different "
             "dataset variant which must be applied to every model or none.")
    ap.add_argument(
        "--force", action="store_true",
        help="overwrite an existing cached dataset in --out")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    config.ensure_dirs()
    out_dir = config.assert_artefact_path(Path(args.out))
    out_dir.mkdir(parents=True, exist_ok=True)

    x_path = config.assert_artefact_path(out_dir / X_FILE)
    y_path = config.assert_artefact_path(out_dir / Y_FILE)
    order_path = config.assert_artefact_path(out_dir / FEATURE_ORDER_FILE)
    audit_path = config.assert_artefact_path(out_dir / AUDIT_FILE)
    manifest_path = config.assert_artefact_path(out_dir / DATASET_MANIFEST_FILE)

    if x_path.exists() and not args.force:
        print(f"{x_path} already exists. Pass --force to rebuild.")
        return 0

    if args.drop_exact_duplicates:
        print_duplicate_variant_warning()

    print("=" * 74)
    print("BUILD DATASET")
    print("=" * 74)
    print(f"ml-dir     : {args.ml_dir}")
    print(f"flows-dir  : {args.flows_dir if not args.no_join else '(skipped)'}")
    print(f"out        : {out_dir}")
    print(f"join       : {'DISABLED (--no-join)' if args.no_join else 'enabled'}")
    print(f"dedup      : {'ON' if args.drop_exact_duplicates else 'off'}")
    print()

    audit = preprocessing.DataAudit()

    # ---- 1. load -------------------------------------------------------
    print("[1/5] loading MachineLearningCVE CSVs ...")
    raw = preprocessing.load_ml_csvs(Path(args.ml_dir), audit)
    print(f"      {len(raw):,} raw rows, {raw.shape[1]} raw columns")

    # ---- 2. clean ------------------------------------------------------
    # NOTE: clean_features RAISES if the class composition does not match the
    # cited counts in config.EXPECTED_CLASS_COUNTS. That is deliberate: a
    # third-party re-upload that has been silently deduplicated or relabelled
    # would otherwise produce a plausible-looking table that is not
    # comparable with anything. The exception is not caught here.
    print("[2/5] cleaning, label-normalising and auditing ...")
    frame = preprocessing.clean_features(raw, audit)
    print(f"      {len(frame):,} rows kept, {len(ALL_FEATURES)} feature columns")

    # ---- 3. join the group keys ----------------------------------------
    has_metadata = False
    if args.no_join:
        print("[3/5] metadata join SKIPPED (--no-join)")
        audit.notes.append(
            "--no-join was passed: no timestamp/IP metadata was attached. The "
            "grouped protocol is UNBUILDABLE from this dataset and only the "
            "saturated random reference can be run on it.")
    else:
        print("[3/5] loading flow metadata and joining ...")
        meta_raw = preprocessing.load_flow_metadata(Path(args.flows_dir), audit)
        print(f"      {len(meta_raw):,} metadata rows")
        frame = preprocessing.join_metadata(
            frame, meta_raw, audit, min_agreement=float(args.join_min_agreement))
        has_metadata = True
        print(f"      joined -> {len(frame):,} rows "
              f"(agreement {audit.join_agreement:.4%})")

    frame = frame.reset_index(drop=True)

    # ---- 4. optional deduplication -------------------------------------
    n_dropped_dups = 0
    if args.drop_exact_duplicates:
        print("[4/5] dropping exact duplicate rows ...")
        before = len(frame)
        frame, n_dropped_dups = drop_exact_duplicates(frame)
        print(f"      {n_dropped_dups:,} removed ({before:,} -> {len(frame):,})")
        audit.notes.append(
            f"--drop-exact-duplicates removed {n_dropped_dups:,} rows "
            "(identical in all 77 features and the label, keep='first'). This "
            "is a DATASET VARIANT: apply it to every model or to none, and do "
            "not compare its numbers with the published literature, whose "
            "class counts include the duplicates.")
    else:
        print("[4/5] deduplication off (default); duplicates retained")

    # ---- 5. materialise and save ---------------------------------------
    print("[5/5] materialising arrays and writing artefacts ...")
    feature_order: list[str] = list(ALL_FEATURES)
    X = frame[feature_order].to_numpy(dtype=np.float32)
    y = frame["label_idx"].to_numpy().astype(np.int64)
    if X.shape[0] != y.shape[0]:
        raise RuntimeError(
            f"internal error: X has {X.shape[0]} rows but y has {y.shape[0]}")
    if X.shape[1] != len(feature_order):
        raise RuntimeError(
            f"internal error: X has {X.shape[1]} columns but feature_order "
            f"lists {len(feature_order)} names")

    np.save(x_path, X)
    np.save(y_path, y)
    order_path.write_text(json.dumps(feature_order, indent=2), encoding="utf-8")
    print(f"      X -> {x_path}  {X.shape} {X.dtype}")
    print(f"      y -> {y_path}  {y.shape} {y.dtype}")
    print(f"      feature order -> {order_path}  ({len(feature_order)} names)")

    meta_path: Path | None = None
    meta_format: str | None = None
    n_nat = 0
    if has_metadata:
        missing_meta = [c for c in META_COLUMNS if c not in frame.columns]
        if missing_meta:
            raise RuntimeError(
                f"join reported success but metadata columns are missing: "
                f"{missing_meta}. Refusing to write a metadata file that "
                "cannot support the grouped protocol.")
        meta = frame[list(META_COLUMNS)].copy()
        meta["timestamp"] = pd.to_datetime(meta["timestamp"], errors="coerce")
        n_nat = int(meta["timestamp"].isna().sum())
        meta_path, meta_format = save_metadata(meta, out_dir)
        print(f"      metadata -> {meta_path}  ({meta_format}, "
              f"{len(meta):,} rows)")
        if n_nat:
            print()
            print(BANNER)
            print(f"!! {n_nat:,} rows have an unparseable timestamp (NaT).")
            print("protocol.build_episodes REFUSES to run with NaT present, so")
            print("the grouped protocol will raise until the timestamp parsing")
            print("in common/preprocessing.load_flow_metadata is fixed for the")
            print("affected files. This is reported, not patched over.")
            print(BANNER)
            audit.notes.append(
                f"{n_nat:,} NaT timestamps survive into the cached metadata; "
                "build_episodes will refuse to run until this is fixed.")

    # fingerprints, so a run manifest can prove which bytes it trained on
    print("      fingerprinting ...")
    x_sha = array_sha256(X)
    y_sha = array_sha256(y)

    audit.save(audit_path)
    print(f"      audit -> {audit_path}")

    manifest: dict[str, Any] = {
        "n_rows": int(X.shape[0]),
        "n_features": int(X.shape[1]),
        "n_classes": int(config.N_CLASSES),
        "classes": list(config.CLASSES),
        "feature_order_file": FEATURE_ORDER_FILE,
        "x_file": X_FILE,
        "y_file": Y_FILE,
        "x_sha256": x_sha,
        "y_sha256": y_sha,
        "has_metadata": bool(has_metadata),
        "metadata_file": meta_path.name if meta_path else None,
        "metadata_format": meta_format,
        "metadata_columns": list(META_COLUMNS) if has_metadata else [],
        "n_unparseable_timestamps": n_nat,
        "grouped_protocol_buildable": bool(has_metadata and n_nat == 0),
        "join_agreement": audit.join_agreement,
        "join_min_agreement_required": (
            None if args.no_join else float(args.join_min_agreement)),
        "drop_exact_duplicates": bool(args.drop_exact_duplicates),
        "n_exact_duplicates_removed": int(n_dropped_dups),
        "n_exact_duplicates_detected_by_audit":
            int(audit.n_exact_duplicate_rows),
        "class_counts_found": audit.class_counts_found,
        "class_count_mismatches": audit.class_count_mismatches,
        "retention": audit.retention,
        "built_by": "core.tools.build_dataset",
    }
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"      manifest -> {manifest_path}")

    # ---- report ---------------------------------------------------------
    print()
    print(audit.report())

    print()
    if manifest["grouped_protocol_buildable"]:
        print("Grouped protocol: BUILDABLE (timestamps and IPs are present).")
    else:
        print(BANNER)
        print("!! GROUPED PROTOCOL IS NOT BUILDABLE FROM THIS DATASET.")
        if args.no_join:
            print("   Reason: --no-join was passed, so no timestamps or IPs")
            print("   were attached.")
        elif n_nat:
            print(f"   Reason: {n_nat:,} unparseable timestamps.")
        else:
            print("   Reason: no metadata was written.")
        print()
        print("   The only runnable protocol is the stratified random split,")
        print("   which config.NON_CLAIM_PROTOCOLS marks as a saturated")
        print("   reference. NO IMPROVEMENT CLAIM MAY BE MADE FROM IT.")
        print("   protocol.build_split raises rather than falling back, so a")
        print("   grouped run will fail loudly instead of quietly becoming a")
        print("   random run.")
        print(BANNER)

    if args.drop_exact_duplicates:
        print_duplicate_variant_warning()

    print("next:  python -m core.tools.run_experiment --smoke")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
