"""Fetch CICIDS2017 from Kaggle, and verify the mirror is usable.

    pip install kaggle
    set KAGGLE_API_TOKEN=...            (Windows cmd)
    $env:KAGGLE_API_TOKEN="..."         (PowerShell)
    python -m core.tools.get_data_kaggle --search
    python -m core.tools.get_data_kaggle --dataset <owner>/<slug>

THE CREDENTIAL IS NEVER STORED IN THIS REPOSITORY.
It is read from, in order:
    1. env KAGGLE_API_TOKEN                     (new-style token, 'KGAT_...')
    2. ~/.kaggle/access_token                   (new-style token file)
    3. env KAGGLE_USERNAME + KAGGLE_KEY         (old-style)
    4. ~/.kaggle/kaggle.json                    (old-style)
If you paste a token into a source file, it ends up in git history. Don't.

WHY --search EXISTS INSTEAD OF A HARD-CODED SLUG
------------------------------------------------
Kaggle copies of CICIDS2017 are third-party re-uploads. They differ from each
other and from the CIC original in ways that matter here:

  * Most carry ONLY the MachineLearningCVE CSVs (78 features + Label).
    Those have Timestamp, Flow ID and both IPs STRIPPED. With such a mirror
    the leakage-free grouped protocol CANNOT BE BUILT -- there is no group
    key -- and the only runnable protocol is the stratified random split,
    which is a saturated reference that cannot host a claim.
  * Several are advertised as "cleaned" or "preprocessed": deduplicated,
    re-scaled, re-labelled, or subsampled. Numbers from those are not
    comparable with the published literature.

So this tool lists candidate datasets AND their file listings first, flags
which ones can support the grouped protocol, and only then downloads. After
extraction it reads the header of every CSV and reports whether the key
columns are actually present. preprocessing.py additionally asserts the class
counts against the cited composition, so a modified re-upload fails loudly
rather than producing a plausible-looking table.

PROVENANCE: the candidate search terms below are search strings, not claims
about what exists. Nothing in this file asserts that any particular Kaggle
dataset is correct -- the verification step measures that at run time.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from core import config
from core.tools.get_data import sha256_file

SEARCH_TERMS = ["CICIDS2017", "CIC-IDS-2017", "intrusion detection CICIDS",
                "network intrusion dataset"]

# Filenames that indicate each distribution. Matched case-insensitively on
# substrings, because re-uploaders rename things.
ML_MARKERS = ["monday-workinghours", "tuesday-workinghours",
              "wednesday-workinghours", "thursday-workinghours",
              "friday-workinghours"]
FLOW_MARKERS = ["trafficlabelling", "generatedlabelledflows", "pcap_iscx"]

# Column names whose presence means the grouped protocol is buildable.
KEY_COLUMNS = ["timestamp", "source ip", "src ip", "destination ip", "dst ip",
               "flow id"]


def resolve_credentials() -> tuple[str, dict]:
    """Find credentials without ever writing them to disk in this repo."""
    tok = os.environ.get("KAGGLE_API_TOKEN")
    if tok:
        return "env KAGGLE_API_TOKEN", {"token": tok[:8] + "..."}
    tok_file = Path.home() / ".kaggle" / "access_token"
    if tok_file.exists():
        os.environ["KAGGLE_API_TOKEN"] = tok_file.read_text().strip()
        return f"{tok_file}", {"token": "(from file)"}
    if os.environ.get("KAGGLE_USERNAME") and os.environ.get("KAGGLE_KEY"):
        return "env KAGGLE_USERNAME/KAGGLE_KEY", {
            "username": os.environ["KAGGLE_USERNAME"]}
    kj = Path.home() / ".kaggle" / "kaggle.json"
    if kj.exists():
        try:
            d = json.loads(kj.read_text())
            os.environ.setdefault("KAGGLE_USERNAME", d.get("username", ""))
            os.environ.setdefault("KAGGLE_KEY", d.get("key", ""))
            return f"{kj}", {"username": d.get("username", "?")}
        except Exception as e:  # noqa: BLE001
            print(f"  kaggle.json present but unreadable: {e}")
    raise RuntimeError(
        "No Kaggle credentials found.\n\n"
        "Set the token in your shell (do NOT put it in a file in this repo):\n"
        "  Windows cmd   :  set KAGGLE_API_TOKEN=KGAT_xxxxxxxx\n"
        "  PowerShell    :  $env:KAGGLE_API_TOKEN=\"KGAT_xxxxxxxx\"\n"
        "  bash          :  export KAGGLE_API_TOKEN=KGAT_xxxxxxxx\n\n"
        "Or write it once to the standard location:\n"
        "  mkdir %USERPROFILE%\\.kaggle\n"
        "  echo KGAT_xxxxxxxx > %USERPROFILE%\\.kaggle\\access_token\n")


def get_api():
    try:
        from kaggle.api.kaggle_api_extended import KaggleApi
    except ImportError:
        raise RuntimeError(
            "the 'kaggle' package is not installed.\n  pip install kaggle\n"
            "If your token starts with 'KGAT_' you need a recent version:\n"
            "  pip install --upgrade kaggle")
    src, info = resolve_credentials()
    print(f"credentials from: {src}  {info}")
    api = KaggleApi()
    api.authenticate()
    return api


def classify_listing(names: list[str]) -> dict:
    """Decide what a dataset's file listing can and cannot support."""
    low = [n.lower() for n in names]
    has_ml = sum(any(m in n for n in low) for m in ML_MARKERS)
    has_flows = any(any(m in n for m in FLOW_MARKERS) for n in low)
    n_csv = sum(1 for n in low if n.endswith(".csv"))
    return {
        "n_files": len(names), "n_csv": n_csv,
        "ml_day_markers": has_ml, "looks_like_flows": has_flows,
        "grouped_protocol_possible": bool(has_flows),
    }


def search(api, limit: int = 20) -> None:
    seen: set[str] = set()
    rows = []
    for term in SEARCH_TERMS:
        try:
            for d in api.dataset_list(search=term, max_size=None):
                ref = str(d.ref)
                if ref in seen:
                    continue
                seen.add(ref)
                rows.append(d)
                if len(rows) >= limit:
                    break
        except Exception as e:  # noqa: BLE001
            print(f"  search {term!r} failed: {e}")
        if len(rows) >= limit:
            break

    if not rows:
        print("no results. Check connectivity and credentials.")
        return

    print(f"\n{len(rows)} candidate dataset(s). Inspecting file listings...\n")
    print(f"{'ref':<52} {'csv':>4} {'day':>4} {'flows?':>7}  title")
    print("-" * 110)
    for d in rows:
        ref = str(d.ref)
        try:
            files = [str(f.name) for f in api.dataset_list_files(ref).files]
        except Exception:
            files = []
        c = classify_listing(files)
        flag = "YES" if c["grouped_protocol_possible"] else "no"
        print(f"{ref:<52} {c['n_csv']:>4} {c['ml_day_markers']:>4} "
              f"{flag:>7}  {str(getattr(d, 'title', ''))[:40]}")
    print("-" * 110)
    print("csv    = number of .csv files")
    print("day    = how many of the 5 weekday filename markers were found")
    print("flows? = listing contains TrafficLabelling/GeneratedLabelledFlows,")
    print("         i.e. it may carry Timestamp + IP columns.")
    print()
    print("PICK ONE WITH flows?=YES IF YOU CAN. A dataset with flows?=no can")
    print("only support the stratified random split, which is the saturated")
    print("reference protocol and cannot host an improvement claim.")
    print()
    print("Then:  python -m core.tools.get_data_kaggle --dataset <ref>")


def inspect_extracted(root: Path) -> dict:
    """Read only the header of every CSV; report which key columns exist."""
    import csv as _csv
    report: dict[str, dict] = {}
    for p in sorted(root.rglob("*.csv")):
        try:
            for enc in ("utf-8", "latin-1"):
                try:
                    with open(p, "r", encoding=enc, newline="") as f:
                        header = next(_csv.reader(f))
                    break
                except UnicodeDecodeError:
                    continue
            else:
                report[p.name] = {"error": "undecodable header"}
                continue
            cols = [h.strip().lower() for h in header]
            report[p.name] = {
                "n_cols": len(cols),
                "has_timestamp": any("timestamp" in c for c in cols),
                "has_src_ip": any(c in ("source ip", "src ip") for c in cols),
                "has_dst_ip": any(c in ("destination ip", "dst ip") for c in cols),
                "has_flow_id": any("flow id" in c for c in cols),
            }
        except StopIteration:
            report[p.name] = {"error": "empty file"}
    return report


def main() -> int:
    ap = argparse.ArgumentParser(description="Fetch CICIDS2017 from Kaggle.")
    ap.add_argument("--search", action="store_true",
                    help="list candidate datasets and what each can support")
    ap.add_argument("--dataset", type=str, default=None,
                    help="owner/slug to download")
    ap.add_argument("--limit", type=int, default=20)
    ap.add_argument("--force", action="store_true",
                    help="re-download even if files are present")
    args = ap.parse_args()

    config.ensure_dirs()
    api = get_api()

    if args.search or not args.dataset:
        search(api, args.limit)
        return 0

    out = config.DATA_RAW / "kaggle" / args.dataset.replace("/", "__")
    out.mkdir(parents=True, exist_ok=True)

    # Pre-flight: know what we are getting before spending the bandwidth.
    try:
        files = [str(f.name) for f in api.dataset_list_files(args.dataset).files]
    except Exception as e:  # noqa: BLE001
        print(f"could not list files for {args.dataset}: {e}")
        return 1
    cls = classify_listing(files)
    print(f"\n{args.dataset}")
    print(f"  files: {cls['n_files']}  csv: {cls['n_csv']}  "
          f"weekday markers: {cls['ml_day_markers']}")
    for f in sorted(files)[:20]:
        print(f"    {f}")
    if not cls["grouped_protocol_possible"]:
        print("\n  ** This listing shows no TrafficLabelling/"
              "GeneratedLabelledFlows files.")
        print("  ** It probably carries only the 78-feature ML CSVs, which")
        print("  ** have Timestamp and IPs stripped. Downloading anyway, but")
        print("  ** the grouped protocol will not be buildable from it alone.")

    print(f"\ndownloading -> {out}")
    api.dataset_download_files(args.dataset, path=str(out), unzip=True,
                               quiet=False, force=args.force)

    # Post-flight: what did we actually get?
    print("\ninspecting headers...")
    rep = inspect_extracted(out)
    if not rep:
        print("  no CSVs found after extraction.")
        return 1
    any_ts = any(v.get("has_timestamp") for v in rep.values())
    any_ip = any(v.get("has_src_ip") for v in rep.values())
    print(f"{'file':<52} {'cols':>5} {'ts':>4} {'sip':>4} {'dip':>4}")
    print("-" * 76)
    for name, v in sorted(rep.items()):
        if "error" in v:
            print(f"{name:<52}  {v['error']}")
            continue
        print(f"{name:<52} {v['n_cols']:>5} "
              f"{'Y' if v['has_timestamp'] else '-':>4} "
              f"{'Y' if v['has_src_ip'] else '-':>4} "
              f"{'Y' if v['has_dst_ip'] else '-':>4}")
    print("-" * 76)

    manifest = {
        "dataset": args.dataset,
        "path": str(out),
        "listing_class": cls,
        "header_report": rep,
        "grouped_protocol_buildable": bool(any_ts and any_ip),
        "sha256": {p.name: sha256_file(p)
                   for p in sorted(out.rglob("*.csv"))[:16]},
    }
    mpath = config.assert_artefact_path(out / "kaggle_manifest.json")
    mpath.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"\nmanifest -> {mpath}")

    print("\n" + "=" * 74)
    if any_ts and any_ip:
        print("USABLE: Timestamp and IP columns are present.")
        print("Both protocols are buildable. Next:")
        print("  python -m core.tools.build_dataset --ml-dir <dir> "
              "--flows-dir <dir>")
    else:
        print("LIMITED: no Timestamp/IP columns were found in any CSV.")
        print("You can build the stratified random split from this mirror.")
        print("You CANNOT build the leakage-free grouped split, and the")
        print("random split is the saturated reference -- no improvement")
        print("claim may be made on it. Either find a Kaggle mirror that")
        print("includes GeneratedLabelledFlows / TrafficLabelling_, or get")
        print("that archive from the CIC:")
        print("  python -m core.tools.get_data --which flows")
    print("=" * 74)
    print("\nSECURITY: rotate this API token at "
          "https://www.kaggle.com/settings -- it was shared in a screenshot.")
    return 0 if (any_ts and any_ip) else 2


if __name__ == "__main__":
    sys.exit(main())
