"""Probe the environment and instantiate every model. Run this first.

    python -m core.tools.check_env

WHAT IT IS FOR
--------------
Two questions, answered without touching the dataset:

 1. Is this machine the one the pipeline was written for? Python, torch,
    CUDA, device name, compute capability, VRAM, and the numpy / pandas /
    sklearn / pyarrow / kaggle situation, compared against
    config.GPU_EXPECTED.

 2. Does every model in MODEL_REGISTRY still satisfy the contract? Each is
    instantiated with n_features=77, n_classes=10 and a group_idx built from
    common/feature_groups over the canonical 77-name column list. A model
    whose __init__ signature has drifted, or which mishandles group_idx,
    fails here in about a second -- instead of three hours into a sweep,
    after the data has loaded and nine other models have trained.

EXIT CODE
---------
Nonzero if any model fails to instantiate. The GPU checks NEVER fail the
process: a mismatch against config.GPU_EXPECTED is a warning, because
running on different hardware is legitimate as long as it is recorded. It
is recorded in every run manifest by run_experiment.py.

WHAT IT REFUSES TO DO
---------------------
* It refuses to report any number that could be mistaken for a result. It
  runs no forward pass by default and computes no metric. --forward-check is
  available and asserts output SHAPES only; it prints no values.
* It refuses to guess VRAM feasibility from a measurement it did not take.
  The attention-memory figure below is stated as arithmetic, with its inputs
  shown, and is labelled as such.

PROVENANCE: the version and device figures are measured from the running
interpreter. The attention-tensor size is ARITHMETIC from
config.SHARED_TRAIN['batch_size'], the transformer's own head count and the
77-feature partition -- it is not a measurement of allocated memory, and the
file says so wherever it appears.
"""
from __future__ import annotations

import argparse
import importlib
import platform
import sys
import traceback
from typing import Any

BANNER = "!" * 74


def _fmt_bytes(n: float) -> str:
    return f"{n / 1e6:,.1f} MB ({n / 2 ** 20:,.1f} MiB)"


def _try_version(module: str) -> tuple[bool, str]:
    try:
        m = importlib.import_module(module)
    except Exception as exc:
        return False, f"NOT INSTALLED ({type(exc).__name__})"
    return True, str(getattr(m, "__version__", "installed, version unknown"))


# --------------------------------------------------------------------------
def report_interpreter() -> None:
    print("-" * 74)
    print("INTERPRETER")
    print("-" * 74)
    print(f"  python        : {platform.python_version()} "
          f"({platform.python_implementation()})")
    print(f"  executable    : {sys.executable}")
    print(f"  platform      : {platform.platform()}")
    if sys.version_info < (3, 9):
        print(f"  {BANNER}")
        print("  !! This code uses builtin generic annotations under "
              "`from __future__ import annotations`.")
        print("     Python 3.9+ is expected. Older versions may fail at "
              "runtime in places")
        print("     where annotations are evaluated.")
        print(f"  {BANNER}")


def report_libraries() -> dict[str, Any]:
    print()
    print("-" * 74)
    print("LIBRARIES")
    print("-" * 74)
    info: dict[str, Any] = {}
    for mod, note in (("numpy", ""), ("pandas", ""), ("sklearn", ""),
                      ("torch", ""),
                      ("pyarrow", "parquet metadata; build_dataset falls "
                                  "back to CSV without it"),
                      ("kaggle", "optional mirror fetch in "
                                 "core/tools/get_data_kaggle.py")):
        ok, ver = _try_version(mod)
        info[mod] = ver if ok else None
        suffix = f"   [{note}]" if note else ""
        print(f"  {mod:<10}    : {ver}{suffix}")
    return info


def report_device(config) -> dict[str, Any]:
    import torch

    print()
    print("-" * 74)
    print("DEVICE")
    print("-" * 74)
    info: dict[str, Any] = {"cuda_available": bool(torch.cuda.is_available())}
    print(f"  torch         : {torch.__version__}")
    print(f"  torch.version.cuda : {getattr(torch.version, 'cuda', None)}")
    print(f"  cuda available: {info['cuda_available']}")

    if not info["cuda_available"]:
        print()
        print("  No CUDA device visible. Everything still RUNS on CPU, but the")
        print("  full sweep (10 models x 2 protocols x 5 seeds over ~2.8M")
        print("  flows) is expected to be impractically slow there. That is a")
        print("  statement about the workload, not a measurement of this")
        print("  machine.")
        print()
        print(f"  Expected per config.GPU_EXPECTED: {config.GPU_EXPECTED}")
        print("  WARNING: cannot verify the expected device. Not failing -- "
              "the run")
        print("  manifest records whatever device was actually used.")
        return info

    n = torch.cuda.device_count()
    print(f"  device count  : {n}")
    for i in range(n):
        props = torch.cuda.get_device_properties(i)
        cap = torch.cuda.get_device_capability(i)
        arch = f"sm_{cap[0]}{cap[1]}"
        vram = int(props.total_memory)
        print(f"  [{i}] name    : {props.name}")
        print(f"      arch     : {arch}")
        print(f"      VRAM     : {_fmt_bytes(vram)}  "
              f"({vram / 2 ** 30:.2f} GiB)")
        print(f"      SMs      : {props.multi_processor_count}")
        if i == 0:
            info.update(name=props.name, arch=arch, total_vram_bytes=vram)

    exp_arch = config.GPU_EXPECTED.get("arch")
    exp_vram_gb = config.GPU_EXPECTED.get("vram_gb")
    got_arch = info.get("arch")
    got_gib = info.get("total_vram_bytes", 0) / 2 ** 30

    print()
    print(f"  expected (config.GPU_EXPECTED): arch {exp_arch}, "
          f"{exp_vram_gb} GB")
    mismatches = []
    if exp_arch and got_arch != exp_arch:
        mismatches.append(f"arch {got_arch} != expected {exp_arch}")
    if exp_vram_gb and got_gib < exp_vram_gb * 0.9:
        mismatches.append(
            f"VRAM {got_gib:.2f} GiB is below the expected {exp_vram_gb} GB")
    if mismatches:
        print(f"  {BANNER}")
        print("  !! DEVICE DOES NOT MATCH config.GPU_EXPECTED")
        for m in mismatches:
            print(f"     {m}")
        print("     NOT failing. Different hardware is legitimate as long as")
        print("     it is recorded -- run_experiment.py writes the actual")
        print("     device into every run manifest. But wall-clock times and")
        print("     any batch-size feasibility reasoning in the write-up were")
        print("     stated for the expected device, so re-check them.")
        print(f"  {BANNER}")
    else:
        print("  device matches config.GPU_EXPECTED.")
    return info


def report_attention_arithmetic(config, n_features: int,
                                nhead: int, nhead_source: str) -> None:
    batch = int(config.SHARED_TRAIN["batch_size"])
    elems = batch * nhead * n_features * n_features
    fp32 = elems * 4

    print()
    print("-" * 74)
    print("VRAM FEASIBILITY NOTE -- THIS IS ARITHMETIC, NOT A MEASUREMENT")
    print("-" * 74)
    print("  Nothing below was allocated or profiled. It is the size of one")
    print("  attention score tensor computed from the shapes, and it is")
    print("  stated so that the batch size can be sanity-checked against the")
    print("  card before a sweep, not as an observed memory figure.")
    print()
    print(f"  batch size   : {batch}   (config.SHARED_TRAIN['batch_size'], "
          "shared by all ten models under rule 5)")
    print(f"  tokens       : {n_features}  (one token per unique feature "
          "column)")
    print(f"  heads        : {nhead}   ({nhead_source})")
    print()
    print(f"  attention tensor shape : ({batch}, {nhead}, {n_features}, "
          f"{n_features})")
    print(f"  elements               : {elems:,}")
    print(f"  fp32 size              : {fp32:,} bytes = {_fmt_bytes(fp32)}")
    print()
    print("  That is ONE tensor for ONE layer of the forward pass. The")
    print("  backward pass holds more, and the transformer in this repo has")
    print("  more than one layer, so the true peak is a multiple of this")
    print("  number -- how large a multiple depends on the autograd graph and")
    print("  on whether the installed torch uses a fused attention kernel")
    print("  that never materialises the full matrix. That is exactly why")
    print("  this is arithmetic and not a claim about peak memory.")
    print()
    print("  The measured figure exists elsewhere: TrainLog.peak_vram_mb is")
    print("  recorded by the shared training loop from")
    print("  torch.cuda.max_memory_allocated() for every run. Use that number")
    print("  when you need a real one.")
    print()
    print(f"  config.SHARED_TRAIN['amp'] = {config.SHARED_TRAIN['amp']}  "
          "(fp32 kept deliberately; see config.py)")


# --------------------------------------------------------------------------
def check_models(forward_check: bool = False) -> tuple[list[dict], list[dict]]:
    """Instantiate every registered model against the canonical 77 features."""
    import torch

    from core import config
    from core.common import model_utils
    from core.common.feature_groups import (
        ALL_FEATURES, GROUP_NAMES, N_UNIQUE_FEATURES, group_index_map,
    )

    # The synthetic column list is the canonical order from feature_groups --
    # the same names build_dataset.py writes into feature_order.json. No data
    # is read; only the names matter, because that is how sigma resolves its
    # groups.
    feature_order = list(ALL_FEATURES)
    group_idx = group_index_map(feature_order)
    n_features = N_UNIQUE_FEATURES

    print()
    print("-" * 74)
    print("FEATURE PARTITION")
    print("-" * 74)
    print(f"  features      : {n_features}  (canonical order from "
          "feature_groups.ALL_FEATURES)")
    print(f"  groups        : {len(GROUP_NAMES)}")
    print("  sizes         : " + ", ".join(
        f"{g}={len(group_idx[g])}" for g in GROUP_NAMES))
    empty = [g for g in GROUP_NAMES if not group_idx[g]]
    if empty:
        print(f"  EMPTY GROUPS  : {empty}")

    names = model_utils.available_models()
    print()
    print("-" * 74)
    print(f"MODEL INSTANTIATION  ({len(names)} registered)")
    print("-" * 74)
    print(f"  n_features={n_features}  n_classes={config.N_CLASSES}  "
          "group_idx=semantic partition")

    ok_rows: list[dict] = []
    failures: list[dict] = []

    for name in names:
        try:
            model = model_utils.build_model(
                name, n_features, config.N_CLASSES, group_idx)
            row = {
                "model": name,
                "params": int(model.n_params()),
                "input_kind": str(model.INPUT_KIND),
                "aux_weight": float(model.AUX_LOSS_WEIGHT),
                "perm_invariant": bool(
                    getattr(model, "CLAIMS_PERMUTATION_INVARIANCE", False)),
                "note": "",
            }
            cov = getattr(model, "shape_cfg", {}).get("coverage_warning")
            if cov:
                row["note"] = str(cov)

            if forward_check:
                # Shapes only. Nothing is printed from the tensor values, and
                # nothing here is a result: the weights are random and the
                # input is zeros.
                model.eval()
                with torch.no_grad():
                    xb = torch.zeros(4, n_features)
                    res = model(model.shape_input(xb))
                    logits = res[0] if isinstance(res, tuple) else res
                    if tuple(logits.shape) != (4, config.N_CLASSES):
                        raise RuntimeError(
                            f"forward returned {tuple(logits.shape)}, expected "
                            f"(4, {config.N_CLASSES})")
                    if isinstance(res, tuple):
                        row["note"] = (row["note"] + " " if row["note"] else "") \
                            + f"aux keys: {sorted(res[1])}"
                row["note"] = (row["note"] + " " if row["note"] else "") \
                    + "forward shape OK"

            ok_rows.append(row)
            print(f"  [ok]   {name}")
        except Exception as exc:
            tb = traceback.format_exc()
            failures.append({"model": name, "error": f"{type(exc).__name__}: {exc}",
                             "traceback": tb})
            print(f"  [FAIL] {name}: {type(exc).__name__}: {exc}")

    # ---- table ---------------------------------------------------------
    if ok_rows:
        headers = ["model", "parameters", "input", "aux w",
                   "perm-invariant (declared)", "note"]
        rows = [[r["model"], f"{r['params']:,}", r["input_kind"],
                 f"{r['aux_weight']:g}", str(r["perm_invariant"]), r["note"]]
                for r in ok_rows]
        widths = [len(h) for h in headers]
        for r in rows:
            for i, c in enumerate(r):
                widths[i] = max(widths[i], len(c))
        print()
        print("  " + "  ".join(h.ljust(widths[i]) for i, h in enumerate(headers)))
        print("  " + "  ".join("-" * w for w in widths))
        for r in rows:
            print("  " + "  ".join(c.ljust(widths[i]) for i, c in enumerate(r)))
        print()
        print("  'perm-invariant (declared)' is the model's own "
              "CLAIMS_PERMUTATION_INVARIANCE")
        print("  flag: a statement about its inductive bias, NOT a measured")
        print("  result. run_experiment.py --permute-columns is what tests it.")
        print("  Parameter counts are exact; they are properties of the")
        print("  architectures at these shapes, not performance figures.")

    return ok_rows, failures


# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="python -m core.tools.check_env",
        description=(
            "Report the interpreter, libraries and CUDA device, compare them "
            "against config.GPU_EXPECTED, and instantiate every registered "
            "model against the canonical 77-feature partition."),
        epilog=(
            "Exit code is nonzero if any model fails to instantiate. Device "
            "mismatches only warn."),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument(
        "--forward-check", action="store_true",
        help="also push a zero batch through each model and assert the output "
             "SHAPE. Prints no tensor values -- the weights are random and "
             "the input is zeros, so nothing produced here means anything")
    ap.add_argument(
        "--no-models", action="store_true",
        help="report the environment only; skip model instantiation")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    print("=" * 74)
    print("ENVIRONMENT CHECK")
    print("=" * 74)

    report_interpreter()
    report_libraries()

    try:
        from core import config
    except Exception:
        print()
        print(BANNER)
        print("!! could not import core.config -- run from the repository root")
        print(BANNER)
        traceback.print_exc()
        return 2

    print()
    print("-" * 74)
    print("PATHS")
    print("-" * 74)
    print(f"  repo root     : {config.REPO_ROOT}")
    print(f"  artefacts     : {config.ARTEFACTS}")
    for label, path in (("raw data", config.DATA_RAW),
                        ("interim data", config.DATA_INTERIM),
                        ("runs", config.RUNS),
                        ("results", config.RESULTS),
                        ("figures", config.FIGURES)):
        print(f"  {label:<13} : {path}  "
              f"{'[exists]' if path.exists() else '[missing]'}")

    try:
        import torch  # noqa: F401
    except Exception:
        print()
        print(BANNER)
        print("!! torch is not importable. Nothing downstream can run.")
        print(BANNER)
        traceback.print_exc()
        return 2

    report_device(config)

    ok_rows: list[dict] = []
    failures: list[dict] = []
    nhead = 4
    nhead_source = "transformer default (model not instantiated)"
    n_features = 77

    if not args.no_models:
        ok_rows, failures = check_models(forward_check=args.forward_check)
        from core.common.feature_groups import N_UNIQUE_FEATURES
        n_features = N_UNIQUE_FEATURES
        try:
            from core.common import model_utils
            tf = model_utils.build_model("transformer", n_features,
                                         config.N_CLASSES, None)
            nhead = int(tf.shape_cfg.get("nhead", 4))
            nhead_source = "read from the instantiated transformer"
        except Exception:
            pass

    report_attention_arithmetic(config, n_features, nhead, nhead_source)

    # ---- verdict --------------------------------------------------------
    print()
    print("=" * 74)
    print("VERDICT")
    print("=" * 74)
    if args.no_models:
        print("  models not checked (--no-models).")
        return 0
    print(f"  instantiated OK : {len(ok_rows)}")
    print(f"  failed          : {len(failures)}")
    if failures:
        print()
        print(BANNER)
        print("!! MODEL CONTRACT BROKEN")
        print(BANNER)
        for f in failures:
            print(f"\n  {f['model']}: {f['error']}")
            print("  " + "\n  ".join(f["traceback"].strip().splitlines()[-6:]))
        print()
        print("Every model must accept (n_features, n_classes, group_idx, "
              "**shape).")
        print("Fix these before running anything: a model that cannot be built")
        print("here will also fail inside the sweep, after the data has loaded")
        print("and other models have already trained.")
        print(BANNER)
        return 1

    print("  all registered models instantiate against the canonical "
          "77-feature partition.")
    print()
    print("next:  python -m core.tools.build_dataset")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
