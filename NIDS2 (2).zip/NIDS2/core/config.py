"""Central configuration: paths, canonical class set, protocol constants.

PROVENANCE OF EVERY NUMBER IN THIS FILE
---------------------------------------
CITED   : EXPECTED_CLASS_COUNTS, TOTAL_FLOWS_CITED, RETENTION_CITED.
          Taken from the published composition of the CICIDS2017
          MachineLearningCVE distribution. They are ASSERTED against the
          actual data at load time (see common/preprocessing.py). If an
          assertion fires, the archive you downloaded is not the one this
          pipeline was written against. Fix that before running anything.
MEASURED: nothing. This file computes no results.
CONJECTURE: nothing.

Nothing here may be edited to make a headline look better. The protocol
constants (TARGET_ATTACK_RECALL, SEEDS) are frozen by the evaluation rules.
"""
from __future__ import annotations

from pathlib import Path

# --------------------------------------------------------------------------
# Paths.  Rule: all code lives under core/, all generated artefacts outside it.
# --------------------------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parents[1]
CORE = REPO_ROOT / "core"

ARTEFACTS = REPO_ROOT / "artefacts"
DATA_RAW = ARTEFACTS / "data" / "raw"          # downloaded zips + extracted csv
DATA_INTERIM = ARTEFACTS / "data" / "interim"  # concatenated / label-normalised
DATA_PROCESSED = ARTEFACTS / "data" / "processed"  # split indices, scalers
RUNS = ARTEFACTS / "runs"                      # one dir per (model, protocol, seed)
RESULTS = ARTEFACTS / "results"                # aggregated tables
FIGURES = ARTEFACTS / "figures"
LOGS = ARTEFACTS / "logs"
DOCS = REPO_ROOT / "docs"

_ALL_ARTEFACT_DIRS = (
    DATA_RAW, DATA_INTERIM, DATA_PROCESSED, RUNS, RESULTS, FIGURES, LOGS,
)


def ensure_dirs() -> None:
    """Create every artefact directory. Never creates anything inside core/."""
    for d in _ALL_ARTEFACT_DIRS:
        d.mkdir(parents=True, exist_ok=True)


def assert_artefact_path(p: Path) -> Path:
    """Guard: refuse to write a generated artefact inside core/."""
    p = Path(p).resolve()
    if CORE.resolve() in p.parents or p == CORE.resolve():
        raise RuntimeError(
            f"Refusing to write generated artefact inside core/: {p}\n"
            "All generated artefacts belong under artefacts/."
        )
    return p


# --------------------------------------------------------------------------
# Task definition: the reduced 10-class problem.
# BENIGN MUST be index 0 -- metrics.py relies on it for the attack/benign
# collapse used by FPR-at-fixed-recall.
# --------------------------------------------------------------------------
CLASSES: tuple[str, ...] = (
    "BENIGN",            # 0
    "DoS Hulk",          # 1
    "PortScan",          # 2
    "DDoS",              # 3
    "DoS GoldenEye",     # 4
    "FTP-Patator",       # 5
    "SSH-Patator",       # 6
    "DoS slowloris",     # 7
    "DoS Slowhttptest",  # 8
    "Bot",               # 9
)
N_CLASSES = len(CLASSES)
CLASS_TO_IDX = {c: i for i, c in enumerate(CLASSES)}
BENIGN_IDX = 0
ATTACK_IDXS = tuple(range(1, N_CLASSES))
assert CLASSES[BENIGN_IDX] == "BENIGN", "BENIGN must be index 0"

# Dropped classes, with the reason each is dropped. The reason is part of the
# method section; do not drop anything else without adding it here.
DROPPED_CLASSES: dict[str, str] = {
    "Web Attack - Brute Force": (
        "payload-defined; CICFlowMeter carries no payload, so the class is "
        "unidentifiable from these features by construction"),
    "Web Attack - XSS": (
        "payload-defined; unidentifiable from flow features by construction"),
    "Web Attack - Sql Injection": (
        "payload-defined; unidentifiable from flow features by construction"),
    "Infiltration": "36 flows; too few to estimate per-class recall at 5 seeds",
    "Heartbleed": "11 flows; too few to estimate per-class recall at 5 seeds",
}

# CITED composition of MachineLearningCVE. Asserted at load time.
EXPECTED_CLASS_COUNTS: dict[str, int] = {
    "BENIGN": 2_273_097,
    "DoS Hulk": 231_073,
    "PortScan": 158_930,
    "DDoS": 128_027,
    "DoS GoldenEye": 10_293,
    "FTP-Patator": 7_938,
    "SSH-Patator": 5_897,
    "DoS slowloris": 5_796,
    "DoS Slowhttptest": 5_499,
    "Bot": 1_966,
}
EXPECTED_DROPPED_COUNTS: dict[str, int] = {
    "Web Attack - Brute Force": 1_507,
    "Web Attack - XSS": 652,
    "Web Attack - Sql Injection": 21,
    "Infiltration": 36,
    "Heartbleed": 11,
}
TOTAL_FLOWS_CITED = sum(EXPECTED_CLASS_COUNTS.values())          # 2_828_516
TOTAL_RAW_CITED = TOTAL_FLOWS_CITED + sum(EXPECTED_DROPPED_COUNTS.values())
RETENTION_CITED = TOTAL_FLOWS_CITED / TOTAL_RAW_CITED             # 0.999213
IMBALANCE_CITED = (
    EXPECTED_CLASS_COUNTS["BENIGN"] / EXPECTED_CLASS_COUNTS["Bot"])  # 1156.2
assert TOTAL_FLOWS_CITED == 2_828_516, "cited class counts changed"
assert TOTAL_RAW_CITED == 2_830_743, "cited raw total changed"

# Tolerance on the load-time assertion. Exact equality is expected for the
# canonical archive; a nonzero tolerance exists only so that a *documented*
# relabelling (e.g. a corrected-label variant) can be run without editing
# this file. Any run with mismatch != 0 is recorded in the run manifest.
CLASS_COUNT_TOLERANCE = 0.0

# --------------------------------------------------------------------------
# Label normalisation. Raw CSVs contain mojibake in the Web Attack labels
# (a 0x96 en-dash decoded as latin-1 / cp1252 / replacement char), and
# inconsistent spacing. Everything is normalised through here.
# --------------------------------------------------------------------------
LABEL_ALIASES: dict[str, str] = {
    "benign": "BENIGN",
    "dos hulk": "DoS Hulk",
    "portscan": "PortScan",
    "port scan": "PortScan",
    "ddos": "DDoS",
    "dos goldeneye": "DoS GoldenEye",
    "ftp-patator": "FTP-Patator",
    "ftp patator": "FTP-Patator",
    "ssh-patator": "SSH-Patator",
    "ssh patator": "SSH-Patator",
    "dos slowloris": "DoS slowloris",
    "dos slowhttptest": "DoS Slowhttptest",
    "bot": "Bot",
    "botnet": "Bot",
    "infiltration": "Infiltration",
    "heartbleed": "Heartbleed",
}

# --------------------------------------------------------------------------
# Protocol constants. FROZEN by the evaluation rules.
# --------------------------------------------------------------------------
SEEDS: tuple[int, ...] = (0, 1, 2, 3, 4)          # rule 4: 5 seeds, mean +/- std
TARGET_ATTACK_RECALL = 0.95                       # rule 2: primary operating point
SPLIT_FRACTIONS = {"train": 0.60, "val": 0.20, "test": 0.20}
assert abs(sum(SPLIT_FRACTIONS.values()) - 1.0) < 1e-9

PROTOCOLS = ("random", "grouped", "nearduplicate_temporal", "nearduplicate_random")
# Claim surfaces for reporting. 'grouped' when timestamps/IPs are present;
# 'nearduplicate_temporal' when only flow features are available.
CLAIM_SURFACE = "nearduplicate_temporal"
CLAIM_SURFACES = {"grouped", "nearduplicate_temporal"}
NON_CLAIM_PROTOCOLS = ("random", "nearduplicate_random")

# Near-duplicate signature configuration (for metadata-free datasets)
SIGNATURE_LOG_BIN_WIDTH = 0.25
SIGNATURE_EXCLUDE_FEATURES = ("destination port",)
SIGNATURE_CAP_FLOWS = 10_000
MIN_MEAN_LABEL_RUN = 5.0

# Episode construction for the grouped split (see common/protocol.py).
EPISODE_GAP_SECONDS = 60      # gap > this starts a new episode
EPISODE_MAX_SECONDS = 300     # hard cap so one long DoS burst is not one group
BENIGN_BLOCK_MINUTES = 5      # benign flows grouped into contiguous time blocks

# Shared training hyperparameters. Rule 5: ONE dict for ALL models. A model
# that needs a different value here does not get one -- change it for
# everybody or not at all. Per-architecture shape parameters (width, depth)
# live in the model modules; these do not.
SHARED_TRAIN = {
    "epochs": 30,
    "batch_size": 1024,
    "lr": 1e-3,
    "weight_decay": 1e-5,
    "optimizer": "adamw",
    "early_stop_patience": 5,
    "early_stop_metric": "val_macro_f1",
    "grad_clip": 5.0,
    "amp": False,   # sm_61 Pascal: no tensor cores, fp16 gives little and
                    # risks silent overflow in the rate features. Keep fp32.
}

# Hardware note (cited from the stated setup, not probed here):
# single RTX 6000 Pascal, sm_61, 8 GB. check_env.py verifies this at runtime.
GPU_EXPECTED = {"arch": "sm_61", "vram_gb": 8}
