"""Core package: all code for the NIDS architecture comparison lives here."""
