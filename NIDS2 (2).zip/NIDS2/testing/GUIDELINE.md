# Testing Guideline

Verification procedures for the NIDS2 codebase. Read this before you trust
any number this repository produces.

> Nothing in this document reports a result. Every table is a template with
> placeholder cells. If you find a number here that is not either an assertion
> target from `core/config.py` or a piece of arithmetic you can check by hand,
> it is a bug in this document.

---

## 0. Why this folder exists separately

The `core/` tree contains code that produces numbers. This folder contains
procedures that decide whether those numbers mean anything. They are kept
apart because they fail differently: a bug in `core/` usually raises, while a
bug in the protocol produces a plausible table that is wrong. The second kind
is what gets published and then retracted.

Tests here are ordered by cost. Run them in order. Do not proceed past a
failing tier.

---

## 1. Tier 0 — no data required

These catch contract breaks in seconds and need no dataset.

```
python -m core.tools.check_env
```

Expected behaviour: prints environment versions, then instantiates all ten
registered models at `n_features=77, n_classes=10` and prints a parameter
count table. Exits nonzero if any model fails to build.

What a failure means:

| Symptom | Cause to check first |
| --- | --- |
| `ImportError` on `core.models` | a model file did not import; the registry is populated by `core/models/__init__.py` |
| `KeyError` in `group_index_map` | a column name is not in the semantic partition — `feature_groups.py` and the data disagree |
| `sigma` raises `ValueError` about `group_idx` | the caller did not pass the partition; sigma refuses to silently become its own control |
| `AssertionError` about 77 features | the partition in `feature_groups.py` no longer sums to 77 |

Then verify the partition by hand:

```
python -m core.common.feature_groups
```

This prints the group table and the total. The total must be 77, and the
printed note must name `fwd header length.1` as the dropped duplicate. If it
prints 78, the duplicate column is being counted as a real feature and every
per-feature analysis downstream double-counts it.

---

## 2. Tier 1 — import and shape tests

Run these as a scratch script. They need no dataset and no GPU.

```python
import numpy as np, torch
from core.common import feature_groups as fg
from core.common.model_utils import available_models, build_model_seeded

gidx = fg.group_index_map(list(fg.ALL_FEATURES))
x = torch.randn(8, 77)

for name in available_models():
    m = build_model_seeded(name, 77, 10, gidx, seed=0)
    m.eval()
    out = m(m.shape_input(x))
    logits = out[0] if isinstance(out, tuple) else out
    assert logits.shape == (8, 10), (name, logits.shape)
    print(f"{name:<12} ok  params={m.n_params():,}")
```

Three things this catches that nothing else does:

- A model whose `INPUT_KIND` disagrees with what its `forward` actually
  expects. The shape assertion fires immediately.
- A model that returns a tuple without declaring `AUX_LOSS_WEIGHT`, or the
  reverse. Compare `isinstance(out, tuple)` against `m.AUX_LOSS_WEIGHT != 0`.
- BatchNorm in eval mode with a batch of 8. If you hit a BatchNorm error
  here, the model is being left in train mode somewhere.

Also assert the fairness property directly:

```python
import inspect
from core.common.model_utils import MODEL_REGISTRY
for name, cls in MODEL_REGISTRY.items():
    src = inspect.getsource(cls)
    for forbidden in ("optim.", "CrossEntropyLoss", "backward()", "threshold"):
        assert forbidden not in src, (name, forbidden)
```

A model that contains its own optimiser or loss has broken evaluation rule 5,
and the comparison it appears in measures the training recipe rather than the
architecture.

---

## 3. Tier 2 — protocol tests, synthetic data

The split logic is the part most worth testing, because its failures are
silent. Construct a synthetic frame where you know the right answer.

```python
import numpy as np, pandas as pd
from core.common import protocol

n = 20_000
rng = np.random.default_rng(0)
y = np.zeros(n, dtype=np.int64)
y[:2000] = 1                      # one attack class
ts = pd.date_range("2017-07-05 09:00", periods=n, freq="s")
meta = pd.DataFrame({
    "timestamp": ts,
    "src_ip": np.where(y == 1, "172.16.0.1", "192.168.10.5"),
    "dst_ip": "192.168.10.50",
    "label_idx": y,
})

idx, man = protocol.build_grouped_split(y, meta, seed=0)
eps = protocol.build_episodes(meta)
for a in ("train", "val", "test"):
    for b in ("train", "val", "test"):
        if a < b:
            assert not set(eps[idx[a]]) & set(eps[idx[b]])
print(man.n_groups, man.n_train, man.n_val, man.n_test)
```

Required properties, each of which you should assert:

| Property | Why it matters |
| --- | --- |
| No episode id appears in two splits | this is the definition of the grouped protocol; `build_grouped_split` already raises on violation, so this test checks the checker |
| `man.is_claim_surface is True` for grouped | the aggregator keys its refusal behaviour off this |
| `man.is_claim_surface is False` for random | as above, inverted |
| All 10 classes present in each split, or a warning in `man.warnings` | a silently empty class makes per-class recall undefined |
| Flow-level split sizes near 60/20/20 | episode sizes are unequal, so episode-count splitting would skew badly; the code splits on cumulative flow count |

Now test that the protocol refuses rather than degrades:

```python
try:
    protocol.build_split("grouped", y, None, seed=0)
except protocol.ProtocolError as e:
    print("correctly refused:", e)
else:
    raise AssertionError("grouped split without metadata must raise")
```

If this ever silently returns a random split, the claim moves onto the
saturated protocol and the thesis is unsound. That is the single most
important refusal in the codebase.

---

## 4. Tier 3 — metric tests with known answers

Metrics are testable against hand-computed cases. Do it; FPR-at-fixed-recall
is easy to get subtly wrong.

```python
import numpy as np
from core.common import metrics

# 100 benign, 100 attack. Attack scores 0.50..0.99, benign 0.00..0.49.
# Perfectly separable: at 95% recall the threshold sits low in the attack
# range and FPR must be 0.
y = np.r_[np.zeros(100, int), np.ones(100, int)]
p = np.zeros((200, 10))
p[:100, 0] = 1.0                                    # benign -> P(BENIGN)=1
p[100:, 0] = np.linspace(0.50, 0.01, 100)           # attack -> lower P(BENIGN)
p[:, 1] = 1 - p[:, 0]

cal = metrics.calibrate_threshold(y, p, split_name="val")
assert cal["val_attack_recall"] >= 0.95
det = metrics.fpr_at_threshold(y, p, cal["threshold"])
assert det["fpr"] == 0.0, det
```

Cases you must cover:

- **Perfectly separable.** FPR at 95% recall is exactly 0.
- **Pure chance.** Scores drawn from one distribution for both classes: FPR at
  95% recall should be approximately 0.95. Not exactly — check within a few
  percent, not for equality.
- **Absent class.** Remove one class from `y_test` entirely and confirm
  `per_class_recall` returns `nan` for it, not `0.0`. Absent is not failed,
  and a table that conflates them understates the model.
- **Calibration guard.** Call `calibrate_threshold(..., split_name="test")`
  and confirm it raises `CalibrationError`. This is evaluation rule 3 made
  structural.
- **Spread guard.** `format_mean_std([0.9])` must return a string containing
  `SPREAD UNKNOWN`, and `format_mean_std([0.9, 0.9, 0.9])` must contain
  `+/-`. A bare mean must be unreachable.
- **Ordering guard.** `separated_by_more_than_one_std([0.80,0.81],[0.805,0.815])`
  must be `False`. Any ranking statement in the paper needs this to be `True`
  for the pair being ranked.

---

## 5. Tier 4 — smoke run on real data

Only now touch the dataset.

```
python -m core.tools.get_data_kaggle --search
python -m core.tools.get_data_kaggle --dataset <owner>/<slug>
python -m core.tools.build_dataset
python -m core.tools.run_experiment --smoke --models ann sigma --protocols grouped
python -m core.tools.aggregate
```

The smoke flag subsamples and shortens training. Its purpose is to prove the
pipeline runs end to end, and nothing else.

> A smoke run produces numbers. They are not results. They come from a
> subsample with a truncated schedule, and reporting them — even informally,
> even in a supervision meeting — is how a placeholder ends up in a draft.
> Label them in your notes the moment you write them down.

Check the audit output before anything else:

| Audit field | What to check |
| --- | --- |
| `class_count_mismatches` | must be empty; if not, the mirror is modified and not comparable to the literature |
| `retention` | should be ~99.92% against the raw total |
| `n_exact_duplicate_rows` | record it; this is the leakage source the random protocol suffers from |
| `constant_columns` | expect several; they are retained deliberately, and the standardiser maps them to 0 |
| `join_agreement` | must exceed the threshold, or the grouped split is built on mis-attached timestamps |
| timestamp range note | must fall inside 3–7 July 2017, or `dayfirst` parsing is wrong for some files |

The join check deserves emphasis. A failed join does not crash — it produces
a grouped split that looks leakage-free and is not, because timestamps are
attached to the wrong flows. `join_metadata` rejects below the agreement
threshold for exactly this reason. Do not lower the threshold to make it pass.

---

## 6. Tier 5 — the pre-registered falsification tests

These are experiments, not unit tests, and their outcome is allowed to be
unfavourable. Run them before writing any claim.

### 6.1 Column-permutation sensitivity (tests H1)

```
python -m core.tools.run_experiment --protocols grouped --permute-columns
python -m core.tools.aggregate
```

The hypothesis in `core/models/sigma.py` is that models applying convolution
or recurrence along the feature-column axis are relying on an adjacency that
the data does not have. Fill this in from your own runs:

| Model | Macro-F1, canonical order | Macro-F1, permuted | Delta |
| --- | --- | --- | --- |
| cnn1d | | | |
| cnn_rnn | | | |
| cnn_lstm | | | |
| cnn_gru | | | |
| transformer | | | |
| ann | | | |
| sigma | | | |
| gated_mlp | | | |

How to read it, decided in advance:

- If the conv/recurrent rows degrade beyond one standard deviation and the
  MLP-family rows do not, H1 survives and the motivation for a group-based
  architecture holds.
- **If cnn1d does not degrade, H1 is falsified.** Say so in the paper. The
  architectural motivation for SIGMA weakens and the contribution has to rest
  on measured FPR alone. Do not rerun with a different permutation seed
  hoping for a better answer — the seed is fixed in the runner precisely to
  remove that temptation.

### 6.2 The semantic-partition control (tests H2)

`gated_mlp` is SIGMA with the semantic partition replaced by an arbitrary one
of identical group sizes. The comparison decomposes as:

| Contrast | Isolates |
| --- | --- |
| `sigma` − `gated_mlp` | the value of the semantic partition |
| `gated_mlp` − `ann` | the value of the gating machinery |
| `sigma` − `ann` | the proposal as a whole |

Decision rule, fixed before you look: if `sigma` and `gated_mlp` are tied
within one standard deviation on the grouped protocol, the semantic partition
is not doing the work. The contribution is then "group-gated MLPs help on
flow features", which is a smaller and different claim. Rewrite the
contribution sentence rather than the experiment.

### 6.3 Gate ablation

```
python -m core.tools.run_experiment --protocols grouped --models sigma \
    --tag gate_uniform
```

with `gate_mode="uniform"` passed through to the model. This freezes the gate
at 1/G and isolates gating from grouping. Three-way: learned gate, uniform
gate, no groups at all (`ann`).

---

## 7. Tier 6 — full protocol, 5 seeds

```
python -m core.tools.run_experiment --protocols random grouped
python -m core.tools.aggregate --latex
```

Ten models times two protocols times five seeds is 100 runs. Before you read
the table, audit the run directory:

- Any `FAILED` marker file is a missing cell. The runner writes one and
  continues rather than crashing the sweep, so a failure is easy to overlook.
  Fix it and rerun that cell. Do not aggregate over the survivors.
- Any row marked `INCOMPLETE (n/5)` must not be described as best, and must
  not appear in the paper without its `n`.
- Any row where `operating_point_transferred` is `False` has a test recall
  that drifted from 95%. Its FPR is not directly comparable with the other
  rows. Report the realised recall alongside it.

---

## 8. The refusal checklist

Before any table leaves this repository, confirm each line. These correspond
one-to-one with the project's non-negotiable rules.

- [ ] No improvement claim is stated on the random split.
- [ ] Both protocols are reported side by side.
- [ ] No threshold or hyperparameter was selected using test data.
- [ ] Every mean has its standard deviation and its `n`.
- [ ] No ordering is asserted between models tied within one standard deviation.
- [ ] All 10 per-class recalls are reported, with absent classes shown as
      absent rather than as zero.
- [ ] Accuracy appears once, next to the 80.4% BENIGN prevalence that makes
      it uninformative.
- [ ] No class, seed or run was dropped. If one is missing, its absence is
      stated and explained.
- [ ] Macro-F1 values compared against each other come from the same class set.
- [ ] Every sentence in the paper traces to a run in `artefacts/runs/`.

The last one is the one that fails most often. A sentence written from memory
of an earlier run, kept after the run was redone, is the standard way an
unsupported claim survives into a submission.

---

## 9. Regression discipline

When you change anything in `core/common/`, rerun Tiers 0–3 before Tier 4.
They are cheap and they catch contract drift.

When you change `feature_groups.py`, the partition assertion will catch a
non-exhaustive edit, but it will not catch a *semantically wrong* assignment —
moving `Flow IAT Min` into `flags` still sums to 77. Re-read the partition
table by eye after any edit.

When you change anything that affects training, the fairness requirement means
you must rerun **every** model, not just the proposal. A sweep where the
proposal ran under the new setting and the baselines under the old one measures
the setting, not the architecture. If you cannot afford to rerun all ten, do
not change the setting.
