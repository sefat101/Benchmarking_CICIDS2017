# NIDS2 — Repository Guideline

Reduced-class intrusion detection on CICIDS2017 flow features. This document
covers what the code does, what to run, in what order, and which results the
repository will refuse to produce.

> **Provenance discipline.** Three labels are used throughout this repository
> and this document. **MEASURED** means produced by a run in
> `artefacts/runs/`. **CITED** means taken from the dataset documentation or
> the literature. **CONJECTURE** means a hypothesis that has not been tested.
> No conjecture may appear in a results table. Every table in this document is
> a template with empty cells — this repository has produced no results yet.

---

## 1. Layout

All code in `core/`. All generated artefacts outside it. `config.py` enforces
this with `assert_artefact_path`, which raises on any attempt to write a
generated file inside `core/`.

```
core/
  config.py               paths, class set, protocol constants, cited counts
  common/
    feature_groups.py     11-group semantic partition of the 77 features
    preprocessing.py      load, clean, audit, join, scale
    protocol.py           random split + leakage-free grouped split
    metrics.py            FPR@fixed recall, macro-F1, per-class, calibration
    balancing.py          class weights and samplers, one strategy for all
    model_utils.py        model contract, registry, THE shared training loop
    pdfwriter.py          stdlib-only PDF generation for the guidelines
  models/
    ann.py cnn1d.py autoencoder.py encoder.py transformer.py
    cnn_rnn.py cnn_lstm.py cnn_gru.py         8 baselines
    sigma.py                                   the proposal
    gated_mlp.py                               the control
  tools/
    get_data.py           download from the CIC, with mirror fallback
    get_data_kaggle.py    download from Kaggle, with mirror verification
    build_dataset.py      raw CSVs -> cached arrays + audit
    run_experiment.py     the 5-seed runner
    aggregate.py          runs -> tables, with the refusal logic
    check_env.py          environment + instantiate all 10 models
    build_journal_outputs.py   figures and captions
    build_guidelines.py   regenerate the three guideline PDFs

artefacts/                everything generated. Safe to delete and rebuild.
  data/{raw,interim,processed}   runs/   results/   figures/   logs/
docs/GUIDELINE.md|.pdf           this document
testing/GUIDELINE.md|.pdf        verification procedures
proposal_sigma/GUIDELINE.md|.pdf the SIGMA research plan
```

---

## 2. The task

Ten classes: BENIGN, DoS Hulk, PortScan, DDoS, DoS GoldenEye, FTP-Patator,
SSH-Patator, DoS slowloris, DoS Slowhttptest, Bot. 2,828,516 flows, 99.921%
of the labelled total.

Five classes are dropped, each for a reason recorded in
`config.DROPPED_CLASSES`. The three Web Attack classes are payload-defined and
CICFlowMeter carries no payload, so they are unidentifiable from these features
by construction — this is a statement about the feature set, not about
difficulty. Infiltration (36 flows) and Heartbleed (11 flows) are too small to
estimate per-class recall across five seeds.

CITED composition, asserted against the data at load time. If your download
disagrees, `clean_features` raises rather than proceeding:

| Class | Flows | Share |
| --- | --- | --- |
| BENIGN | 2,273,097 | 80.36% |
| DoS Hulk | 231,073 | 8.17% |
| PortScan | 158,930 | 5.62% |
| DDoS | 128,027 | 4.53% |
| DoS GoldenEye | 10,293 | 0.36% |
| FTP-Patator | 7,938 | 0.28% |
| SSH-Patator | 5,897 | 0.21% |
| DoS slowloris | 5,796 | 0.20% |
| DoS Slowhttptest | 5,499 | 0.19% |
| Bot | 1,966 | 0.07% |

BENIGN:Bot is 1,156:1. The three largest attack classes are 92% of all attack
flows, which is why pooled attack recall alone cannot describe a model's
behaviour on this task.

---

## 3. The two protocols

Reported side by side, always.

**Random (stratified, per flow).** The saturated reference. CICIDS2017 attacks
are scripted bursts; consecutive flows within a burst are near-identical, so a
random split deals near-duplicates into train and test simultaneously. Scores
near 0.99 macro-F1 are the known behaviour of this protocol and measure
memorisation, not generalisation. **No claim lives here.** `aggregate.py`
raises if asked to compute an improvement delta on it.

**Grouped (episode, temporal).** The claim surface. An episode is a maximal
run of flows sharing (label, src_ip, dst_ip) with gaps no larger than 60
seconds, capped at 300 seconds. Benign flows are grouped into 5-minute
contiguous blocks per day. Episodes are atomic — every flow in an episode
lands in exactly one split — and assignment is temporal, so training never
sees traffic that postdates its test traffic. `build_grouped_split` asserts
that no episode spans two splits and raises if one does.

The grouped protocol requires `Timestamp` and IP columns. The
`MachineLearningCVE` distribution has them stripped. If they are absent,
`build_split` raises rather than falling back to the random split — a silent
fallback would move the claim onto the saturated protocol, which is the exact
failure the protocol module exists to prevent.

Rejected alternatives, with reasons: day holdout puts most classes at zero
training flows, because PortScan, DDoS and Bot occur only on Friday and the
DoS family only on Wednesday. Host holdout empties whole classes, since the
dataset uses very few attacker hosts; it is implemented as a diagnostic to
demonstrate that, and macro-F1 from it is not reportable because it changes
the class set between folds.

---

## 4. The metrics

Two decision rules, from one model. Conflating them is the most common way to
get a NIDS table wrong.

**Closed-set classification**, by argmax over the ten outputs. Gives macro-F1
and per-class recall. No threshold involved.

**Detection at an operating point.** Collapse to `attack_score = 1 − P(BENIGN)`
and compare against a threshold chosen on validation so that pooled attack
recall reaches 95%. The threshold is then frozen and applied to test. FPR at
that frozen threshold is the primary headline.

`calibrate_threshold` takes a `split_name` argument and raises unless it is
`"val"`. Calibrating on test is not a discouraged practice in this
repository; it is unreachable.

Because the threshold is frozen from validation, realised test recall drifts.
`fpr_at_threshold` therefore always returns the realised recall alongside the
FPR, and flags `operating_point_transferred=False` when the drift exceeds two
percentage points. An FPR reported without the recall it was measured at is
meaningless, and two FPRs at different realised recalls are not comparable.

Accuracy is reported once, beside the 80.4% BENIGN prevalence, to show that a
do-nothing predictor achieves it.

---

## 5. Getting the data

Two routes. Both verify what they downloaded.

```
python -m core.tools.get_data --which both
```

Fetches `MachineLearningCSV.zip` and `GeneratedLabelledFlows.zip` from the
CIC. The URLs are **unverified** — they were not reachable from the machine
where this code was written, and the CIC has relocated this dataset more than
once. The tool tries several candidates and, if all fail, prints manual
instructions rather than failing silently.

```
python -m core.tools.get_data_kaggle --search
python -m core.tools.get_data_kaggle --dataset <owner>/<slug>
```

Kaggle route. `--search` lists candidate datasets **with their file listings**
and flags which can support the grouped protocol, before downloading anything.
This matters: most Kaggle mirrors carry only the 78-feature CSVs, with
`Timestamp` and IPs stripped, and several are silently deduplicated or
re-labelled. After extraction the tool reads every CSV header and reports
whether the key columns are actually present.

Credentials are read from `KAGGLE_API_TOKEN`, `~/.kaggle/access_token`,
`KAGGLE_USERNAME`+`KAGGLE_KEY`, or `~/.kaggle/kaggle.json`, in that order.
No credential is stored in this repository — it is a git repository, and a
committed token is worse than an inconvenient one.

```
python -m core.tools.build_dataset
```

Loads, normalises labels, filters to the ten classes, asserts the class counts
against the cited composition, handles infinities, audits degenerate columns,
joins the group keys, and caches arrays plus a `DataAudit`.

Read the audit before anything else. `class_count_mismatches` must be empty —
if it is not, the mirror has been modified and its numbers are not comparable
with the literature. `join_agreement` must clear its threshold, or the
timestamps are attached to the wrong flows and the grouped split would look
leakage-free while not being so. Do not lower that threshold to make it pass.

---

## 6. Running experiments

```
python -m core.tools.check_env
python -m core.tools.run_experiment --smoke --models ann sigma --protocols grouped
python -m core.tools.run_experiment --protocols random grouped
python -m core.tools.run_experiment --protocols grouped --permute-columns
python -m core.tools.aggregate --latex
python -m core.tools.build_journal_outputs
```

The runner builds the split once per (protocol, seed) and loops models inside
it, so every model in a cell sees an identical split. The scaler is fit on
train indices only, inside the loop, after the split. A model that crashes
writes a `FAILED` marker and the sweep continues — check for those before
aggregating, because a failed cell is a missing row, not a zero.

Smoke runs produce numbers that are not results. They come from a subsample
with a truncated schedule. Label them the moment you write them down.

---

## 7. What makes the comparison fair

Evaluation rule 5 — any change applied to the proposal is applied identically
to all baselines — is enforced structurally rather than by discipline.

Models define **only** a forward pass. The training loop, optimiser, schedule,
loss, gradient clipping, early stopping and class weighting live in
`core/common/model_utils.py` and `balancing.py`, and are identical for all ten
models. There is no per-model `train()` method to diverge. A model that needs
a different learning rate does not get one; the value changes for everybody or
not at all.

Two consequences worth stating in the paper. The autoencoder's reconstruction
loss is declared through `AUX_LOSS_WEIGHT` in the open, as part of its
definition as an architecture, not as a training advantage. And `drop_last` is
true for training loaders only, because every model uses BatchNorm and a
final batch of size one raises — at most 1023 rows of 1.7M, applied
identically to all ten models, and no evaluation row is ever dropped.

---

## 8. What this repository refuses to do

Each refusal is implemented, not merely documented.

| Refusal | Where |
| --- | --- |
| Improvement claim on the random split | `aggregate.py` raises on `--claim-protocol random`; `metrics.evaluate` cross-checks `is_claim_surface` against `config` |
| Calibrating a threshold on test | `calibrate_threshold` raises unless `split_name="val"` |
| Grouped split silently degrading to random | `build_split` raises when metadata is absent |
| An episode spanning two splits | `build_grouped_split` raises |
| A mean without its spread | `format_mean_std` returns `SPREAD UNKNOWN` at n=1 and annotates n<5 |
| An ordering claim within one std | `separated_by_more_than_one_std` gates every ranking statement |
| Silently dropping a class | absent classes render as `absent`, not `0`; splits that empty a class emit a warning |
| A modified dataset mirror passing as canonical | class counts asserted against `config.EXPECTED_CLASS_COUNTS` |
| Generated artefacts inside `core/` | `assert_artefact_path` raises |

---

## 9. Reporting template

The main table. Both protocols, side by side. Empty because no run has
happened.

| Model | FPR @ 95% recall (grouped) | Macro-F1 (grouped) | Macro-F1 (random, reference) |
| --- | --- | --- | --- |
| ann | | | |
| cnn1d | | | |
| autoencoder | | | |
| encoder | | | |
| transformer | | | |
| cnn_rnn | | | |
| cnn_lstm | | | |
| cnn_gru | | | |
| gated_mlp (control) | | | |
| sigma (proposal) | | | |

Every cell is `mean ± std` over five seeds. The random column carries a
banner stating it is a saturated reference from which no improvement claim may
be drawn. Per-class recall for all ten classes goes in a second table, with
absent classes marked `absent` rather than `0`. Accuracy appears once, next to
the 80.4% BENIGN prevalence.

Before submission, walk the refusal checklist in `testing/GUIDELINE.md`
section 8. The line that fails most often is the last one: every sentence in
the paper must trace to a run in `artefacts/runs/`. A sentence written from
memory of an earlier run, kept after the run was redone, is the standard route
by which an unsupported claim reaches a submission.

---

## 10. Known limitations

Single dataset, single capture week, single extractor. Nothing here
demonstrates generalisation beyond CICIDS2017.

CICIDS2017 has documented defects: duplicated flows, labelling errors at
attack-window boundaries, and constant-zero columns from the extractor itself.
This pipeline audits and reports them rather than silently cleaning them,
because cleaning would break comparability with published baselines that
consume the original release. State this in the limitations section and cite
the corrected-dataset literature.

The episode gap and cap are modelling choices. If model ordering changes when
they change, that ordering is an artefact of the grouping parameters and must
be reported as one.

Under temporal assignment the grouped split is deterministic and does not vary
with seed. The reported standard deviation is model variance only. Say so — a
reader who assumes it includes split variance will read the error bars as
stronger evidence than they are.

---

## 11. Regenerating these documents

```
python -m core.tools.build_guidelines
```

Rebuilds all three PDFs from their markdown sources using
`core/common/pdfwriter.py`, which depends only on the standard library.
